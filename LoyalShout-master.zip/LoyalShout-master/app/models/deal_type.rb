class DealType < ActiveRecord::Base
  attr_accessible :name
  has_many :deals
end
