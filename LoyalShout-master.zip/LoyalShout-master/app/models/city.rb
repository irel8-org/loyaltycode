class City < ActiveRecord::Base
  attr_accessible :name, :state_id, :zip
  belongs_to :state
  has_many :users
end
