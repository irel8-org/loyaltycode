class Deal < ActiveRecord::Base
  attr_accessible :deal_image, :deal_key, :deal_price, :deal_redemption, :deal_title, :deal_type_id, :description, :end_date, :fine_print, :highlights, :max_buy, :max_gift_buy, :min_buy, :min_coupons, :regular_price, :reviews, :start_date, :user_id
  belongs_to :deal_type
end
