ActiveAdmin.register Deal do
  
end
