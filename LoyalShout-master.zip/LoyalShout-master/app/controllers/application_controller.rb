class ApplicationController < ActionController::Base
  protect_from_forgery
  def after_sign_in_path_for(resource)
    resource.is_admin? ? admin_dashboard_path : root_path
  end

  def authenticate_admin_user!
    raise SecurityError unless current_user.is_admin?
  end

  rescue_from SecurityError do |exception|
    redirect_to root_path
  end
end
