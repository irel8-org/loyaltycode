class RegistrationsController < Devise::RegistrationsController
  def new
    @states = State.all
  end

  def dynamic_cities
    @cities = City.find_all_by_state_id(params[:id])
 
    respond_to do |format|
      format.js 
    end          
  end

end 