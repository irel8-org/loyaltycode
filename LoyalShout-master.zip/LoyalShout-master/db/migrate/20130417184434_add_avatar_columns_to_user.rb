class AddAvatarColumnsToUser < ActiveRecord::Migration 
  add_column :users, :avatar, :string
end