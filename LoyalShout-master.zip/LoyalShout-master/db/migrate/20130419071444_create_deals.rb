class CreateDeals < ActiveRecord::Migration
  def change
    create_table :deals do |t|
      t.integer :user_id
      t.integer :deal_type_id
      t.integer :deal_redemption
      t.string :deal_key
      t.date :start_date
      t.date :end_date
      t.integer :min_buy
      t.integer :max_buy
      t.integer :max_gift_buy
      t.integer :min_coupons
      t.integer :regular_price
      t.integer :deal_price
      t.string :deal_title
      t.text :fine_print
      t.text :highlights
      t.text :description
      t.text :reviews
      t.string :deal_image

      t.timestamps
    end
  end
end
