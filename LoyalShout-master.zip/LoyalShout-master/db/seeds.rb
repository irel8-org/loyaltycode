require 'open-uri'
# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
  cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
  Mayor.create(name: 'Emanuel', city: cities.first)
puts '------Create user role------'
  if Role.find_or_create_by_name(:name => 'admin') 
    puts 'Create admin role'
  end
  if Role.find_or_create_by_name(:name => 'simple') 
    puts 'Create simple role'
  end

puts '------Create admin user-----'
  admin = User.new(:email => 'admin@ddeals.com', :password => '12345678', :password_confirmation => '12345678')
  admin.roles << Role.find_by_name('admin')
  if admin.save
    puts 'Create admin user'
  end

puts '------Create States------'

  states = JSON.parse( IO.read(Rails.root.to_s+"/db/states.json") )
  states.each_pair {|abr, name| puts name if State.find_or_create_by_name(:name => name, :abbreviation => abr)  }

puts '----Create Cities------'
  states = State.all
  states.each do |state|
    puts state.name

    jsoncities = open('http://gomashup.com/json.php?fds=geo/usa/zipcode/state/'+state.abbreviation+'&jsoncallback=').read.chop 
    cit =  JSON.parse(jsoncities[1..-1])
    cit["result"].each do |city|
      puts city["City"]+" create" if state.cities.find_or_create_by_zip(:name => city["City"], :zip => city["Zipcode"].to_i)
    end
  end