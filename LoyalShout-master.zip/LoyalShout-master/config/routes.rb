DealyDeals::Application.routes.draw do
  devise_for :users, :controllers => {:registrations => "registrations"} do
    get 'logout' => 'devise/sessions#destroy'
    post "dynamic_cities/:id" => "registrations#dynamic_cities"
  end

  


  
  root :to => 'welcome#index'
ActiveAdmin.routes(self)
  # See how all your routes lay out with "rake routes"

  # This is a legacy wild controller route that's not recommended for RESTful applications.
  # Note: This route will make all actions in every controller accessible via GET requests.
  # match ':controller(/:action(/:id))(.:format)'
end
