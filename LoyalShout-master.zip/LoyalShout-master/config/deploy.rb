# Имя приложения
set :application, "LoyalShout"
# Вызов функции set создаст переменную application и присвоит ей значение "myproject"

# В проекте мы используем только один сервер, выполняющий роль веб-сервиса.
role :web, "108.166.87.231" # хост удалённого сервера
set :user, 'admin' # пользователь удалённого сервера
set :password, 'uiubminOHE@u6u'
set :use_sudo, false # не запускать команды под sudo

# Директория приложения на удалённом хостинге
set :app_dir, "/var/www/admin/data/www" # /home/myuser/myproject/

# Директория, куда будет делаться checkout из репозитория
set :deploy_to, "#{app_dir}/loyalshout.moegenius.com/" # /home/myuser/myproject/deploy

set :repository, "git@github.com:MoeGenius/LoyalShout.git"  # Your clone URL
set :scm, "git"
set :scm_username, "dmsilaev"
set :scm_passphrase, "c33cbd0f8d"  # The deploy user's password


