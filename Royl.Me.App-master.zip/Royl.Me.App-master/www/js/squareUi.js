
	$('#dropdown-1').on('click', 'li', function(e) {
		var target = $(e.target),
			value = target.attr('data-value');
		target.parents('.dropdown').find('.dropdown-toggle').text(value);
	});

	$('#venue-name-0').typeahead({
		minLength: 3,
		source: function(query, process) {
			var hardcodedOptions = ['a', 'aa', 'aaa', 'aaaa', 'aaaaa', 'aaaaaa', 'aaaaaaa', 'b', 'bb', 'bbb', 'bbbb', 'bbbbb', 'bbbbbb', 'bbbbbbb'];
			process(hardcodedOptions);
		}
	});

    $(document).ready(function() {
        $('.toggle').click(function() {
            $(this).toggleClass('toggle-off').toggleClass('toggle-on');
        });
    });

    $(document).ready(function() {
        var pagination = $('#pagination-slider-1');
        pagination.mousedown(function(e) {
            var target = $(e.target),
                    lastItem = target,
                    items = $(this).children('li'),
                    syncFirstLast = function() {
                        items.removeClass('slider-left').removeClass('slider-right');
                        items.filter('.active').first().addClass('slider-left');
                        items.filter('.active').last().addClass('slider-right');
                    };
            items.on('mouseenter', (function(e) {
                var enterTarget = $(e.target),
                        isLeft = enterTarget.hasClass('slider-left'),
                        isRight = enterTarget.hasClass('slider-right'),
                        isActive = enterTarget.hasClass('active'),
                        isLastSlider = lastItem.hasClass('slider-left') || lastItem.hasClass('slider-right');


                if (!(isLeft && isRight)) {
                    if (isActive && isLastSlider) {
                        lastItem.removeClass('active');
                    } else if (!isActive) {
                        enterTarget.addClass('active');
                    }
                    syncFirstLast();
                }

                lastItem = enterTarget;
            }));

            $(document).one('mouseup', function() {
                items.off('mouseenter');
            });
            pagination.one('mouseleave', function() {
                items.off('mouseenter');
            });

            return false; //Prevent selection cursor
        });
    });