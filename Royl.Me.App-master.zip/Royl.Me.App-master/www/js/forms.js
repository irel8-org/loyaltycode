var formErrors = {};

function error_occurred_for_form(form) {
	var cont = $(form).find('.form-submit-error');
	
	if(cont.length > 0){
		cont.html($LOCALE.get('form_not_submited')).show();
	} else {
		$(form).append('<div class="form-submit-error">'+$LOCALE.get('form_not_submited')+'</div>');
	}  
}
function submitData(form) {
	$(form).find('[type="submit"]').attr('disabled', true);
	
  if ($(form).data('before-call')) {
			eval($(form).data('before-call') + '()');
	}
			var formVals = $(form).serialize();
	
	var device_attrs = authDeviceAttributes();
	
  formVals = formVals + '&' + decodeURIComponent($.param(device_attrs));
  
  formVals = formVals + '&' + decodeURIComponent($.param({api_version: $CONFIG.moe.api_version, without_reseller_ids: $CONFIG.moe.without_reseller_ids, reseller_id: $CONFIG.moe.reseller_id}));

	if ($(form).data('config-param')) {
		var source = $(form).data('config-source') || 'local';

		url = $CONFIG[source][$(form).data('config-param')];
	} else {
		url = $(form).attr('action');
	}
	
	url = url.replace(/_CONSUMER_ID_/, window.localStorage.getItem("consumer_id"));
	
	if ($(form).data('should-be-signed')){
		url += '?auth_token='+window.localStorage.getItem("auth_token");
	}	$.post(url, formVals, function(data) {
		if(data.status == 401){
		 	alert($LOCALE.get('your_session_is_expired_pls_authorize_again'));
		 	authCleanConsumerDataAndRedirect();
		} else if ($(form).data('callback')) {
			eval($(form).data('callback') + '(data)');
		}
		
		$(form).find('[type="submit"]').attr('disabled', false);	}, 'json').fail(function(data) {
		if ($(form).data('error-callback')) {
			try {
	  		eval($(form).data('error-callback') + '(JSON.parse(data.responseText))');
			} catch(e) {
				console.log(form);
				error_occurred_for_form(form);
			}
		} else {
			console.log(form);
			error_occurred_for_form(form);
		}
		
		$(form).find('[type="submit"]').attr('disabled', false);
	});};
function addErrorToField(field, message) {
	$(field).focus();

	$(field).parent().addClass('error');

	if ($(field).siblings('.error-message').length == 0) {
		$(field).after('<span class="error-message"></span>');
	}

	$(field).siblings('.error-message').html(message);
}

function isFieldBlank(field) {
	var str = typeof (field) == 'string' ? field : $(field).val();
	return !!str.match(/^\s*$/);
}

function formsAddError(field, message) {
	field = $(field).attr('id');
	if(formErrors[field] == undefined){
		formErrors[field] = [];
	}
	
	formErrors[field].push(message);
}

function formsErrorExist(){
	return Object.keys(formErrors).length > 0;
}

function validForm(form) {	form = $(form);	form.find('.error').removeClass('error');
	form.find('.success-message').remove();
	
	formErrors = [];	form.find('.requiredFieldForChoice').each(function(i) {		vals = [];		$('[data-choice=' + $(this).data('choice') + ']').each(function() {			vals.push($(this).val());		});		if (isFieldBlank(vals.join(''))) {
			formsAddError(this, 'cannot be blank');		}	});	form.find('.requiredField').each(function(i) {		if (isFieldBlank(this)) {
			formsAddError(this, $LOCALE.get('cannot_be_blank'));
					} else if ($(this).hasClass('requiredEmailField')) {			var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;			if (!emailReg.test($(this).val())) {
				formsAddError(this, $LOCALE.get('cannot_be_blank'));			}
		}
	});
	
	form.find('.customValidation').each(function(i) {
		$this = $(this);
		if($this.data('type')){
			if($this.data('type') == 'integer' && !$this.val().match(/^\d+$/)){
				formsAddError(this, $LOCALE.get('should_be_numericality'));
			}else if ($this.data('type') == 'string'){
				// todo
			}
		}
		
		if($this.data('size-max') && $this.val().length > parseInt($this.data('size-max'))){
		  formsAddError(this, $LOCALE.get('should_have_length_less_or_equal') + ' ' + $this.data('size-max'));
		}
		
		if($this.data('size-min') && $this.val().length < parseInt($this.data('size-min'))){
		  formsAddError(this, $LOCALE.get('should_have_length_more_or_equal')+' '+$this.data('size-min'));
		}
		
		if($this.data('size-equal') && $this.val().length != parseInt($this.data('size-equal'))){
		  formsAddError(this, $LOCALE.get('should_have_length_equal')+' '+$this.data('size-equal'));
		}
	});
	
	form.find('.ShouldBeConfirmedField').each(function(i) {
		$this = $(this);
		$this_conf = $('#'+$this.attr('id')+'-confirmation');
		
	  if($this.val() != $this_conf.val()){
		  formsAddError($this_conf, $LOCALE.get('invalid_confirmation'));
		}
	});
	return !formsErrorExist();}
function ReqieredNotSet(field) {	addErrorToField(field, $LOCALE.get('cannot_be_blank'));	return false;}

function formsSetEvents(klass) {
	if(!klass) klass = 'smart-form';
	//console.log('formsSetEvents', klass, $('form.'+klass));
	
	$('form.'+klass).bind('submit', function() {	
		
		if (validForm(this)) {			
			submitData(this);
		} else {
			for(i in formErrors){
			  addErrorToField($('#'+i), formErrors[i].join(' '+$LOCALE.get('and')+' ')); 
			}
		}
		
		headerControll();

		return false;
	});
}

$(document).ready(function() {
	formsSetEvents();
});
