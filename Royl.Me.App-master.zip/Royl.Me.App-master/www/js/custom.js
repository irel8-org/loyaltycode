$.urlParam = function(name) {
	//console.log(name, document.location.href);
	var results = new RegExp('[\\?&]' + name + '=([^&#]*)').exec(document.location.href);
	return (results !== null) ? decodeURIComponent(results[1]) : null;
}
function closeSidebar() {
	$('.sidebar-right').animate({
		right : '-300px',
	}, 300, 'easeInOutExpo', function() {
	});
}

function setSidebar() {
	$.ajax({
		url : $CONFIG.local.sidebar_path,
		success : function(data) {
			$('.mainContent').after(templateReplaceVars(data, {}, true));

			$('.deploy-right-sidebar').click(function() {
				$('.sidebar-right').delay(300).animate({
					right : '-10',
				}, 300, 'easeOutExpo', function() {
				});
				return false;
			});

			$('.close-sidebar-right, .mainContent').click(function() {
				closeSidebar();
			});

		},
		dataType : 'html'
	});
}

function floatToS(val){
	if(val){
		if((val+'').match(/\.\d{3}/)){
			val = val.toFixed(2);
		}
	}
	
	return val;
}

function setBackObserve(){
	$('.btn-small.arrow-left-white-large').bind('click', function(){
    window.history.go(-1);
  });
}

$(document).ready(function() {
	if (authIsLogged()) {
		setSidebar();
	}
	
	setBackObserve();
	
  
}); 
