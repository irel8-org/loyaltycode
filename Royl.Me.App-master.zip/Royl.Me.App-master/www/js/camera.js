// device APIs are available
//
function cameraRemovePreloader() {
	$('#preloader').hide();
}

function cameraShowPreloader() {
	$('#preloader').show();
  $('#preloader #status').show();
}

function cameraOnDeviceReady() {
	$CONFIG.local.picture_source = navigator.camera.PictureSourceType;
	$CONFIG.local.destination_type = navigator.camera.DestinationType;
	
	window.requestFileSystem(LocalFileSystem.PERSISTENT, 1024*1024, cameraGotFileSystem, cameraFsFail1); 
	
	//if(window.localStorage.getItem("consumer_avatar_needs_to_upload") && window.localStorage.getItem("consumer_local_avatar")){
  //  cameraUploadPhotoToServer( window.localStorage.getItem("consumer_local_avatar") );
	//}
}

// Called when a photo is successfully retrieved
//
// function cameraOnPhotoURISuccess(imageURI) {
	// console.log('cameraOnPhotoURISuccess');
	// console.log(imageURI);
	// $('#avatar').attr('src', imageURI);
	// console.log($('#avatar').attr('src'));
// 	
	// window.localStorage.setItem("consumer_local_avatar", imageURI);	
// 	
	// camperaUploadPhoto(imageURI);	
// }

// A button will call this function
//
function cameraCapturePhoto() {
	
	navigator.camera.getPicture(cameraPhotoSave, cameraOnFail, {
		quality : 50,
		targetWidth: 1000,
    targetHeight: 1000,
		destinationType : $CONFIG.local.destination_type.FILE_URI
	});
}

function cameraGotFileSystem(fileSystem){ 
  $CONFIG.local.file_system = fileSystem;  
}; 
     
function camerGotFileEntry(fileEntry) {   
	//console.log('camerGotFileEntry'+fileEntry.toURL()+fileEntry.fullPath);
//	 $CONFIG.local.file_system.root.getDirectory("photos", {create: true, exclusive: false}, function(dir) { 
	 //	console.log('camerGotFileEntry2');
     fileEntry.copyTo($CONFIG.local.file_system.root, null, cameraCopiedFile, cameraFsFail2); 
  // }, cameraFsFail4);  
	// console.log('camerGotFileEntry3');
	 cameraUploadPhotoToServer(fileEntry.toURL());	   
}


function cameraPhotoSave(imageURI) {  
//	console.log(imageURI);
  cameraShowPreloader();
	
	window.localStorage.setItem("consumer_avatar_needs_to_upload", true);	
	
	var rLocalFileSystemURL;
	
  //resolve file system for image 
  //(image is currently stored in dir off of persistent file system but that may change) 
  if(window.resolveLocalFileSystemURL == undefined){
  	rLocalFileSystemURL = window.resolveLocalFileSystemURI;
  } else {
  	rLocalFileSystemURL = window.resolveLocalFileSystemURL;
  }
  
  rLocalFileSystemURL(imageURI, camerGotFileEntry, cameraFsFail3); 
  	
  // upload to server
	
} 

function cameraCopiedFile(fileEntry) { 
	$('#avatar').attr('src', fileEntry.toURL() + "?v=" + (new Date()).getTime());	
	window.localStorage.setItem("consumer_local_avatar", fileEntry.toURL());		
} 

function cameraFsFail1(error) {	
    console.log("cameraFsFail1"); 
    cameraFsFail(error);
}  
function cameraFsFail2(error) {	
    console.log("cameraFsFail2"); 
    cameraFsFail(error);
}
function cameraFsFail3(error) {	
    console.log("cameraFsFail3"); 
    cameraFsFail(error);
}  
function cameraFsFail4(error) {	
    console.log("cameraFsFail4"); 
    cameraFsFail(error);
}  

// file system fail 
function cameraFsFail(error) {	
    console.log("failed with error code: " + error.code); 
    console.log(error);
}           
        

// Called if something bad happens.
//
function cameraOnFail(message) {
	console.log('Failed because: ' + message);
}

function cameraUploadPhotoToServer(imageURI) {

  //console.log('cameraUploadPhotoToServer');

	var options = new FileUploadOptions();

	options.fileKey = "consumer[photo]";

	options.fileName = imageURI.substr(imageURI.lastIndexOf('/') + 1);

	options.mimeType = "image/jpeg";

	var params = new Object();
	params.auth_token = window.localStorage.getItem("auth_token");

	options.params = params;

	var ft = new FileTransfer();
	
	//console.log('imageURI : '+imageURI);
	ft.upload(imageURI, $CONFIG.moe.prepared_update_consumer_url, cameraPhotoUploaded, cameraPhotoNotUploaded, options);
//  console.log('cameraUploadPhotoToServer2');
}

function cameraPhotoUploaded(r) {
	//console.log('cameraPhotoUploaded');
	window.localStorage.setItem("consumer_avatar_needs_to_upload", false);
	authSetConsumerAvatar(JSON.parse(r.response));
	
	cameraRemovePreloader();
}

function cameraPhotoNotUploaded(error) {
  console.log('cameraPhotoNotUploaded');
	authSetConsumerAvatar(null);

	cameraRemovePreloader();
}

