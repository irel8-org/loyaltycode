function showWelcome() {
	var obj = {};
	
	obj.consumer_name = window.localStorage.getItem('consumer_name');

	res = authSignedRequest( $CONFIG.moe.merchants_url, 'GET', {
		count_merchant : 10
	});
	merchants = [];
	obj.count_rewards = 0;
	obj.points = 0;
	obj.loyalty_value = 0;

  if(res){
		for (i in res) {
			var add = false;	
			
			obj.count_rewards +=  res[i].count_rewards;
			
			if(res[i].count_rewards > 0) add = true;

		  obj.points +=  res[i].points_balance;
		  	
		 	if(res[i].points_balance > 0) add = true;
			
			if(res[i].enabled_loyalty == 'SS'){	  	
		  	// obj.points +=  res[i].points_balance;
 		  	
		  	// if(res[i].points_balance > 0) add = true;
		 	} else {
			  obj.loyalty_value +=  res[i].loyl_me_loyalty_value;
			  
			  if(res[i].loyl_me_loyalty_value > 0) add = true;
			}
			
		  if (add && merchants.indexOf(res[i].id) == -1) merchants.push(res[i].id);
			
	  }	
  }	
	
	obj.merchant_count = merchants.length;
	obj.points_rewards = [];

	if(obj.points > 0) obj.points_rewards.push(obj.points+' point'+(obj.points > 1 ? 's' : ''));
	if(obj.count_rewards > 0) obj.points_rewards.push(obj.count_rewards+' reward'+(obj.count_rewards > 1 ? 's' : ''));
	if(obj.loyalty_value > 0) obj.points_rewards.push('$'+floatToS(obj.loyalty_value));
	
	if(obj.merchant_count > 0){
		obj.merchant_count_string = obj.merchant_count+' merchant'+(obj.merchant_count > 1 ? 's' : '');
	} else {
		obj.rewards_hidden = 'style="display:none;"';
	}
		
	obj.points_rewards = obj.points_rewards.join(' and ');

	var html = templateReplaceVars($('body').html(), obj);

	$('body').html(html);
}
