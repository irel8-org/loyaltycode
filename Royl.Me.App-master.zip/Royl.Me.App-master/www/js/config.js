var $ = jQuery.noConflict();
var $CONFIG = new Object;

$CONFIG.moe  = new Object;
$CONFIG.local  = new Object;
$CONFIG.db     = new Object;
$CONFIG.locale = new Object;
$CONFIG.push_notifications = new Object;
$CONFIG.debug = false;//true;
$CONFIG.verify_first_use = false;

$CONFIG.locale.available = ['en', 'es', 'it'];
$CONFIG.locale.base = 'en';
$CONFIG.locale.current = window.localStorage.getItem("consumer_locale") || 'en';

$CONFIG.snow_shoe = new Object;
$CONFIG.snow_shoe.debug = $CONFIG.debug;

$CONFIG.debug_code = $CONFIG.debug ? '9EWDbwm9o5uNtt10nQ7o53BB2Na1Jh2' : '';
$CONFIG.error_message_should_be_authorized = 'You need to sign in or sign up before continuing.';
$CONFIG.error_message = "Rubbish! We've encountered an issue. We'll direct you back to the main page momentarily.  Our apologies.";
$CONFIG.second_error_message = "Rubbish!  We've encountered a bugger. Tap your home button twice (the round button on your iPhone), select Royl.Me and slide it to the top.  Then come on back.  Our sincere apologies - cheers!";

////////// MOE SETTINGS //////////
$CONFIG.moe.url = 'http://moegenius.com';
//$CONFIG.moe.url = document.location.host == 'royal' ?  'http://loc.my:4500' :  'http://moegenius.com';
$CONFIG.moe.url = 'http://staging.moegenius.com';

$CONFIG.moe.reseller_id = '';
$CONFIG.moe.without_reseller_ids = [26];
$CONFIG.moe.api_version = 1.1;

$CONFIG.moe.session_create_path = '/consumer_api/sessions';
$CONFIG.moe.session_create_url = $CONFIG.moe.url+$CONFIG.moe.session_create_path;

$CONFIG.moe.facebook_session_create_path = '/consumer_api/sessions/sign_in_via_facebook';
$CONFIG.moe.facebook_session_create_url = $CONFIG.moe.url+$CONFIG.moe.facebook_session_create_path;

$CONFIG.moe.session_destroy_path = '/consumer_api/sessions/_CONSUMER_ID_';
$CONFIG.moe.session_destroy_url = $CONFIG.moe.url+$CONFIG.moe.session_destroy_path;

$CONFIG.moe.registration_path = '/consumer_api/registrations';
$CONFIG.moe.registration_url = $CONFIG.moe.url+$CONFIG.moe.registration_path;

$CONFIG.moe.reset_password_code_path = '/consumer_api/passwords';
$CONFIG.moe.reset_password_code_url = $CONFIG.moe.url+$CONFIG.moe.reset_password_code_path;

$CONFIG.moe.reset_password_change_path = '/consumer_api/passwords/_CONSUMER_ID_';
$CONFIG.moe.reset_password_change_url = $CONFIG.moe.url+$CONFIG.moe.reset_password_change_path;

$CONFIG.moe.geo_notification_request_path = '/consumer_api/notifications/geo_request';
$CONFIG.moe.geo_notification_request_url = $CONFIG.moe.url+$CONFIG.moe.geo_notification_request_path;

$CONFIG.moe.merchants_path = '/consumer_api/merchants';
$CONFIG.moe.merchants_url = $CONFIG.moe.url+$CONFIG.moe.merchants_path;

$CONFIG.moe.search_merchants_path = '/consumer_api/merchants/search';
$CONFIG.moe.search_merchants_url = $CONFIG.moe.url+$CONFIG.moe.search_merchants_path;

$CONFIG.moe.create_merchants_path = '/consumer_api/merchants';
$CONFIG.moe.create_merchants_url = $CONFIG.moe.url+$CONFIG.moe.create_merchants_path;

$CONFIG.moe.show_merchant_path = '/consumer_api/merchants/_MERCHANT_ID_';
$CONFIG.moe.show_merchant_url = $CONFIG.moe.url+$CONFIG.moe.show_merchant_path;

$CONFIG.moe.update_consumer_path = '/consumer_api/consumers/_CONSUMER_ID_';
$CONFIG.moe.update_consumer_url = $CONFIG.moe.url+$CONFIG.moe.update_consumer_path;
$CONFIG.moe.prepared_update_consumer_url = $CONFIG.moe.update_consumer_url.replace(/_CONSUMER_ID_/, window.localStorage.getItem("consumer_id"));

$CONFIG.moe.show_consumer_path = '/consumer_api/consumers/_CONSUMER_ID_';
$CONFIG.moe.show_consumer_url = $CONFIG.moe.url+$CONFIG.moe.show_consumer_path;
$CONFIG.moe.prepared_show_consumer_url = $CONFIG.moe.show_consumer_url.replace(/_CONSUMER_ID_/, window.localStorage.getItem("consumer_id"));

$CONFIG.moe.balances_consumer_path = '/consumer_api/consumers/balances';
$CONFIG.moe.balances_consumer_url = $CONFIG.moe.url+$CONFIG.moe.balances_consumer_path;

$CONFIG.moe.reconfirm_email_path = '/consumer_api/consumers/_CONSUMER_ID_/send_confirmation_instruction';
$CONFIG.moe.reconfirm_email_url = $CONFIG.moe.url+$CONFIG.moe.reconfirm_email_path;

$CONFIG.moe.link_to_facebook_consumer_path = '/consumer_api/consumers/_CONSUMER_ID_/link_to_facebook';
$CONFIG.moe.link_to_facebook_consumer_url = $CONFIG.moe.url+$CONFIG.moe.link_to_facebook_consumer_path;


$CONFIG.moe.snowshoe_path = '/consumer_api/snow_shoe/callback';
$CONFIG.moe.snowshoe_url = $CONFIG.moe.url+$CONFIG.moe.snowshoe_path;

$CONFIG.moe.find_merchant_by_stamp_path = '/consumer_api/snow_shoe/merchant_by_stamp';
$CONFIG.moe.find_merchant_by_stamp_url = $CONFIG.moe.url+$CONFIG.moe.find_merchant_by_stamp_path;

//////////////////////////////////

////////// LOCAL SETTINGS //////////
$CONFIG.local.root_path = 'index.html';

$CONFIG.local.verification_path = $CONFIG.local.root_path;// 'verification.html';
$CONFIG.local.not_verified_path = $CONFIG.local.root_path;//'not_verified.html';

$CONFIG.local.login_path = 'login.html';
$CONFIG.local.signup_path = 'signup.html';
$CONFIG.local.forgot_password_path = 'login_forgot_password.html';

$CONFIG.local.add_merchants_path = 'find_merchant_by_stamp.html';

$CONFIG.local.sidebar_path = '_sidebar.html';

$CONFIG.local.welcome_path = 'welcome.html';
$CONFIG.local.my_merchants_path = 'my_merchants.html';
$CONFIG.local.search_merchants_path = 'search_merchants.html';
$CONFIG.local.show_merchant_path = 'show_merchant.html';
$CONFIG.local.merchant_settings_path = 'merchant_settings.html';

$CONFIG.local.merchant_menu_path = '_merchant_menu.html';
$CONFIG.local.merchant_index_menu_path = '_merchant_index_menu.html';

$CONFIG.local.scan_code_path = 'merchant_qr_code.html';
$CONFIG.local.scan_code_for_reward_path = 'merchant_qr_code_reward.html';

$CONFIG.local.enter_amount_path = 'enter_amount.html';
$CONFIG.local.enter_amount_stamp_path = 'enter_amount_visit_total_stamp_screen.html';
$CONFIG.local.enter_amount_stamp_failure_path = 'enter_amount_visit_total_failure.html';
$CONFIG.local.enter_amount_stamp_success_path = 'enter_amount_visit_total_success.html';

$CONFIG.local.reward_slider_path = 'reward_slider.html';
$CONFIG.local.reward_enter_amount_path = 'reward_enter_amount.html';
$CONFIG.local.reward_enter_items_path = 'reward_enter_items.html';

$CONFIG.local.reward_enter_amount_stamp_path = 'reward_visit_total_stamp_screen.html';
$CONFIG.local.reward_enter_amount_stamp_failure_path = 'reward_visit_total_failure.html';
$CONFIG.local.reward_enter_amount_stamp_success_path = 'reward_visit_total_success.html';

$CONFIG.local.loyalty_value_slider_path = 'loyalty_value_slider.html';
$CONFIG.local.loyalty_value_enter_amount_path = 'loyalty_value_enter_amount.html';
$CONFIG.local.loyalty_value_stamp_path = 'loyalty_value_stamp_screen.html';
$CONFIG.local.loyalty_value_stamp_failure_path = 'loyalty_value_stamp_failure.html';
$CONFIG.local.loyalty_value_stamp_success_path = 'loyalty_value_stamp_success.html';


$CONFIG.local.my_profile_menu_path = '_profile_menu.html';
$CONFIG.local.my_profile_path = 'my_profile.html';
$CONFIG.local.my_profile_phone_path = 'my_profile_phone.html?v=1';
$CONFIG.local.my_profile_email_path = 'my_profile_email.html?v=1';
$CONFIG.local.my_profile_password_path = 'my_profile_password.html?v=1';
$CONFIG.local.my_profile_birthday_path = 'my_profile_birthday.html';
$CONFIG.local.my_profile_language_path = 'my_profile_language.html';
$CONFIG.local.my_facebook_profile_path = 'my_facebook_profile.html';
$CONFIG.local.find_merchant_by_stamp_path = 'find_merchant_by_stamp.html';

$CONFIG.local.add_loyalty_card_path = 'merchant_add_loyalty_card.html';
$CONFIG.local.add_loyalty_card_success_path = 'merchant_add_loyalty_card_success.html';

// for working with camera
$CONFIG.local.picture_source = null;
$CONFIG.local.destination_type = null;
$CONFIG.local.file_system = null;
//////////////////////////////////

$CONFIG.requests_add_to_queue = false;

$CONFIG.push_notifications.sender_id = '885385952808';
$CONFIG.push_notifications.distination_to_merchant = 0.25;//km
$CONFIG.push_notifications.period_cheking_distance = 40*1000;//40 seconds
$CONFIG.push_notifications.period_sending_pn = 5 * 60 * 60 * 1000;// 5 hours

$CONFIG.db.connect = null;
$CONFIG.db.name = 'RoylMe32';
$CONFIG.db.version = '0.1';
$CONFIG.db.description = 'RoylMe db';
$CONFIG.db.size = 4*1024*1024;
