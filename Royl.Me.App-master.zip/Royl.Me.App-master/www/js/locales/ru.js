$LANG['ru'] = {
	loyalty_value: 'Бонусный баланс'
};