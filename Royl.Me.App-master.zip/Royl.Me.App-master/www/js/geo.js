function currentPositionTracker() {
	console.log('currentPositionTracker');
	navigator.geolocation.getCurrentPosition(geolocationSuccess, geolocationError);

	navigator.geolocation.watchPosition(geolocationSuccess, geolocationError, {
		maximumAge : 30000,
		enableHighAccuracy : true,
		timeout:10000
	});
}

function geolocationSuccess(position) {
	checkMerchantNearMe(position.coords.latitude, position.coords.longitude);
}

function geolocationError(error) {
	console.log('code: ' + error.code + '\n' + 'message: ' + error.message + '\n');
}

function merchantNearMeError() {
	console.log('merchantNearMeError');
}

function merchantNearMeCallback(url, type, params, result) {
	if (result.success) {
		var now = new Date();

		$CONFIG.db.connect.transaction(function(tx) {
			tx.executeSql('UPDATE merchants SET last_notification_request_at = ? WHERE merchant_id = ?', [now.getTime(), params.merchant_id], function(tx, result) {
			//	console.log('merchantNearMeCallback - success');
			}, function(tx, error) {
				console.log("Query Error: " + error.message);
			});
		});
	}
}

function checkMerchantNearMe(latitude, longitude) {
	var now = new Date();
	
	if(window.localStorage.getItem('lastCheckMerchantNearMe') && now.getTime() < parseInt(window.localStorage.getItem('lastCheckMerchantNearMe'))+$CONFIG.push_notifications.period_cheking_distance){
	  return;
	}
	
	window.localStorage.setItem('lastCheckMerchantNearMe', now.getTime());
	 
	console.log(latitude, longitude);
	 
	var my_position = new LatLon(latitude, longitude);

	dbCheckInstall();

	$CONFIG.db.connect.transaction(function(tx) {		
		var period_ago = now.getTime() - $CONFIG.push_notifications.period_sending_pn;

		tx.executeSql('SELECT * FROM merchants WHERE last_notification_request_at IS NULL OR last_notification_request_at <= ?', [period_ago], function(tx, result) {
			//console.log(result.rows.length);
			for (var i = 0; i < result.rows.length; i++) {
				var row = result.rows.item(i);

				if (row.latitude && row.latitude.length > 0 && row.longitude && row.longitude.length > 0) {

					var p2 = new LatLon(row.latitude, row.longitude);
					var distance = my_position.distanceTo(p2);
					// in km

					if (distance <= $CONFIG.push_notifications.distination_to_merchant) {
						authSignedRequest($CONFIG.moe.geo_notification_request_url, 'GET', {
							merchant_id : row.merchant_id,
							distance : distance
						}, false, 'merchantNearMeCallback', 'merchantNearMeError');
					}
				}
			}
		}, function(tx, error) {

			console.log("Query Error: " + error.message);
		});
	});

}