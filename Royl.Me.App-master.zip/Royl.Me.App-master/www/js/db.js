function dbConnect(){
	$CONFIG.db.connect =  openDatabase($CONFIG.db.name, $CONFIG.db.version, $CONFIG.db.description, $CONFIG.db.size);
	
	if(!$CONFIG.db.connect){  alert("Failed to connect to database.");  }
}

function dbCheckInstall(){
	if(!$CONFIG.db.connect){
		dbInstall();
	}
}

function dbInstall(){
	dbConnect();

	dbExSql("CREATE TABLE IF NOT EXISTS requests"+
	"(id INTEGER PRIMARY KEY AUTOINCREMENT,"+
	"identificator INTEGER, "+
	"	data TEXT, "+
	"	url VARCHAR(255), "+
	"	type VARCHAR(255), "+
	"	status VARCHAR(255))");
		
	dbExSql("CREATE TABLE IF NOT EXISTS consumers"+
	"(id INTEGER PRIMARY KEY AUTOINCREMENT,"+
	"consumer_id INTEGER, "+
	"	login VARCHAR(255), "+
	"	email VARCHAR(255), "+
	"	unconfirmed_email VARCHAR(255), "+
	"	phone VARCHAR(255), "+
	"	first_name VARCHAR(255), "+
	"	last_name VARCHAR(255), "+
	"	name VARCHAR(255), "+
	"	birthday VARCHAR(255), "+
	"	locale VARCHAR(255), "+
	"	formatted_account_number VARCHAR(255), "+
	"	account_number VARCHAR(255), "+
	"	facebook_id VARCHAR(255), "+
	"	updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, "+
	 
	"	auth_token VARCHAR(255))");
	
	dbExSql("CREATE TRIGGER IF NOT EXISTS last_update_trigger "+
	"	AFTER UPDATE "+
	"	ON consumers "+
	"	BEGIN "+
 	"	   UPDATE consumers SET updated_at = datetime('now') WHERE id = NEW.id; "+
	"	END; ");
     
      
	dbExSql("CREATE TABLE IF NOT EXISTS merchants"+
	"(id INTEGER PRIMARY KEY AUTOINCREMENT,"+
	"merchant_id INTEGER, "+
	"	favorite BOOLEAN, "+
	"	send_sms BOOLEAN, "+
	"	send_email BOOLEAN, "+
	"	send_push_notification BOOLEAN, "+
	"	count_rewards INTEGER, "+
	"	count_ss_rewards INTEGER, "+
	"	points_balance INTEGER, "+
	"	loyl_me_loyalty_value FLOAT, "+
	"	count_daily_deal_coupons INTEGER, "+
	"	buyx_items_balance INTEGER, "+
	"	name VARCHAR(255), "+
	"	logo VARCHAR(255), "+
	"	website VARCHAR(255), "+
	"	address VARCHAR(255), "+
	"	country VARCHAR(255), "+
	"	state VARCHAR(255), "+
	"	zip_code VARCHAR(255), "+
	"	city VARCHAR(255), "+
	"	time_zone VARCHAR(255), "+
	"	cover_image VARCHAR(255), "+
	"	latitude VARCHAR(255), "+
	"	longitude VARCHAR(255), "+
	"	last_notification_request_at VARCHAR(255), "+	
	"	count_coupons INTEGER)");
}


function dbExSql(sql, args, successResult, errorResult){
	dbCheckInstall();
	
	if(!args) args = [];
	
	$CONFIG.db.connect.transaction(function(tx) {
    tx.executeSql(sql, args, 
    	function(tx, result){
    		
      	if(successResult){
      	  eval(successResult+"(result)");
      	};
     }, 
     function(tx, error){
     	console.log(sql, error);
     	  if(errorResult) eval(errorResult+"(error)");
     });
  });
}


//document.addEventListener("deviceready", dbInstall, false);