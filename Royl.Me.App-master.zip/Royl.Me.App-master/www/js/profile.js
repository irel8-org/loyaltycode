function profileShow() {
	var uri;
	// = window.localStorage.getItem("consumer_local_avatar");
	if (!uri && window.localStorage.getItem("consumer_avatar")) {
		uri = $CONFIG.moe.url + window.localStorage.getItem("consumer_avatar");
	}

	if (!uri) {
		uri = "images/profile/placeholder.png";
	}

	var html = templateReplaceVars($('.mainContent').html(), {
		avatar : uri,
		name : window.localStorage.getItem("consumer_name") || ''
	});
	$('.mainContent').html(html);

	setBackObserve();

	profileSetMenu();

	closePreloader();
}

function profileFacebookLinkSuccess(url, type, params, data) {

	authSetConsumerData(data);
	
	document.location.reload();
}
function profileFacebookLinkError() {
	alert($LOCALE.get('facebook_not_linked'));
}

function profileFacebookShow() {
	var facebook_id = window.localStorage.getItem("consumer_facebook_id");
	
	var linked = facebook_id && facebook_id.length > 0;
		
	var html = templateReplaceVars($('.mainContent').html(), {
		 already_linked : linked ? $LOCALE.get('facebook_already_linked') : ''
		 });
 		
	 $('.mainContent').html(html);
	 
	 if(linked) $('#facebook-link-button').hide();
	 
	 closePreloader();
	
	// facebookConnectPlugin.getLoginStatus(function(response) {
		// var linked = response['status'] != "unknown";
// 		
		// var html = templateReplaceVars($('.mainContent').html(), {
			// already_linked : linked ? $LOCALE.get('facebook_already_linked') : ''
		// });
// 		
		// $('.mainContent').html(html);
		// if(linked) $('#facebook-link-button').hide();
		// closePreloader();
	// }, function(response) {
		// var html = templateReplaceVars($('.mainContent').html(), {
			// already_linked : ''
		// });
		// $('.mainContent').html(html);
		// closePreloader();
	// });
// }
}
function profileShowPhone() {
	var phone = window.localStorage.getItem("consumer_phone");
	if (phone == 'null')
		phone = '';
	//temp fix

	var html = templateReplaceVars($('.mainContent').html(), {
		phone : phone
	});
	$('.mainContent').html(html);

	setBackObserve();

	profileSetMenu('phone');
	formsSetEvents('smart-form-delay');

	closePreloader();
}

function profileShowLanguage() {
	localeStandartControll();

	$('[name="consumer[locale]"]').val($CONFIG.locale.current);

	setBackObserve();
	profileSetMenu('language');
	formsSetEvents();

	closePreloader();
}

function profileShowEmail() {
	var html = templateReplaceVars($('.mainContent').html(), {
		email : window.localStorage.getItem("consumer_email")
	});
	$('.mainContent').html(html);

	setBackObserve();
	profileSetMenu('email');
	formsSetEvents();

	closePreloader();
}

function profileBirthdayBeforeCall() {
	$('[name="consumer[birthday]"]').val($('[name="consumer[year]"]').val() + '-' + $('[name="consumer[month]"]').val() + '-' + $('[name="consumer[day]"]').val());
}

function profileShowBday() {
	localeStandartControll();
	formsSetEvents();

	var birthday = window.localStorage.getItem("consumer_birthday");

	if (birthday && ( birthday = birthday.match(/(\d{4})-(\d{2})-(\d{2})/) ).length == 4) {
		$('[name="consumer[day]"]').val(birthday[3]);
		$('[name="consumer[month]"]').val(birthday[2]);
		$('[name="consumer[year]"]').val(birthday[1]);
	}

	profileSetMenu('birthday');
	//formsSetEvents();
}

function profileSetMenu(part) {
	if (part == undefined) {
		part = 'profile';
	}
	$.ajax({
		url : $CONFIG.local.my_profile_menu_path,
		success : function(data) {
			data = templateReplaceVars(data, {}, true);
			if ($('.footer').length > 0) {
				$('.footer').replaceWith(data);
			} else {
				$('.mainContent').append(data);
			}

			$('#profile-menu-' + part).removeClass('highlight-color-1');
		},
		dataType : 'html'
	});
}

function profileUpdated(data) {
	if(data.success){
		window.localStorage.setItem("consumer_phone", data.consumer.mobile_number);
		window.localStorage.setItem("consumer_email", data.consumer.email);
		window.localStorage.setItem("consumer_birthday", data.consumer.birthday);
		window.localStorage.setItem("consumer_locale", data.consumer.locale);
	
		var $field = $('form input[type=text]:last').length > 0 ? $('form input[type=text]:last') : ($('form input[type=password]:last').length > 0 ? $('form input[type=password]:last') : $('form select:last'));
		$field.siblings('.error-message').remove();
	
		if ($field.siblings('.success-message').length == 0) {
			$field.after('<span class="success-message"></span>');
		}
	
		$field.siblings('.success-message').html($LOCALE.get('successfully_updated'));
	} else {
		profileNotUpdated(data);
	}
}

function profileNotUpdated(data) {
	var $field = $('form input[type=text]:last');
	$field.siblings('.success-message').remove();

	if ($field.siblings('.error-message').length == 0) {
		$field.after('<span class="error-message"></span>');
	}

	$field.siblings('.error-message').html(data.error_message.join(' ' + $LOCALE.get('and') + ' ')).show();
}
