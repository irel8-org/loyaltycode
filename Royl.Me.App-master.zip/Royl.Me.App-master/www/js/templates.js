function templateReplaceVars(template, object, only_locales) {
	if(!template) return '';
	var mtch = template.match(/#\{([^}])*\}/g);
	
	if(only_locales == undefined) only_locales = false;

	if (mtch && mtch.length > 0) {
		for (i in mtch) {
			var replacement;
			var replace = false;
			
			if(mtch[i].match(/locale\./)){
			  replacement = $LOCALE.get(mtch[i].replace(/#\{|(locale\.)|\}/g,''));
			  replace = true;
			} else if(!only_locales) {
			  replacement = object[mtch[i].replace(/#\{|\}/g, '')];
			  replace = true;
			}
			
			if(replace){
			  replacement = replacement ? replacement : '';
			
			  template = template.replace(mtch[i], replacement);
			}
		}
	}
	
	return only_locales ? template : template.replace(/(class=('|")[^'"]*)hidden/, '$1').replace('template', '');
}
