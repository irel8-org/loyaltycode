$_DEVICE = {};
$_READY = false;

var version = (new Date()).getTime();//1
//
//console.log('version:'+version)

//.script("plugins/org.apache.cordova.geolocation/www/Coordinates.js'></script>");
//.script("plugins/org.apache.cordova.geolocation/www/geolocation.js'></script>");
//.script("plugins/org.apache.cordova.geolocation/www/Position.js'></script>");
//.script("plugins/org.apache.cordova.geolocation/www/PositionError.js'></script>");
//document.writeln("<script type='text/javascript' src='http://debug.build.phonegap.com/target/target-script-min.js#c261787e-34c6-11e3-803e-22000a98b3d6'></script>");

$LAB  
	.script("cordova.js");
	
$LAB  
  .script("js/jquery.min.js?version="+version).wait()
 	.script("js/config.js?version="+version).wait()
	.script("js/locale.js?version="+version).wait()
	.script("js/db.js?version="+version)
	.script("js/PushNotification.js?version="+version).wait()
	.script("js/push_notifications.js?version="+version)
	.script("js/jquery-ui-min.js?version="+version)
	.script("js/colorbox.js?version="+version)
	.script("js/hammer.js?version="+version)
	.script("js/swipe.js?version="+version)
	.script("js/swipebox.js?version="+version)
	.script("js/retina.js?version="+version)
	.script("js/requests.js?version="+version)
	.script("js/templates.js?version="+version)
	.script("js/forms.js?version="+version)
	.script("js/camera.js?version="+version)
	.script("js/facebook.js?version="+version)
	.script("js/auth.js?version="+version)
	.script("js/merchants.js?version="+version)
	.script("js/profile.js?version="+version)
	.script("js/custom.js?version="+version)
	.script("js/reward.js?version="+version)
	.script("js/loyalty_value.js?version="+version)
	.script("js/framework.js?version="+version)
	.script("js/bootstrap.js?version="+version)
	.script("js/rainbow/rainbow.min.js?version="+version)
	.script("js/customer.js?version="+version)
	.script("js/qrcode/jquery.qrcode.js?version="+version)
	.script("js/qrcode/qrcode.js?version="+version)

.wait(function(){	
	$(function() { 
		document.addEventListener('deviceready', app_init, false);
		
		try {
			pageInit();

		} catch(e) {
			error_occurred(e);
		}
		});
});


//.script("js/geoLib.js?version="+version)
//.script("js/geo.js?version="+version)



function lost_connection(error_on_server) {
	var cont = $('.lost-connection');
	
	if(cont.length > 0){
		cont.html($LOCALE.get('lost_connection')).show();
	} else {
		$('body').prepend('<div class="lost-connection"><div>'+$LOCALE.get('lost_connection')+'<button class="btn btn-large background-color-1 background-color-hover-1" onclick="document.location.reload()">Check Again</button></div></div>');
	}  
}


function app_init() {
//	console.log('app_init'+version)

	onDeviceReadyPushNotification();
	
//	currentPositionTracker();

	$_DEVICE = device;

	dbCheckInstall();
	
	console.log(navigator);

	if (document.location.href.match(/my_profile.html/)) {
		cameraOnDeviceReady();
	}
	
	requestsSendFromQueue();
}

function error_occurred(e, message) {
	console.log(e, message);
	
	var error_occurred_num = $.urlParam('error_occurred') ? parseInt($.urlParam('error_occurred')) : 0;
	
	var redirect = true;
	if (error_occurred_num <= 3) {
		alert(message || $CONFIG.error_message);
		document.location.href = $CONFIG.local.root_path + '?error_occurred=' + (error_occurred_num + 1);
	} else {
		alert($CONFIG.second_error_message);
		redirect = false;
	}
	
	authCleanConsumerDataAndRedirect(!redirect, '?error_occurred=' + (error_occurred_num + 1));
}