var facebookLogin = function(button) {
	if ($(button).hasClass('wait'))
		return;

	$(button).addClass('wait').attr('disabled', true);

	showPreloader(false);

	if (!window.cordova) {
		var appId = prompt("Enter FB Application ID", "");
		facebookConnectPlugin.browserInit(appId);
	}

	facebookConnectPlugin.login(["email"], function(response) {
		if (!$(button).hasClass('request')) {
			$(button).addClass('request');
			response['facebook_auth_token'] = response['authResponse']['accessToken'];

			var device_attrs = authDeviceAttributes();

			jQuery.extend(response, device_attrs);

			$.ajax({
				type : 'POST',
				url : $CONFIG.moe.facebook_session_create_url,
				data : response,
				async : false,
				success : function(data) {
					console.log(data);
					if (data.error_code == 'wrong_credentials') {
						alert($LOCALE.get('facebook_login_problem'));
					} else {
						authConsumer(data);
					}

				},
				error : function(xhr, status, error) {
					alert($LOCALE.get('facebook_login_problem'));
					closePreloader();
					$(button).removeClass('wait').removeClass('request').attr('disabled', false);
				}
			});
		} else{
			closePreloader();
			$(button).removeClass('wait').removeClass('request').attr('disabled', false);
		}

	}, function(response) {
		alert(JSON.stringify(response));
		closePreloader();
		$(button).removeClass('wait').removeClass('request').attr('disabled', false);
	});
};

var facebookSignUp = function() {
	facebookConnectPlugin.login(["email"], function(response1) {
		facebookConnectPlugin.api("me", ["user_birthday"], function(response) {
			$('#form-field-email').val(response['email']).hide();
			$('#form-field-first-name').val(response['first_name']).hide();
			$('#form-field-last-name').val(response['last_name']).hide();
			$('#consumer-locale-field').val(response['locale'].split('_')[0]);
			$('#facebook-sign-up button').html('Facebook: ' + response['name']);
			$('#facebook-sign-up input').val(response1['authResponse']['accessToken']);
			$('#form-field-password').val(response1['authResponse']['accessToken'].substr(0, 120)).hide();
			$('#sign_up_via_fb_or').hide();
		}, function(response) {
			alert(JSON.stringify(response));
		});

	}, function(response) {
		alert(JSON.stringify(response));
	});
};

var facebookLink = function(successFunc, errorFunc, button) {
	if ($(button).hasClass('wait'))
		return;

	$(button).addClass('wait').attr('disabled', true);

	facebookConnectPlugin.login(["email"], function(response) {
		if (!$(button).hasClass('request')) {
			$(button).addClass('request');

			authSignedRequest($CONFIG.moe.link_to_facebook_consumer_url.replace(/_CONSUMER_ID_/, window.localStorage.getItem("consumer_id")), 'POST', {
				facebook_auth_token : response['authResponse']['accessToken']
			}, false, successFunc, errorFunc);
		}
	}, function(response) {
		alert(JSON.stringify(response));
		$(button).removeClass('wait').removeClass('request').attr('disabled', false);
	});
};

var facebookGetAccessToken = function() {
	facebookConnectPlugin.getAccessToken(function(response) {
		alert(JSON.stringify(response));
	}, function(response) {
		alert(JSON.stringify(response));
	});
};

var facebookGetStatus = function() {
	facebookConnectPlugin.getLoginStatus(function(response) {
		alert(JSON.stringify(response));
	}, function(response) {
		alert(JSON.stringify(response));
	});
};

var facebookLogout = function() {
	facebookConnectPlugin.logout(function(response) {
		alert(JSON.stringify(response));
	}, function(response) {
		alert(JSON.stringify(response));
	});
};

//
// var showDialog = function () {
// facebookConnectPlugin.showDialog( { method: "feed" },
// function (response) { alert(JSON.stringify(response)) },
// function (response) { alert(JSON.stringify(response)) });
// }
//
// var apiTest = function () {
// facebookConnectPlugin.api( "me/?fields=id,email", ["user_birthday"],
// function (response) { alert(JSON.stringify(response)) },
// function (response) { alert(JSON.stringify(response)) });
// }
// var logPurchase = function () {
// facebookConnectPlugin.logPurchase(1.99, "USD",
// function (response) { alert(JSON.stringify(response)) },
// function (response) { alert(JSON.stringify(response)) });
// }
// var logEvent = function () {
// // For more information on AppEvent param structure see
// // https://developers.facebook.com/docs/ios/app-events
// // https://developers.facebook.com/docs/android/app-events
// facebookConnectPlugin.logEvent("Purchased",
// {
// NumItems: 1,
// Currency: "USD",
// ContentType: "shoes",
// ContentID: "HDFU-8452"
// }, null,
// function (response) { alert(JSON.stringify(response)) },
// function (response) { alert(JSON.stringify(response)) });
// }
