function authCleanConsumerData() {
	window.localStorage.removeItem("auth_token");
	window.localStorage.removeItem("consumer_id");
	window.localStorage.removeItem("consumer_email");
	window.localStorage.removeItem("consumer_unconfirmed_email");	
	window.localStorage.removeItem("consumer_login");
	window.localStorage.removeItem("consumer_avatar");
	window.localStorage.removeItem("consumer_phone");
	window.localStorage.removeItem("consumer_birthday");
	window.localStorage.removeItem("consumer_first_name");
	window.localStorage.removeItem("consumer_last_name");
	window.localStorage.removeItem("consumer_name");
	window.localStorage.removeItem("consumer_locale");
	window.localStorage.removeItem("consumer_formatted_account_number");
	window.localStorage.removeItem("consumer_account_number");
	window.localStorage.removeItem("consumer_facebook_id");
}

function authDeviceAttributes() {
	if(!$_DEVICE) return {};
	
	return {device: {model: $_DEVICE.model, platform: $_DEVICE.platform, uuid: $_DEVICE.uuid, version: $_DEVICE.version, token: window.localStorage.getItem("device_token")}};
}

function authCleanConsumerDataAndRedirect(not_redirect, additional_params) {
  var consumer_id = window.localStorage.getItem("consumer_id");

	authCleanConsumerData();
  
  var url = $CONFIG.local.root_path;
  if(additional_params && additional_params.match(/\?/)) url = url+additional_params;
  
  if (consumer_id){
	  dbCheckInstall();
	 
	  $CONFIG.db.connect.transaction(function(tx) {
	 
    tx.executeSql('UPDATE consumers SET auth_token = "" ',[],// WHERE consumer_id = ?', [consumer_id],
    	function(tx, result){
    
        if(not_redirect===true){ //something 
        	}else{ document.location.href = url; }
       }, 
       function(tx, result){console.log(result);alert('oops');});
     });
	} else {
		if(not_redirect===true){  //something 
			}else{  document.location.href = url; }
	}
}

function authSetConsumerLocalData(data){
	window.localStorage.setItem("auth_token", data.auth_token);
	window.localStorage.setItem("consumer_id", data.consumer.id);
	window.localStorage.setItem("consumer_email", data.consumer.email || '');
	window.localStorage.setItem("consumer_unconfirmed_email", data.consumer.unconfirmed_email || '');	
	window.localStorage.setItem("consumer_login", data.consumer.login || '');
	window.localStorage.setItem("consumer_phone", data.consumer.mobile_number || '');
	window.localStorage.setItem("consumer_first_name", data.consumer.first_name || '');
	window.localStorage.setItem("consumer_last_name", data.consumer.last_name || '');
	window.localStorage.setItem("consumer_name", data.consumer.name || '');
	window.localStorage.setItem("consumer_locale", data.consumer.locale || '');
	window.localStorage.setItem("consumer_formatted_account_number", data.consumer.formatted_account_number || '');
  window.localStorage.setItem("consumer_account_number", data.consumer.account_number || '');
  window.localStorage.setItem("consumer_facebook_id", data.consumer.facebook_id || '');  

	if (data.consumer.birthday && data.consumer.birthday.match(/\d{4}-\d{2}-\d{2}/)) {
		window.localStorage.setItem("consumer_birthday", data.consumer.birthday);
	}

	authSetConsumerAvatar(data);
}

function authInsertOrUpdateConsumer(data, res, not_redirect){	
	if(not_redirect == undefined)
	  not_redirect = false;
	  
	if (res) {
			sql = 'UPDATE consumers SET auth_token = ?, email = ?, unconfirmed_email = ?, login = ?, phone = ?, first_name = ?, last_name = ?, name = ?, locale = ?, formatted_account_number = ?, account_number = ?, facebook_id = ? WHERE id = ?';
			args = [data.auth_token, data.consumer.email, data.consumer.unconfirmed_email, data.consumer.login, data.consumer.mobile_number, data.consumer.first_name, data.consumer.last_name, data.consumer.name, data.consumer.locale, data.consumer.formatted_account_number, data.consumer.account_number, data.consumer.facebook_id, res.id];
		} else {
	  	sql = 'INSERT INTO consumers (consumer_id, auth_token, email, unconfirmed_email, login, phone, first_name, last_name, name, locale, formatted_account_number, account_number, facebook_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
	  	args = [data.consumer.id, data.auth_token, data.consumer.email, data.consumer.unconfirmed_email, data.consumer.login, data.consumer.mobile_number, data.consumer.first_name, data.consumer.last_name, data.consumer.name, data.consumer.locale, data.consumer.formatted_account_number, data.consumer.account_number, data.consumer.facebook_id];
		}
		
	  $CONFIG.db.connect.transaction(function(tx) {
	  	tx.executeSql(sql, args, function(tx, result){ 
	  		  authSetConsumerLocalData(data);
          if(!not_redirect) authAlreadyLogged();
  			},  function(tx, error){
     	   console.log(error);
        });	
  	});
  	
}

function authSetConsumerData(data, update_db, not_redirect) {
	if (update_db == undefined)
		update_db = true;

	if (update_db && data && data.consumer) {
		var sql, args;
		
		dbCheckInstall();
		
		if(data.consumer.id){
		  $CONFIG.db.connect.transaction(function(tx) {
	  	  tx.executeSql('SELECT * FROM consumers WHERE consumer_id = ?', [data.consumer.id], function(tx, result){
	  	   
	  	    authInsertOrUpdateConsumer(data, result.rows.length > 0 && result.rows.item(result.rows.length-1), not_redirect);
	  	  },  function(tx, error){
     	   console.log(error);
        });	
  	  });	
		} else {
			authInsertOrUpdateConsumer(data);
		}
		
		authSetConsumerLocalData(data);	
		
	} else {
		authSetConsumerLocalData(data);
		authAlreadyLogged();
	}
}

function authSetConsumerAvatar(data) {
	if (data && data.consumer.photo_exist && data.consumer.photo && data.consumer.photo.photo && data.consumer.photo.photo.view && data.consumer.photo.photo.view.url) {
		window.localStorage.setItem("consumer_avatar", data.consumer.photo.photo.view.url);
	} else {
		window.localStorage.removeItem("consumer_avatar");
	}
}

function authUpdateConsumerDataSuccess(url, type, params, result){
	result.consumer = result;
	result.auth_token = window.localStorage.getItem("auth_token");
	authSetConsumerData(result, true, true);
}
function authUpdateConsumerData(){	
	authSignedRequest($CONFIG.moe.prepared_show_consumer_url, 'GET', {}, false, 'authUpdateConsumerDataSuccess');
}

// callback after sending credentials to MOE server
function authConsumer(data) {	
	 
	if(!data){
		error_occurred();
		return;
	}
	
	if (data.success == true) {
		
		authSetConsumerData(data);
	} else {
		authCleanConsumerData();
		if (data.error_code == 'wrong_credentials') {
			$('.form-item input').each(function() {
				if ($(this).val().length > 0) {
					addErrorToField($(this), $LOCALE.get('wrong_credentials'));
				}
			});
		} else if (data.error_code == 'missing_attributes') {
			addErrorToField($('.form-item input'), data.error_message);
		} else{
			error_occurred();
		}
	}
}

function authPasswordChange(data) {
	if (data.success == true) {
		authSetConsumerData(data);
	} else {
		if (data.error_code == 'invalid_sms_code') {
			addErrorToField($('.form-item input[name=code]'), data.error_message);
		} else if (data.error_code = 'invalid_consumer_params') {
			addErrorToField($('.form-item input[name=password]'), data.error_message);
		}
	}
}

// callback after sign up in MOE server
function authSingUpConsumer(data) {
	if (data.success == true) {
		authSetConsumerData(data);
	} else {
		authCleanConsumerData();

		if (data.error_code == 'wrong_data') {
			for (var i in data.error_message) {
				if (data.error_message.hasOwnProperty(i)) {
					addErrorToField($('.form-item input[name="consumer[' + i + ']"]'), data.error_message[i].join(' and '));
				}
			}
		} else {
			addErrorToField($('.form-item input'), data.error_message);
		}
	}
}

function authSetConsumerDataFromDb(successCallback){
 if (!window.localStorage.getItem("auth_token")) {
		var data = null;		
		
		dbCheckInstall();
		
		consumer_id = window.localStorage.getItem("consumer_id");		

    $CONFIG.db.connect.transaction(function(tx) {
    tx.executeSql("SELECT * FROM consumers "+(consumer_id ? 'WHERE consumer_id = ?' : '')+" ORDER BY updated_at", consumer_id ? [consumer_id] : [],
	  
		  function(tx, res){
		  	if(res.rows.length > 0 && (res = res.rows.item(res.rows.length-1))){
			  	data = {};
					data.consumer = {};
			
					data.auth_token = res.auth_token;
					data.consumer.email = res.email;
					data.consumer.unconfirmed_email = res.unconfirmed_email;
					data.consumer.login = res.login;
					data.consumer.mobile_number = res.phone;
					data.consumer.first_name = res.first_name;
					data.consumer.last_name = res.last_name;
					data.consumer.name = res.name;
					data.consumer.id = res.consumer_id;
					data.consumer.formatted_account_number = res.formatted_account_number;
					data.consumer.account_number = res.account_number;
					data.consumer.facebook_id = res.facebook_id;					
					
					authSetConsumerData(data, false);
					
					if(successCallback) eval(successCallback+'(data)');
				}
		  });	
	  });	
			
	}
}

function authIsLogged() {
	return !!window.localStorage.getItem("auth_token");
}

function authAlreadyLogged(check_for_verification) {
	check_for_verification = check_for_verification && !$.urlParam('not_check_for_verification');
	
	if (authIsLogged()) {
		document.location.href = $CONFIG.local.welcome_path;
	} else if(check_for_verification && $CONFIG.verify_first_use){
	  dbCheckInstall();
		
	  $CONFIG.db.connect.transaction(function(tx) {
  	  tx.executeSql('SELECT * FROM consumers', [], function(tx, result){  	   
  	    if(result.rows.length == 0){
  	    	document.location.href = $CONFIG.local.verification_path;
  	    }
  	    
  	  },  function(tx, error){
   	    console.log(error);
      });	
	  });	
	}
}

function authRedirectNotAuthorized() {
	//document.location.href = $CONFIG.local.root_path;
	error_occurred(null, $CONFIG.error_message_should_be_authorized);
}

function authShouldBeAuthorized() {
	if (!authIsLogged()) {
		authRedirectNotAuthorized();
	}
}

function authSignOutLocal(){
	
	authCleanConsumerDataAndRedirect();
}
function authSignOut() {
	authSignedRequest($CONFIG.moe.session_destroy_url.replace(/_CONSUMER_ID_/, window.localStorage.getItem("consumer_id")), 'POST', {}, false, 'authSignOutLocal', 'authCleanConsumerDataAndRedirect');
}

// sending request to MOE server with auth token
function authSignedRequest(url, type, params, async, callback, errorCallback) {
	if (async == undefined)
		async = false;

	params = params == undefined ? new Object : params;
	
	authShouldBeAuthorized();
	
	params.auth_token = window.localStorage.getItem("auth_token");
	params.reseller_id = $CONFIG.moe.reseller_id;
	params.without_reseller_ids = $CONFIG.moe.without_reseller_ids;
	params.api_version = $CONFIG.moe.api_version;
	params.debug_code = $CONFIG.debug_code;
	
	var device_attrs = authDeviceAttributes();
	
	jQuery.extend(params, device_attrs);
	
	type = type == undefined ? 'GET' : type;
	var result;

	$.ajax({
		type : type,
		url : url,
		data : params,
		async : async,
		success : function(data) {
			result = data;
			if(result.status == 401){
				alert($LOCALE.get('your_session_is_expired_pls_authorize_again'));
				authCleanConsumerDataAndRedirect();
			} else if (callback) {
				eval(callback + '(url, type, params, result)');
			}
		},
		error: function(xhr, status, error) {
			if(status=="timeout" || error.name == 'TimeoutError'){
				lost_connection();
			} else if (errorCallback) {
				result = eval(errorCallback + '(url, type, params, error)');
			} else {
		  	//authCleanConsumerDataAndRedirect(true);
		  	lost_connection(true);
		  	//error_occurred(error);		    
		  }
		}
		}
		);
	//var t;
//return t;//todo remove
	return result;
}

function authShowLogin() {
	var set_default_data = false;
	
	localeStandartControll();
	formsSetEvents();
	
	if ($.urlParam('login') && $.urlParam('login') != 'null') {
		$('input[name=login]').val($.urlParam('login'));
		addErrorToField($('input[name=login]'), 'wrong credentials');
	} else if(window.localStorage.getItem("consumer_login") && window.localStorage.getItem("consumer_login").length > 0) {
		set_default_data = true;
		$('input[name=login]').val(window.localStorage.getItem("consumer_login"));
	}
	
	if ($.urlParam('mobile_number') && $.urlParam('mobile_number') != 'null') {
		$('input[name=mobile_number]').val($.urlParam('mobile_number'));
		addErrorToField($('input[name=mobile_number]'), 'wrong credentials');
	} else if(!set_default_data && window.localStorage.getItem("consumer_phone") && window.localStorage.getItem("consumer_phone").length > 0) {
		set_default_data = true;
		$('input[name=mobile_number]').val(window.localStorage.getItem("consumer_phone"));
	}
	if ($.urlParam('email') && $.urlParam('email') != 'null') {
		$('input[name=email]').val($.urlParam('email'));
		addErrorToField($('input[name=email]'), 'wrong credentials');
	} else  if(!set_default_data && window.localStorage.getItem("consumer_email") && window.localStorage.getItem("consumer_email").length > 0) {
		set_default_data = true;
		$('input[name=email]').val(window.localStorage.getItem("consumer_email"));
	}
}

function authShowResetPasswordCode() {
  if ($.urlParam('login')){
		$('input[name=login]').val($.urlParam('login'));
	}
	if ($.urlParam('mobile_number')){
		$('input[name=mobile_number]').val($.urlParam('mobile_number'));
	}
	if ($.urlParam('email')){
		$('input[name=email]').val($.urlParam('email'));
	}
	
					
	localeStandartControll();
	formsSetEvents();
}
function authSendResetPasswordCode(button) {
	authCleanConsumerData();
	
	$("#resend-result").html('').attr('class', '');
	var last_sent = $(button).attr('last-sent');

	var ts = new Date().getTime();

	if (last_sent && (ts - last_sent) / 1000 < 60) {
		$("#resend-result").html($LOCALE.get('you_can_request_a_reset_code_once')).addClass('error');
		return;
	}

	$(button).attr('last-sent', new Date().getTime());
	$(button).val($(button).attr('data-wait'));

	var data = {};

	if ($.urlParam('login')){
		data.login = $.urlParam('login');
	}
	if ($.urlParam('mobile_number')){
		data.mobile_number = $.urlParam('mobile_number');
	}
	if ($.urlParam('email')){
		data.email = $.urlParam('email');
	}

	$.ajax({
		type : 'POST',
		url : $CONFIG.moe.reset_password_code_url,
		data : data,
		async : false,
		success : function(res) {
			window.localStorage.setItem("consumer_id", res.consumer_id);
		},
		complete : function(e, xhr, settings) {
			$("#resend-result").html('code successfully resent');
			$(button).val($(button).attr('data-value'));
			if (e.status == 400 || e.status == 0) {
				// document.location.href = $CONFIG.local.login_path+
				// '?login='+$.urlParam('login')+
				// '&mobile_number='+$.urlParam('mobile_number')+
				// '&email='+$.urlParam('email');
			}
		}
	});
}

function authForgotLinkClick() {
	if ($("#checkbox-1").prop('checked')) {
		$('#form-field-password').val('Password');
		if (!validForm($('.smart-form'))) {
			for (i in formErrors) {
				if (i != 'form-field-password')
					addErrorToField($('#' + i), formErrors[i].join(' and '));
			}
			return false;
		}

		document.location.href = $CONFIG.local.forgot_password_path + '?login=' + $('input[name=login]').val() + '&mobile_number=' + $('input[name=mobile_number]').val() + '&email=' + $('input[name=email]').val();
	} else {
		document.location.href = $CONFIG.local.root_path;
	}
}
