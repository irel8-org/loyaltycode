//////////////////
//Site Preloader//
///////////////////

function setToggleElements(i) {
	if (!i) i = 1;

	$('.show-toggle-v' + i).hide();
	$('.toggle-content-v' + i).hide();
	
	$('.show-toggle-v' + i).click(function() {
		$(this).hide();
		$(this).parent().find('.hide-toggle-v' + i).show();
		$(this).parent().find('.toggle-content-v' + i).fadeOut(100);
		return false;
	});
	$('.hide-toggle-v' + i).click(function() {
		$(this).parent().find('.show-toggle-v' + i).show();
		$(this).hide();
		$(this).parent().find('.toggle-content-v' + i).fadeIn(200);
		return false;
	});
}

function setToggleAs(mcont, num, checked) {
  mcont.find('li.'+num).find('.toggle').removeClass('wait');
  
	if(checked) {
		mcont.find('li.'+num).find('.sub.off').addClass('hidden');
		mcont.find('li.'+num).find('.sub.on').removeClass('hidden');
		mcont.find('li.'+num).removeClass('toggle-cont-off').addClass('toggle-cont-on');
		mcont.find('li.'+num).find('.toggle').removeClass('toggle-off').addClass('toggle-on');
		mcont.find('li.'+num).find('input').attr('checked', true);
	} else {
		mcont.find('li.'+num).find('.sub.off').removeClass('hidden');
		mcont.find('li.'+num).find('.sub.on').addClass('hidden');
		mcont.find('li.'+num).removeClass('toggle-cont-on').addClass('toggle-cont-off');
		mcont.find('li.'+num).find('.toggle').removeClass('toggle-on').addClass('toggle-off');
		mcont.find('li.'+num).find('input').attr('checked', false);
	}
}

function setToggleCheckBoxs(callback, with_wait) {
	$('.toggle').click(function() {
		if(with_wait == undefined || with_wait)
		  $(this).addClass('wait');
		$(this).toggleClass('toggle-off').toggleClass('toggle-on');
		
		var li = $(this).parents('li').first();
		
		li.toggleClass('toggle-cont-off').toggleClass('toggle-cont-on');
		li.find('input').attr('checked', $(this).hasClass('toggle-on'));
		li.find('.sub').toggleClass('hidden');
		
		if(callback){ eval(callback+'(this)'); }
	});
}

function preparePreloader() {
	$('#status p').html(templateReplaceVars($('#status p').html(), {}, true));
}
function showPreloader(not_prepare) {
	if(!not_prepare) preparePreloader();
	
	$("#status").show();	
	$("#preloader").show();
}

function closePreloader() {	
	// will first fade out the loading animation
	$("#status").fadeOut();
	// will fade out the white DIV that covers the website.
	$("#preloader").delay(350).fadeOut("slow");
}

function setSlider() {
	//Do not use var to declare position li! It will crash other pages!
	var slider = Swipe(document.getElementById('slider'), {
		startSlide : 0,
		speed : 400,
		auto : false,
		continuous : true,
		disableScroll : false,
		stopPropagation : false,
		callback : function(pos) {
			var i = $('#position li').length;
			while (i--) {
				$('#position li')[i].className = ' ';
			}
			$('#position li')[pos].className = 'on';
		}
	});

	$('#position li').click(function() {
		slider.slide($(this).index());
	});

	$('.next-but-swipe').click(function() {
		slider.prev();
		return false;
	});

	$('.prev-but-swipe').click(function() {
		slider.next();
		return false;
	});

}

function headerControll(){
	setTimeout(function() {
  	window.scrollTo(document.body.scrollLeft, document.body.scrollTop);
	}, 0);
}

$(window).load(function() {// makes sure the whole site is loaded
	preparePreloader();
	if (!$('body').data('custom-preloader-close')) closePreloader();
});

$(document).ready(function() {
	
	preparePreloader();
	if (!$('body').data('custom-preloader-close')) closePreloader();
	
	setSlider();

	$(document).on('blur', 'input, textarea', function() {
	  headerControll();
	});
	//////////////////////
	//////////////////////
	//Touch Enabled Stuf//
	//////////////////////
	//////////////////////

	//Tap Dismiss

	$(".tap-dismiss").hammer({
		drag_max_touches : 0,
	}).on("tap", function() {
		$(this).fadeOut(500);
	});

	//Double tap dimiss

	$(".double-tap-dismiss").hammer({
		drag_max_touches : 0,
	}).on("doubletap", function() {
		$(this).fadeOut(500);
	});

	//Swipe to tick swipe to cross tap to clear

	$('.swipe-tick-cross-left').click(function() {
		return false;
	});
	$(".swipe-tick-cross-left").hammer({
		drag_max_touches : 0,
	}).on("dragleft", function(ev) {
		var touches = ev.gesture.touches;
		ev.gesture.preventDefault();
		$(this).css("background-color", "#ffdcdd");
		$(this).find(".swipe-check-box").show();
		$(this).find(".swipe-tick-box").hide();
		$(this).find(".swipe-null-box").hide();
	}).on("dragright", function(ev) {
		var touches = ev.gesture.touches;
		ev.gesture.preventDefault();
		$(this).css("background-color", "#e3ffdc");
		$(this).find(".swipe-check-box").hide();
		$(this).find(".swipe-tick-box").show();
		$(this).find(".swipe-null-box").hide();
	}).on("tap", function() {
		$(this).css("background-color", "#ffffff");
		$(this).find(".swipe-check-box").hide();
		$(this).find(".swipe-tick-box").hide();
		$(this).find(".swipe-null-box").show();
	});

	//

	$('.swipe-tick-cross-right').click(function() {
		return false;
	});
	$(".swipe-tick-cross-right").hammer({
		drag_max_touches : 0,
	}).on("dragright", function(ev) {
		var touches = ev.gesture.touches;
		ev.gesture.preventDefault();
		$(this).css("background-color", "#ffdcdd");
		$(this).find(".swipe-check-box").show();
		$(this).find(".swipe-tick-box").hide();
		$(this).find(".swipe-null-box").hide();
	}).on("dragleft", function(ev) {
		var touches = ev.gesture.touches;
		ev.gesture.preventDefault();
		$(this).css("background-color", "#e3ffdc");
		$(this).find(".swipe-check-box").hide();
		$(this).find(".swipe-tick-box").show();
		$(this).find(".swipe-null-box").hide();
	}).on("tap", function() {
		$(this).css("background-color", "#ffffff");
		$(this).find(".swipe-check-box").hide();
		$(this).find(".swipe-tick-box").hide();
		$(this).find(".swipe-null-box").show();
	});

	//Swipe Left Dismiss Right Dismiss

	$('.swipe-left-notification').click(function() {
		return false;
	});
	$(".swipe-left-notification").hammer({
		drag_max_touches : 0,
	}).on("dragleft", function(ev) {
		var touches = ev.gesture.touches;
		ev.gesture.preventDefault();
		$(this).find('.swipe-button').css("width", "20%").css("display", "block");
		$(this).parent().find('.swipe-left-notification a').css("width", "75%");
	}).on("dragright", function(ev) {
		var touches = ev.gesture.touches;
		ev.gesture.preventDefault();
		$(this).find('.swipe-button').css("width", "0%").css("display", "none");
		$(this).parent().find('.swipe-left-notification a').css("width", "100%");
	});

	//

	$('.swipe-right-notification').click(function() {
		return false;
	});
	$(".swipe-right-notification").hammer({
		drag_max_touches : 0,
	}).on("dragright", function(ev) {
		var touches = ev.gesture.touches;
		ev.gesture.preventDefault();
		$(this).find('.swipe-button').css("width", "20%").css("display", "block");
		$(this).parent().find('.swipe-right-notification a').css("width", "75%");
	}).on("dragleft", function(ev) {
		var touches = ev.gesture.touches;
		ev.gesture.preventDefault();
		$(this).find('.swipe-button').css("width", "0%").css("display", "none");
		$(this).parent().find('.swipe-right-notification a').css("width", "100%");
	});

	$('.swipe-button').click(function() {
		$(this).parent().parent().fadeOut(200);
		return false;
	});

	////////////////////////////////////////
	////////////////////////////////////////
	/*Page Coach Arrows Showere*/
	////////////////////////////////////////
	////////////////////////////////////////

	$('.coach-nav').click(function() {
		$('.sidebar-left').animate({
			left : '-270',
		}, 300, 'easeOutExpo', function() {
		});
		$('.sidebar-right').animate({
			right : '-280px',
		}, 300, 'easeInOutExpo', function() {
		});

		$('.page-coach').fadeIn(200);
		document.ontouchmove = function(event) {
			event.preventDefault();
		}
	});

	$('.page-coach').click(function() {
		$('.page-coach').fadeOut(200);
		document.ontouchmove = function(event) {
			event.allowDefault();
		}
	});

	////////////////////////////////////////
	////////////////////////////////////////
	/*Big White notifications */
	////////////////////////////////////////
	////////////////////////////////////////

	$('.white-notification a em').click(function() {
		$(this).parent().parent().parent().hide(200);
		return false;
	});

	$('.white-notification').click(function() {
		return false;
	});

	////////////////////////////////////////
	////////////////////////////////////////
	/*Go back to top button*/
	////////////////////////////////////////
	////////////////////////////////////////

	$('.go-up').click(function() {
		$('body,html').animate({
			scrollTop : 0
		}, 500);
		return false;
	});

	////////////////////////////////////////
	////////////////////////////////////////
	/* Extended Content*/
	////////////////////////////////////////
	////////////////////////////////////////

	$('.show-extended-content').click(function() {
		$(this).parent().find('.extended-content').fadeToggle('medium', 'easeInOutExpo');
		return false;
	});

	////////////////////////////////////////
	////////////////////////////////////////
	/*Dropdown Menu*/
	////////////////////////////////////////
	////////////////////////////////////////

	$('.dropdown-hidden').hide();
	$('.dropdown-item').hide();

	$('.dropdown-deploy').click(function() {
		$(this).parent().parent().find('.dropdown-item').show(200);
		$(this).parent().parent().find('.dropdown-hidden').show();
		$(this).hide();
		return false;
	});

	$('.dropdown-hidden').click(function() {
		$(this).parent().parent().find('.dropdown-item').hide(200);
		$(this).parent().parent().find('.dropdown-deploy').show();
		$(this).parent().parent().find(this).hide();
		return false;
	});

	////////////////////////////////////////
	////////////////////////////////////////
	/*Sliding Door for phone number*/
	////////////////////////////////////////
	////////////////////////////////////////

	$('.sliding-door-top').click(function() {
		$(this).animate({
			left : '101%'
		}, 500, 'easeInOutExpo');
		return false;
	});

	$('.sliding-door-bottom a em').click(function() {
		$(this).parent().parent().parent().find('.sliding-door-top').animate({
			left : '0px'
		}, 500, 'easeOutBounce');
		return false

	});

	/////////////////////////////////////////////////////////////////////////////
	//Detect if iOS WebApp Engaged and permit navigation without deploying Safari
	/////////////////////////////////////////////////////////////////////////////
	(
		function(a, b, c) {
			if ( c in b && b[c]) {
				var d, e = a.location, f = /^(a|html)$/i;
				a.addEventListener("click", function(a) {
					d = a.target;
					while (!f.test(d.nodeName))
					d = d.parentNode;
					"href" in d && (d.href.indexOf("http") || ~d.href.indexOf(e.host)) && (a.preventDefault(), e.href = d.href)
				}, !1)
			}
		})(document, window.navigator, "standalone")

	/////////////////////////////////////////////////////////////////////////////////////////////
	//Detect user agent for known mobile devices and show hide elements for each specific element
	/////////////////////////////////////////////////////////////////////////////////////////////

	var isiPhone = navigator.userAgent.toLowerCase().indexOf("iphone");
	var isiPad = navigator.userAgent.toLowerCase().indexOf("ipad");
	var isiPod = navigator.userAgent.toLowerCase().indexOf("ipod");
	var isiAndroid = navigator.userAgent.toLowerCase().indexOf("android");

	if (isiPhone > -1) {
		$('.ipod-detected').hide();
		$('.ipad-detected').hide();
		$('.iphone-detected').show();
		$('.android-detected').hide();
	}
	if (isiPad > -1) {
		$('.ipod-detected').hide();
		$('.ipad-detected').show();
		$('.iphone-detected').hide();
		$('.android-detected').hide();
	}
	if (isiPod > -1) {
		$('.ipod-detected').show();
		$('.ipad-detected').hide();
		$('.iphone-detected').hide();
		$('.android-detected').hide();
	}
	if (isiAndroid > -1) {
		$('.ipod-detected').hide();
		$('.ipad-detected').hide();
		$('.iphone-detected').hide();
		$('.android-detected').show();
	}

	////////////////////////////////////////
	////////////////////////////////////////
	// Creating a cookie for the modal form!
	////////////////////////////////////////
	////////////////////////////////////////

	function createCookie(name, value, days) {
		if (days) {
			var date = new Date();
			date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
			var expires = "; expires=" + date.toGMTString();
		} else
			var expires = "";
		document.cookie = name + "=" + value + expires + "; path=/";
	}

	function readCookie(name) {
		var nameEQ = name + "=";
		var ca = document.cookie.split(';');
		for (var i = 0; i < ca.length; i++) {
			var c = ca[i];
			while (c.charAt(0) == ' ')
			c = c.substring(1, c.length);
			if (c.indexOf(nameEQ) == 0)
				return c.substring(nameEQ.length, c.length);
		}
		return null;
	}

	function eraseCookie(name) {
		createCookie(name, "", -1);
	}

	var webappStatus = readCookie('webappIsClosed');

	////////////////////////////////////////
	////////////////////////////////////////
	/*Show and Close WebApp*/
	////////////////////////////////////////
	////////////////////////////////////////

	$('.delete-cookie').click(function() {
		eraseCookie('webappIsClosed');
		return false;
	});

	if (window.navigator.standalone == true) {
		$('.webapp').hide();
	}

	$('.close-webapp').click(function() {
		createCookie('webappIsClosed', 'true', 7);
		$('.webapp').animate({
			bottom : '-100',
		}, 500, function() {
			$('.webapp').hide();
		});
	});

	if (isiPhone > -1) {
		$('.webapp').delay(1000).animate({
			bottom : '0',
		}, 500, function() {
		});
	};

	if (webappStatus == 'true') {
		$('.webapp').hide();
	};

	/////////////////////////////
	//Checkboxes and radio boxes!
	/////////////////////////////

	$('.checkbox-v1').click(function() {
		$(this).toggleClass('checked-v1');
		return false;
	});
	$('.checkbox-v2').click(function() {
		$(this).toggleClass('checked-v2');
		return false;
	});
	$('.checkbox-v3').click(function() {
		$(this).toggleClass('checked-v3');
		return false;
	});
	$('.checkbox-v4').click(function() {
		$(this).toggleClass('checked-v4');
		return false;
	});
	$('.radio-v1').click(function() {
		$(this).toggleClass('balled-v1');
		return false;
	});
	$('.radio-v2').click(function() {
		$(this).toggleClass('balled-v2');
		return false;
	});

	///////////////////////
	//Notification boxes!//
	///////////////////////
	$(".close-notification").click(function() {
		$(this).parent().hide(150);
		return false;
	});
	$(".small-notification a").click(function() {
		$(this).parent().hide(150);
		return false;
	});

	////////////////////
	//Toggle Function!//
	/////////////////////
	setToggleElements();

});

(function(a) {
	a.fn.extend({
		tabify : function(e) {
			function c(b) {
				hash = a(b).find("a").attr("href");
				return hash = hash.substring(0, hash.length - 4)
			}

			function f(b) {
				a(b).addClass("active");
				a(c(b)).show();
				a(b).siblings("li").each(function() {
					a(this).removeClass("active");
					a(c(this)).hide()
				})
			}

			return this.each(function() {
				function b() {
					location.hash && a(d).find("a[href=" + location.hash + "]").length > 0 && f(a(d).find("a[href=" + location.hash + "]").parent())
				}

				var d = this, g = {
					ul : a(d)
				};
				a(this).find("li a").each(function() {
					a(this).attr("href", a(this).attr("href") + "-tab")
				});
				location.hash && b();
				setInterval(b, 100);
				a(this).find("li").each(function() {
					a(this).hasClass("active") ? a(c(this)).show() : a(c(this)).hide()
				});
				e && e(g)
			})
		}
	})
})(jQuery);

