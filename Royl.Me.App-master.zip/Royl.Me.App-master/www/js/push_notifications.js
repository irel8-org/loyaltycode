//var pushNotification;

function onDeviceReadyPushNotification() {
	console.log('onDeviceReadyPushNotification');
	//alert('onDeviceReadyPushNotification');

	document.addEventListener("backbutton", function(e) {
		if ($("#home").length > 0) {
			// call this to get a new token each time. don't call it to reuse existing token.
			//pushNotification.unregister(successHandler, errorHandler);
			e.preventDefault();
			navigator.app.exitApp();
		} else {
			navigator.app.backHistory();
		}
	}, false);

	try {
		pushNotification = window.plugins.pushNotification;

		if (device.platform == 'android' || device.platform == 'Android' || navigator.userAgent.match(/Android/i) == "Android") {
			console.log('android!');

			pushNotification.register(successHandler, errorHandler, {
				"senderID" : $CONFIG.push_notifications.sender_id,
				"ecb" : "onNotificationGCM"
			});

		} else {
			pushNotification.register(tokenHandler, errorHandler, {
				"badge" : "true",
				"sound" : "true",
				"alert" : "true",
				"ecb" : "onNotificationAPN"
			});

		}
	} catch(err) {
		txt = "There was an error on this page.\n\n";
		txt += "Error description: " + err.message + "\n\n";
		alert(txt);
	}
}

// handle APNS notifications for iOS
function onNotificationAPN(e) {
	//console.log('onNotificationAPN', e);
	if (e.alert) {
		navigator.notification.alert(e.alert, function() {
		});
	}

	if (e.sound) {
		var snd = new Media(e.sound);
		snd.play();
	}

	if (e.badge) {
		pushNotification.setApplicationIconBadgeNumber(successHandler, e.badge);
	}
}

// handle GCM notifications for Android
function onNotificationGCM(e) {
	console.log('onNotificationGCM:' + e.event);

	switch( e.event ) {
	case 'registered':
		console.log("regID = " + e.regid);
		tokenHandler(e.regid);
		break;

	case 'message':
		// if this flag is set, this notification happened while we were in the foreground.
		// you might want to play a sound to get the user's attention, throw up a dialog, etc.
		if (e.foreground) {
			// if the notification contains a soundname, play it.
			//var my_media = new Media("/android_asset/www/" + e.soundname);
			//my_media.play();
			alert(e.payload.message);
		} else {// otherwise we were launched because the user touched a notification in the notification tray.
			if (e.coldstart)
				console.log('--COLDSTART NOTIFICATION--');
			else
				console.log('--BACKGROUND NOTIFICATION--');
		}

		console.log('<li>MESSAGE -> MSG: ' + e.payload.message + '</li>');
		console.log('<li>MESSAGE -> MSGCNT: ' + e.payload.msgcnt + '</li>');

		break;

	case 'error':
		console.log('ERROR -> MSG:' + e.msg);
		break;

	default:
		console.log('Unknown, an event was received and we do not know what it is');
		break;
	}
}

function tokenHandler(result) {
	console.log('tokenHandler:' + result);

	window.localStorage.setItem("device_token", result);
}

function successHandler(result) {
	console.log('successHandler' + result);
}

function errorHandler(error) {
	alert('error!:' + error);
}
