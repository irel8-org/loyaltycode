window.sss = window.sss || {};

sss.client = (function() {
    var self = {};
    
    function init(callback_url) {
        self.callback_url = callback_url;
    };
    self.init = init;
           
    function ajax(data, cbk, error_cbk) {
      if( $('body').hasClass('wait') ) { return; }
    	
    	data.data = sss.util.base64.encode($.toJSON(data.data));
    	$('body').addClass('wait');
    
      networkState = navigator.network.connection.type;
      
      identificator = (new Date()).getTime()+''+window.localStorage.getItem("consumer_id");
      
      data.identificator = identificator;

			if($CONFIG.requests_add_to_queue && ((networkState == Connection.NONE) || (networkState == Connection.UNKNOWN))){
			  requestsAddToQueue(self.callback_url, data, "POST", identificator);
			} else {
        $.ajax(
            {'url': self.callback_url,
             'data': data,
             'type': "POST",
             timeout: 10 * 1000,
             cache: false,
             'error': function(res, textStatus, errorThrown) { 
             	if(textStatus==="timeout"){
             	  if($CONFIG.requests_add_to_queue)
             	    requestsAddToQueue(self.callback_url, data, "POST", identificator);
             	    
             	  cbk && cbk({notices: [$LOCALE.get('slow_internet')]});
             	  $('body').removeClass('wait');
             	}else{
             	   console.log(res, res.responseJSON);
                 error_cbk && error_cbk(res.responseJSON); 
                 $('body').removeClass('wait');
                }
             }, 
             'success': function(res) { 
             	if(res && !res.success){
             		error_cbk && error_cbk(res); 
             	}else{
             		cbk && cbk(res);
             	}
             	
             	$('body').removeClass('wait');
             	}
            });
        };
    };
    self.ajax = ajax;


    function call(data, merchant_id) {
        var form = $('<form method="POST"></form>');
        form.attr('action', self.callback_url);
        var input = $('<input name="data" type="hidden"></input>');
        input.val(sss.util.base64.encode($.toJSON(data)));
        form.append(input);
        
        input = $('<input name="merchant_id" type="hidden"></input>');
        input.val(merchant_id);
        form.append(input);
        
        input = $('<input name="auth_token" type="hidden"></input>');
        input.val(window.localStorage.getItem("auth_token"));
        form.append(input);
        
       
        $('body').append(form);
        form.submit();
    };
    self.call = call;
    
    return self;
})();

