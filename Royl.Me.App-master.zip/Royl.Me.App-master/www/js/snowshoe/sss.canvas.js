window.sss = window.sss || {};

sss.canvas = (function() {
    var msTouches = {};
    var pointsChanged = false;
    var errorLock = false;
    var errorDisplay = false;
    var touchTriggered = false;
    
    var self = {
        touches: [],
        pointsCaptured: false,
        noTouchCount: 0,
        trackingData: {},
        error_cbk: function() { window.location = self.errorURL || "http://beta.snowshoestamp.com/api/v2/uasubmit"; },
        trackCapture: false,
        debug: false,
        debugCountTouch: 1
    };
    
    function init(cbk, options) {
        /*
         * @param cbk: Callback function to call when points are detected on the canvas 
         *   that is called with an array of points [(x,y), ] as the argument.
         */
        // zero out existing touches
        self.touches = [];
        
        // set up touch event listeners
        self.addListeners();

        // set all passed options to self
        for (key in options) {
            self[key] = options[key];
        }        
        
        self.cbk = cbk;
        
        // grab current background image
        self.image = $("#canvas").css('background-image');
        self.background_color = $("#canvas").css('background-color');

        setTimeout(initCanvas, 0);
        
        // set up intervals to update the canvas size
        //setInterval(adjustCanvas, 100);
        
        // hide address bar
        /*setTimeout(function() { 
            window.scrollTo(0, 1);
        }, 100);*/
        
        //start touch polling
        setInterval(function() { 
            pollTouches(cbk); 
        }, 20); // 20ms = 50fps
    };
    self.init = init;
    
    self.reset = function() {
        self.touches = [];
        self.pointsCaptured = false;
        pointsChanged = false;
        self.noTouchCount = 0;
        self.errorStart = null;
        errorLock = false;
    }

    self.onNoTouches = function() {
        self.noTouchCount ++;
        if (self.noTouchCount >= 4 && !errorLock) {
            errorLock = true;
            self.noTouchCount = 0;
            self.clearError();
            self.error_cbk && self.error_cbk(); 
            
        }
    };

    self.onInsufficientPoints = function() {
        if (self.errorStart == null) {
            self.errorStart = new Date();
        }
        else if (new Date() - self.errorStart > 2000 && !errorLock) {
            errorLock = true;
            self.clearError();
            self.error_cbk && self.error_cbk(); 
           
        }

        //Timeout to prevent hyper-reactivity of error screen
        else if (new Date() - self.errorStart > 1000) {  
            if (!errorDisplay) {
                errorDisplay = true;
                $("body").css("background-color", "#e74c3c");
                $("#canvas").css("background-color", "#e74c3c");
                $("#canvas").css("background-image", "url('/static/api/img/points.png')");
            }
        }
        // reset the timer if we have zero touches here
        if (self.touches.length == 0) {
            self.errorStart = null;
        }
    }

    self.clearError = function () {
        errorDisplay = false;
        $("body").css("background-color", self.background_color);
        $("#canvas").css("background-color", self.background_color);
        $("#canvas").css("background-image", self.image);
    }
        
    function pollTouches() {    
        if (self.touches.length >= 5 && !self.pointsCaptured || self.debug && self.touches.length == self.debugCountTouch ) {
            // indicate that we have reached 5 points to prevent polling from calling
            // the callback more than once (until reset)
            self.pointsCaptured = true;
            // use slice(0) to make a copy of the array so that the data is available
            // when keen returns from logging the stamp event
            var capturedPoints = self.touches.slice(0);
            
            if (self.trackCapture) {
                
                    self.clearError();
                    self.cbk && self.cbk(capturedPoints);
               
            }
            else {
                // clear error state so that returning this page works
                self.clearError();
                self.cbk && self.cbk(capturedPoints);
            }
        }
        else if (self.touches.length >= 1 && !self.pointsCaptured) {
            // there are fewer than 5 touches but at least one
            self.onInsufficientPoints && self.onInsufficientPoints();
        }

        // callback for no touches if points changed and there are no touches
        if (self.touches.length == 0) {
            if (pointsChanged) {
                pointsChanged = false; // only fire notouches once
                self.clearError();
                self.onNoTouches && self.onNoTouches();
            }
            else {
                // reset timer for detecting not enough points
                // this is a bug fix timer for a really fast press
                // where notouches is not called because pointsChanged
                // doesn't get set
                self.errorStart = null;
            }
        }
    };
    
    function addListeners() {
        // check to see if this is a microsoft device
        if (navigator.msPointerEnabled) {
            // questionable whether these are needed on canvas or document
            document.getElementById('canvas').addEventListener("MSPointerUp", msTouchEnd, false);
            document.getElementById('canvas').addEventListener("MSPointerDown", msTouchStart, false);
            document.addEventListener("MSPointerMove", msTouchStart, false);
            document.addEventListener("MSPointerCancel", msTouchEnd, false);
            document.addEventListener("MSPointerDown", function(evt) { evt.preventDefault() }, false);
            document.addEventListener("MSGestureInit", function(evt) { 
                if(evt.preventManipulation) evt.preventManipulation(); }, false);
            document.addEventListener("MSHoldVisual", function(evt) { evt.preventDefault(); }, false);
        } 
        else {
            document.getElementById('canvas').addEventListener('touchmove', recordTouches, true);
            document.getElementById('canvas').addEventListener('touchstart', recordTouches, true);
            document.getElementById('canvas').addEventListener('touchend', recordTouches, true);
            document.getElementById('canvas').addEventListener('touchleave', recordTouches, true);
            document.getElementById('canvas').addEventListener('touchcancel', recordTouches, true);
        }
        window.addEventListener('message', function(evt){
            points = JSON.parse(evt.data);
            for (var i=0;i<=Object.keys(points).length;i++) {
                self.touches[i] = [points[i+1].x, points[i+1].y];
            }

        }, false);
        
        // we might need to adjust canvas shape, etc on orientation change
        //document.addEventListener("orientationChanged", adjustCanvas, true); 
    };
    self.addListeners = addListeners;
    
    /////////////////////////////////////////
    // Listener event handlers for ms devices
    function convertTouches() {
        // keep the touches in an array format for compatibility with other devices
        self.touches = [];
        var count = 0;
        for (i in msTouches) {
            if (msTouches[i]) {
                self.touches[count] = msTouches[i];
                count += 1;
            }
        }
        pointsChanged = true;
    }
    function msTouchStart(event) {
        event.preventDefault();
        var pID = event.pointerId || 0;
        msTouches[pID] = [event.clientX, event.clientY];
        convertTouches();
    }
    function msTouchEnd(event) {
        var pID = event.pointerId || 0;
        if(msTouches[pID]) {
            delete msTouches[pID];
        }
        convertTouches();
    }
    // non-microsoft event listeners
    function recordTouches(evt) {
        evt.preventDefault();
        pointsChanged = true;
        if (evt.type == "touchend") {
            if (evt.touches.length == 0) {
                self.touches = [];
            }
        }
        // record the touched points in x,y format
        for (i in evt.touches) {
            if(evt.touches[i]){
                self.touches[i] = [evt.touches[i].pageX, evt.touches[i].pageY];
            }
        }        
    }
    // End listeners
    //////////////////////////////////////////
    
    function initCanvas() {
        // check current window size and compare with the current canvas size
        // update the canvas size if it is not the same as the current window
        var jscanvas = document.getElementById('canvas'); // to use javascript width and height
        var canvas = $("#canvas"); // jquery canvas for convenience methods
        if (canvas.width() != window.innerWidth) {
            canvas.css({'width': window.innerWidth + 'px'}); // set visible width and height
            jscanvas.width = window.innerWidth; // set pixel width
        }
        if (canvas.height() != window.innerHeight) {
            canvas.css({'height': (window.innerHeight) + 'px'});
            jscanvas.height = window.innerHeight;
        }
    }
    
    function adjustCanvas() {
        // 180 degree rotation is the same as upright for our purposes
        var orientation = window.orientation % 180;
        if (orientation) {
            canvas.removeClass("stamp");
            canvas.addClass("rotate-" + (orientation < 0 ? "left" : "right"));
        }
        else { // normal orientation, remove rotate classes
            canvas.removeClass("rotate-left");
            canvas.removeClass("rotate-right");
            canvas.addClass("stamp");
        }
    };
    
    // this is a debugging method verifying stamp points visually
    function drawTouches(points, clear) { 
        var canvas = document.getElementById('canvas')
        //canvas.style.opacity = "0.5";
        var ctx = canvas.getContext('2d');
        
        // if clear is not specified, default to true
        if (typeof(clear) == "undefined" || clear) {
            ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
        }
        
        // use the internal touch values if none are supplied
        if (typeof(points) == "undefined") {
            points = self.touches;
        }
        
        for (i in self.touches) {
            var x = self.touches[i][0];
            var y = self.touches[i][1];
            
            // outer circle
            ctx.beginPath();
            ctx.arc(x, y, 50, 0, 2*Math.PI, true);
            ctx.fillStyle = "rgba(64, 64, 64, 0.2)";
            ctx.fill();
            ctx.lineWidth = 2.0;
            ctx.strokeStyle = "rgba(64, 64, 64, 0.8)";
            ctx.stroke();
            
            // center dot
            ctx.beginPath();
            ctx.arc(x, y, 1, 0, 2*Math.PI, true);
            ctx.lineWidth = 4.0;
            ctx.strokeStyle = "rgba(0, 0, 0, 1)";
            ctx.stroke();
            
            // points
            ctx.font = "12px Arial";
            ctx.fillStyle = "rbga(0, 0, 0, 255)";
            ctx.fillText(x+","+y, x,y);
        }
    };
    self.drawTouches = drawTouches;
    
    return self;
})();
