# Hosting your own stamp screen

The basic mechanics of the stamp screen are as follows:

sss.util.js is used for base64 encoding and a few other utility functions. You should not have to modify this file
at all.

sss.client.js handles the post forward to your callback. sss.client.call() takes the data from the canvas, 
and generates a form on the fly, converts the touches to a base64 encoded string, and sends them to
whatever is set as the callback URL. The only thing you really need to do is set the callback, which is done via
sss.client.init(callback_url). This is the first function called from the HTML.

sss.canvas.js is where most of the heavy lifting happens. There are some mechanics that handle error state, i.e.,
a phone that doesn't detect five touches. onInsufficientTouches and onNoTouches check whether the screen has received
inputs that are less than five touches for either more than 2 seconds, or more than 3 times. You can change what happens
on the error state via the sss.canvas.init function, which we will discuss now. This is the second function called from the HTML.
init takes two parameters, the js client callback function and options as a JS object. The options parameter is where 
you would set an error URL if you want it to be something other than SnowShoe's error page. Calling init starts the 
detection mechanism for points.  init adds touch event listeners to the canvas element in the HTML, and then sets up an 
interval, pollTouches, to check the content of the touch variable every 20 ms. The listeners call  an function called recordTouches 
(or msTouchEnd or msTouchStart for Microsoft devices), and this stores the touch data as coordinates in self.touches.
When pollTouches determines that there are five touches stored in self.touches, it fires off the js client callback.



