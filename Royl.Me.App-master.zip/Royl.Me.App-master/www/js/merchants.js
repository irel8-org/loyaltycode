function merchantsSaveInfo(merchant) {
	merchantsSaveInfoInDb(merchant);
	if (merchant.name != undefined) {
		window.localStorage.setItem("merchant_" + merchant.id + '_name', merchant.name);
	}
	if (merchant.favorite != undefined) {
		window.localStorage.setItem("merchant_" + merchant.id + '_favorite', merchant.favorite);
	}
}

function merchantsCreateOrUpdate(merchant, res) {
	dbCheckInstall();
	var args = new Array();
	var sql;

	if (res) {
		sql = 'UPDATE merchants SET count_coupons = ?, cover_image = ?, time_zone = ?, city = ?, zip_code = ?, state = ?, country = ?,';
		sql += ' address = ?, website = ?, logo = ?, name = ?, buyx_items_balance = ?, count_daily_deal_coupons = ?, points_balance = ?, loyl_me_loyalty_value = ?,';
		sql += ' count_ss_rewards = ?, count_rewards = ?, send_email = ?, send_sms = ?, send_push_notification = ?, favorite = ?, latitude = ?, longitude = ? ';
		sql += ' WHERE id = ?';
		args = [merchant.count_coupons, merchant.cover_image, merchant.time_zone, merchant.city, merchant.zip_code, merchant.state, merchant.country, merchant.address, merchant.website, (merchant.logo && merchant.logo.logo && merchant.logo.logo.url), merchant.name, merchant.buyx_items_balance, merchant.count_daily_deal_coupons, merchant.points_balance, merchant.loyl_me_loyalty_value, merchant.count_ss_rewards, merchant.count_rewards, merchant.send_email, merchant.send_sms, merchant.send_push_notification, merchant.favorite, merchant.latitude, merchant.longitude, res.id];
	} else {
		sql = 'INSERT INTO merchants (merchant_id, count_coupons, cover_image, time_zone, city, zip_code, state, country, address, website, logo, name, ';
		sql += ' buyx_items_balance, count_daily_deal_coupons, points_balance, loyl_me_loyalty_value, count_ss_rewards, count_rewards, send_email, send_sms, send_push_notification, favorite, latitude, longitude)';
		sql += ' VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
		args = [merchant.id, merchant.count_coupons, merchant.cover_image, merchant.time_zone, merchant.city, merchant.zip_code, merchant.state, merchant.country, merchant.address, merchant.website, (merchant.logo && merchant.logo.logo && merchant.logo.logo.url), merchant.name, merchant.buyx_items_balance, merchant.count_daily_deal_coupons, merchant.points_balance, merchant.loyl_me_loyalty_value, merchant.count_ss_rewards, merchant.count_rewards, merchant.send_email, merchant.send_sms, merchant.send_push_notification, merchant.favorite, merchant.latitude, merchant.longitude];
	}

	for (i in args) {
		if (args[i] == undefined || args[i] == null)
			args[i] = '';
	}

	$CONFIG.db.connect.transaction(function(tx2) {
		tx2.executeSql(sql, args, function(tx2, result2) {

		}, function(tx, error) {

			console.log(sql, args, "Query Error: " + error.message);
		});
	});
}

function merchantsSaveInfoInDb(merchant) {

	dbCheckInstall();

	$CONFIG.db.connect.transaction(function(tx) {
		tx.executeSql('SELECT * FROM merchants WHERE merchant_id = ?', [merchant.id], function(tx, result) {
			merchantsCreateOrUpdate(merchant, result.rows.length > 0 && result.rows.item(result.rows.length - 1));
		});
	});
}

function merchantSort(val) {
	$('.merchant-li').each(function() {
		if (!$(this).hasClass('hidden')) {
			var re = new RegExp(val, "ig");

			if ($(this).find('.title').length == 0 || !$(this).find('.title').html().match(re)) {
				$(this).hide();
			} else {
				$(this).show();
			}
		}
	});

	if (val.length >= 3) {
		merchantsGetList('search', val);
	}
}

function merchantsGetInfo(merchant_id, fields, need_update) {
	var merchant = {};

	merchant.id = merchant_id;
	if (!fields) {
		fields = ['name', 'favorite'];
	}

	for (i in fields) {
		merchant[fields[i]] = window.localStorage.getItem("merchant_" + merchant.id + '_' + fields[i]);
		merchant[fields[i]] = merchant[fields[i]] == 'false' ? false : (merchant[fields[i]] == 'true' ? true : merchant[fields[i]]);
		if (merchant[fields[i]] == undefined) {
			need_update = true;
		}
	}

	if (need_update) {
		var res = authSignedRequest($CONFIG.moe.show_merchant_url.replace(/_MERCHANT_ID_/, merchant.id), 'GET', {
			with_balance : 'yes',
			with_consumer_data_for_merchant : 'yes'
		});

		if (!res.success) {
			document.location.href = $CONFIG.local.my_merchants_path;
			return;
		} else {
			merchantsSaveInfo(res.merchant);
			merchant = res.merchant;
		}
	}

	return merchant;
}

function merchantsSaveInfoMerchants(merchants) {
	if(merchants){
		for (i in merchants) {
			merchantsSaveInfo(merchants[i]);
		}
	}
}

function merchantsSettingCalbackAfterUpdate(url, type, params, result) {
	$('#merchant-' + params.merchant_id + ' .wait').removeClass('wait');
}

function merchantsSettingCalback(el) {
	var merchant_id = $(el).parents('.merchant-li').first().data('id');
	var data = {
		merchant_id : merchant_id
	};
	data.consumer = {};
	data.consumer[$(el).data('field')] = $(el).hasClass('toggle-on');

	authSignedRequest($CONFIG.moe.update_consumer_url.replace(/_CONSUMER_ID_/, window.localStorage.getItem("consumer_id")), 'POST', data, true, 'merchantsSettingCalbackAfterUpdate');
}

function merchantsEmptyResult(){
	lost_connection();
	return null;
}

function merchantsGetList(search_type, query, page) {
	localeStandartControll(false);

	var url = $CONFIG.moe.merchants_url;
	var params = {
		page : page || 1
	};

	if (search_type != undefined && search_type != '') {
		$('.footer').html(templateReplaceVars($('.footer').html(),{},true));
		if (search_type == 'search') {
			url = $CONFIG.moe.search_merchants_url;
			params['query'] = query;
		} else if (search_type == 'favorite') {
			params['favorite'] = 'yes';
		} else if (search_type == 'rewards') {
			params['by_rewards'] = 'yes';
		}
	} else {
		// in case no results from server
		// $CONFIG.db.connect.transaction(function(tx) {
		// tx.executeSql('SELECT * FROM merchants WHERE', [merchant.id], function(tx, result) {
//
		// });
	// });
	}
	
	if($.urlParam('qr')){
		params['qr_code_enabled'] = 'yes';		
	}

	var merchants = authSignedRequest(url, 'GET', params, false, false, 'merchantsEmptyResult');

	if (search_type == 'search' && merchants)
		merchants = merchants.merchants;

	merchantsSaveInfoMerchants(merchants);

	// cleaninig container from non template elements
	//  $('ul.listing li.merchant-li').each(function(){ if(!$(this).hasClass('template')){ $(this).remove(); } });

	if (merchants && merchants.length > 0) {

		var template = $('ul.listing li.template')[0].outerHTML;

		for (i in merchants) {
			var merchant = merchants[i];
			if (search_type == 'search') {
				m = merchant[0];
				m.already_added_to_list = merchant[1] ? 'hidden' : '';
				m.not_in_list_merchant = merchant[1] ? 'no' : 'yes';

				merchant = m;
			}

				if (merchant['merchant_info.cover_image'] && merchant['merchant_info.cover_image'].cover_image && merchant['merchant_info.cover_image'].cover_image.url && merchant['merchant_info.cover_image'].cover_image.url.length > 0) {
					merchant.cover_img = $CONFIG.moe.url + merchant['merchant_info.cover_image'].cover_image.url;
				}

				if (merchant['logo'] && merchant['logo'].logo && merchant['logo'].logo.view && merchant['logo'].logo.view.url  && merchant['logo'].logo.view.url.length > 0) {
					merchant.logo_img = $CONFIG.moe.url + merchant['logo'].logo.view.url;
				}

			if ($('#merchant-' + merchant.id).length == 0) {

				$('ul.listingWrapper').append(templateReplaceVars(template, merchant));

				if (search_type != 'search') {
					var loaylty = [];

					if (merchant.count_rewards > 0) {
						loaylty.push($LOCALE.get('rewards', {count: merchant.count_rewards}));
					}
					
					if (merchant.points_balance > 0) {
							loaylty.push($LOCALE.get('points', {count: merchant.points_balance}));
					}

					if (merchant['merchant_setting.enabled_loyalty'] == 'SS') {
						// if (merchant.points_balance > 0) {
							// loaylty.push($LOCALE.get('points', {count: merchant.points_balance}));
						// }
					} else {
						if (merchant.loyl_me_loyalty_value > 0) {
							loaylty.push($LOCALE.get('loyalty_value_2', {count: floatToS(merchant.loyl_me_loyalty_value)}));
						}
					}

					if (loaylty.length > 0) {
						$('li#merchant-' + merchant.id + ' .loyalty').html(loaylty.join($LOCALE.get('and2')));
					}
				}

				if (search_type == 'settings') {
					var mcont = $('li#merchant-' + merchant.id);

					setToggleAs(mcont, 'email', merchant.send_email == 1);
					setToggleAs(mcont, 'sms', merchant.send_sms == 1);
					setToggleAs(mcont, 'push_notification', merchant.send_push_notification == 1);
				}
			} else {
				$('#merchant-' + merchant.id).show();
			}
		}
	}

	merchantSetIndexMenu(search_type);

	if (search_type == 'settings') {
		setToggleElements();
		setToggleCheckBoxs('merchantsSettingCalback');
	}

	closePreloader();
}

function merchantsAddToMyList(merchant_id) {
	if ($('#merchant-' + merchant_id).hasClass('wait') || $('#merchant-' + merchant_id).hasClass('done')) {
		return false;
	}

	$('#merchant-' + merchant_id).addClass('wait');

	res = authSignedRequest($CONFIG.moe.create_merchants_url, 'POST', {
		merchant_id : merchant_id
	});

	if (res.completed) {
		$('#merchant-' + merchant_id).addClass('done');
		document.location.href = $CONFIG.local.show_merchant_path + '?id=' + merchant_id;
	}

	$('#merchant-' + merchant_id).removeClass('wait');
}

function merchantFavorite(buton, merchant_id) {
	if ($(buton).hasClass('wait')) {
		return false;
	}

	$(buton).addClass('wait');
	var favorite = !!$(buton).hasClass('highlight-color-1');
	$(buton).toggleClass('highlight-color-1');

	authSignedRequest($CONFIG.moe.update_consumer_url.replace(/_CONSUMER_ID_/, window.localStorage.getItem("consumer_id")), 'POST', {
		consumer : {
			favorite : favorite
		},
		merchant_id : merchant_id
	});

	merchantsSaveInfo({
		id : merchant_id,
		favorite : favorite
	});

	$(buton).removeClass('wait');
}

function merchantShow() {
	var merchant_id = $.urlParam('id') || $.urlParam('merchant_id');
	var not_in_list_merchant = false;
	//$.urlParam('not_in_list_merchant') == 'yes';

	res = authSignedRequest($CONFIG.moe.show_merchant_url.replace(/_MERCHANT_ID_/, merchant_id), 'GET', {
		with_balance : not_in_list_merchant ? 'no' : 'yes',
		with_consumer_data_for_merchant : not_in_list_merchant ? 'no' : 'yes',
		with_punchcards : not_in_list_merchant ? 'no' : 'yes',
	});

	if (!res || !res.success) {
		document.location.href = $CONFIG.local.my_merchants_path;
		return;
	}

	var obj = res.merchant;

	merchantsSaveInfo(obj);

	obj.loyalty_value = [];
	obj.favorite_active_class = obj.favorite ? 'active' : '';

	//if (res.consumer_balance) {

	if (obj.points_balance && obj.points_balance > 0) {
		obj.loyalty_value.push(obj.points_balance + ' points');
	}
		
	if (obj['merchant_setting.enabled_loyalty'] == 'SS') {
		// if (obj.points_balance && obj.points_balance > 0) {
			// obj.loyalty_value.push(obj.points_balance + ' points');
		// }
	} else {
		if (obj.loyl_me_loyalty_value && obj.loyl_me_loyalty_value > 0) {
			obj.loyalty_value.push('$'+floatToS(obj.loyl_me_loyalty_value));
		}
	}

	//if (res.consumer_balance.sticky_street.buyx_items_balance > 0)
	//	obj.loyalty_value.push(res.consumer_balance.sticky_street.buyx_items_balance + ' items');
	//}

	obj.loyalty_value = obj.loyalty_value.join(', ');

	obj.cover_img = "images/merchantSampleImage.jpg";

	if (obj['merchant_info.cover_image'] && obj['merchant_info.cover_image'].cover_image && obj['merchant_info.cover_image'].cover_image.url && obj['merchant_info.cover_image'].cover_image.url.length > 0) {
		obj.cover_img = $CONFIG.moe.url + obj['merchant_info.cover_image'].cover_image.url;
	}

	if(res.punchcards && res.punchcards.length > 0){
		//obj.count_rewards += 1;
	}

	var html = templateReplaceVars($('.mainContent').html(), obj);
	$('.mainContent').html(html);

	if(obj.loyalty_value.length == 0 && (!obj.count_rewards || obj.count_rewards == 0)){
		$('.loyaltyBar').hide();
	} else if(obj.loyalty_value.length == 0){
		$('.loyaltyBarRight').addClass('hideButton');
		$('.loyaltyBarLeft').addClass('showButton');
	} else if(!obj.count_rewards || obj.count_rewards == 0){
		$('.loyaltyBarLeft').addClass('hideButton');
		$('.loyaltyBarRight').addClass('showButton');
	}

	if (!not_in_list_merchant)
		merchantSetMenu(obj);
		
	if(!obj['merchant_royl_me.qr_code_enabled'])
	  $('#add-loyalty-card').hide();

	setBackObserve();
	closePreloader();
	$('.mainContent').show();
}

function merchantShowQrCode() {
	authShouldBeAuthorized();

	var merchant_id = $.urlParam('id') || $.urlParam('merchant_id');

	var merchant;
	
	var res = authSignedRequest($CONFIG.moe.show_merchant_url.replace(/_MERCHANT_ID_/, merchant_id), 'GET', {
			with_balance : 'yes',
			with_consumer_data_for_merchant : 'yes'
		});

		if (!res.success) {
			document.location.href = $CONFIG.local.my_merchants_path;
			return;
		} else {
			merchant = res.merchant;
		}
		
	if(merchant){
		$('.middle').html(templateReplaceVars($('.middle').html(), merchant));
		merchantSetMenu(merchant, 'scan-code');
	}
	
	// qr_code = {
		// customer: {
			// id:  res.customer && res.customer.id,
			// card_number:  res.customer && res.customer.card_number
		// },
		// consumer: {
			    // id: window.localStorage.getItem("consumer_id"), 
		      // account_number: window.localStorage.getItem("consumer_formatted_account_number") || ''
		      // },
		// merchant: {id: merchant_id}
		// };
// 	
	// if($.urlParam('reward_name')){
		// key = $.urlParam('reward_type') == 'coupon' ? 'coupon' :  'reward';
// 		
		// qr_code[key] = {name: $.urlParam('reward_name'), id: $.urlParam('reward_id')};
// 		
	   // if( $.urlParam('reward_type') == 'punchcard'){
		   // qr_code[key]['type'] = 'participating_in_punchcard';
		// }
	// }
	
	// console.log(qr_code);
	
	$('#account_number').html(res.customer.formatted_card_number);

  var size = $('#qrcode_cont').width();

  if(size < 100) size = 100;

	jQuery('#qrcode').qrcode({
		width : size,
		height : size,
		text : res.customer.card_number||''//JSON.stringify(qr_code)
	});
	
	$('.content2').html(templateReplaceVars($('.content2').html(),{},true));
	if($('.offerToBeApplied').length > 0){
		$('.offerToBeApplied').html($.urlParam('reward_name'));
	}

	closePreloader();
}


function merchantSetMenu(merchant, part) {
	if (!merchant) return;

	if (!merchant.id)
		merchant.id = merchant.merchant_id;
	$.ajax({
		url : $CONFIG.local.merchant_menu_path,
		success : function(data) {

			data = templateReplaceVars(data, merchant);

			$('.mainContent').append(data);

			if (part != undefined)
				$('#merchant-menu-' + part).removeClass('highlight-color-1');

			if (merchant.favorite)
				$('#merchant-menu-favorite').removeClass('highlight-color-1');
	  	if (merchant['merchant_royl_me.qr_code_enabled']){
	  	  $('#merchant-menu-scan-code').show();
	  	  $('#merchant-menu-enter-amount').hide();
	  	 }else{
	  	  $('#merchant-menu-scan-code').hide();
	  	  $('#merchant-menu-enter-amount').show();	  	 	
	  	 }
	  	   
		},
		dataType : 'html'
	});
}

function merchantSetIndexMenu(part) {
	if ($('.footer').length == 0) {
		$.ajax({
			url : $CONFIG.local.merchant_index_menu_path,
			success : function(data) {

				$('.mainContent').append(templateReplaceVars(data, {}, true));

				if ($('#merchant-menu-' + part).length > 0)
					$('#merchant-menu-' + part).removeClass('highlight-color-1');
			},
			dataType : 'html'
		});
	}
}


function merchnatAddLoyaltyCard(){	
	var merchant_id = $.urlParam('id') || $.urlParam('merchant_id');
	
	var res = authSignedRequest($CONFIG.moe.show_merchant_url.replace(/_MERCHANT_ID_/, merchant_id), 'GET', {});

	if (!res.success) {
		document.location.href = $CONFIG.local.my_merchants_path;
		return;
	}
	
	data = res.customer;
	
	data.merchant_name = res.merchant.name;
	
	data.loyalty_card_body = $LOCALE.get('add_loyalty_card_body', {name: res.merchant.name});
	$('.mainContent').html(templateReplaceVars($('.mainContent').html(), data));
	
	formsSetEvents('smart-form-delay');
	
	setBackObserve();
}


function merchantAddCardSuccess(){
	var merchant_id = $.urlParam('id') || $.urlParam('merchant_id');
	
	if (merchant_id) var merchant = merchantsGetInfo(merchant_id);

  if (!merchant_id || !merchant) {
		document.location.href = $CONFIG.local.my_merchants_path;
		return;
	}
	
	$('.mainContent').html(templateReplaceVars($('.mainContent').html(), merchant));
	
	setBackObserve();
}

function merchantCardNumberUpdated(){
	var merchant_id = $.urlParam('id') || $.urlParam('merchant_id');
	
	document.location.href = $CONFIG.local.add_loyalty_card_success_path+'?merchant_id='+merchant_id;
}

function merchantAddCardFailure(){
	var merchant_id = $.urlParam('id') || $.urlParam('merchant_id');
	
	if (merchant_id) var merchant = merchantsGetInfo(merchant_id);

  if (!merchant_id || !merchant) {
		document.location.href = $CONFIG.local.my_merchants_path;
		return;
	}
	
	$('.mainContent').html(templateReplaceVars($('.mainContent').html(), merchant));
	
	setBackObserve();
}

function merchantFindByStamp(){
	localeStandartControll();

	setBackObserve();

	closePreloader();
}

function merchantFindByStampCallback(data) {
	document.location.href = $CONFIG.local.show_merchant_path + '?merchant_id=' + data.id;
}

function merchantFindByStampErrorCallback(data) {
	var errors = data && (data.errors && data.errors.join(' ') || data.error_message) || !data && $LOCALE.get('lost_connection') || '';

	alert(errors);

	document.location.reload();
}
