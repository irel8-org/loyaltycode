var $LANG = {};

var version = (new Date()).getTime();//1

 if($CONFIG.locale.base){
	  $LAB.script("js/locales/"+$CONFIG.locale.base+".js?version="+version);
	}
	if($CONFIG.locale.current && $CONFIG.locale.current != 'null' && $CONFIG.locale.base != $CONFIG.locale.current){
	  $LAB.script("js/locales/"+$CONFIG.locale.current+".js?version="+version);
	}

function Locale(locale, base_locale, available_languages){
	this.default_locale = base_locale;
	this.locale = locale;
	this.available_languages = available_languages;

	this.get = function(variable, variables){
		var val, i;
		
		if(!variables) variables = {};
		
		if(this.available_languages[this.locale] && this.available_languages[this.locale][variable]){
			val = this.available_languages[this.locale][variable];
		} else if(this.available_languages[this.default_locale] && this.available_languages[this.default_locale][variable]) {
			val = this.available_languages[this.default_locale][variable];
		} else {
			val = variable;
		}
		
		for(i in variables){
			val = val.replace(new RegExp('%{'+i+'}','g'), variables[i]);
		}
		
		return val;
	};
};

function localeStandartControll(content, header){
	if(content == undefined || content){
	  $('.mainContent').html(templateReplaceVars($('.mainContent').html(),{},true));	  
	}
	
	if(header == undefined || header){
	  $('.header').html(templateReplaceVars($('.header').html(),{},true));
  	setBackObserve();
	 }
}

var $LOCALE = new Locale($CONFIG.locale.current, $CONFIG.locale.base, $LANG);
