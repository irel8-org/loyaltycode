function LVShowLoyaltyValueSlider(){
	var merchant_id = $.urlParam('id') || $.urlParam('merchant_id');

	res = authSignedRequest($CONFIG.moe.show_merchant_url.replace(/_MERCHANT_ID_/, merchant_id), 'GET', {
		with_balance : 'yes',
		with_consumer_data_for_merchant : 'yes'
	});

	if (!res.success) {
		document.location.href = $CONFIG.local.my_merchants_path;
		return;
	}

	var obj = res.merchant;

	merchantsSaveInfo(obj);

	if (res.consumer_balance) {
		var template_slide = $('.wrap.template')[0].outerHTML;
		var template_navig = $('#position li.template')[0].outerHTML;

		if (res.consumer_balance.enabled_loyalty == 'loyl_me' && res.consumer_balance.loyl_me.loyalty_value > 0) {
		
		 var balances = res.consumer_balance.loyl_me.loyalty_campaigns && res.consumer_balance.loyl_me.loyalty_campaigns.dollars ? res.consumer_balance.loyl_me.loyalty_campaigns.dollars : [];
		 
		 var object, description, i, can_redeem_few_times;
		 
			for (i in balances) {
				  can_redeem_few_times  = balances[i].max_redeem != balances[i].min_redeem;
				  description =  !can_redeem_few_times ? $LOCALE.get('this_value_can_only_be_redeemed_once') : $LOCALE.get('you_may_use_up_to', {count: balances[i].max_redeem});
	  
	  		  object = {
						title : balances[i].title,
						description : description,
						reward_id : balances[i].id,
						reward_type : balances[i].type,
						can_redeem_few_times: can_redeem_few_times ? '1' : '0',
						earned: balances[i].earned,
						max_redeem: balances[i].max_redeem,
						expiration_date: balances[i].expiration_date ? $LOCALE.get('expiration_date', {date: balances[i].expiration_date}) : '',
					};
	
					$('.wrap:last').after(templateReplaceVars(template_slide, object));
					$('#position li:last').after(templateReplaceVars(template_navig, object));
	  	}
			
		
			
		} else {
			$('#slider').html( $LOCALE.get('empty_loyalty_value') );
			$('#claim-cont').hide();
		}
	}

	$('.wrap.template').remove();
	$('#position li.template').remove();

	var html = templateReplaceVars($('.mainContent').html(), obj);

	$('.mainContent').html(html);

	if ($('#position li').length > 0) {
		$('#position li:first').addClass('on');
		setSlider();
	}

	merchantSetMenu(obj, 'reward-enter-amount');

	setBackObserve();

	closePreloader();
}


function LVSelectedloyaltyValue(){
  var merchant_id = $.urlParam('id') || $.urlParam('merchant_id');
	
	var li_on = $('#position li.on');
	
	var cont = $('.wrap').eq(li_on.index()).find('.loyaltyValue-title');
	
	var reward_name = cont.html();
	
	var can_redeem_few_times = cont.data('can-redeem-few-times') == '1' ? true : false;
	var max_redeem = cont.data('max-redeem');
	
	var reward_id = cont.data('reward-id');
	
	if(!can_redeem_few_times){
		var earned = cont.data('amount');
		
		return LVEnterAmount(earned, reward_id);
	}	
	
	
	
	var params = [];
	
	params.push('merchant_id=' + merchant_id);
	params.push('reward_id=' + reward_id);
	params.push('max_redeem=' + max_redeem);
	

	document.location.href = $CONFIG.local.loyalty_value_enter_amount_path + '?' + params.join('&');
}

function LVEnterAmount(amount, reward_id){	

  if (!amount && ($('#enterAmount').length == 0 || $('#enterAmount').val().length == 0)) {
		return false;
	}
	
	if(!amount) amount = $('#enterAmount').val();
	
	var max_redeem = $('h2').data('max-redeem');
	
	if(max_redeem < amount){
		alert($LOCALE.get('you_may_use_up_to', {count: max_redeem}));
		return false;
	}

	var params = [];
	
	if(!reward_id) reward_id = $.urlParam('reward_id');
	
	params.push('merchant_id=' + ($.urlParam('merchant_id') || $.urlParam('id')));
	params.push('reward_id=' + reward_id);
	params.push('amount=' + amount);
	
	document.location.href = $CONFIG.local.loyalty_value_stamp_path + '?' + params.join('&');
}

function LVStampCallback(data) {
	var merchant_id = $.urlParam('id') || $.urlParam('merchant_id');

	document.location.href = $CONFIG.local.loyalty_value_stamp_success_path + '?amount=' + $.urlParam('amount') + '&notices=' + encodeURIComponent(data.notices.join(' ')) + '&merchant_id=' + merchant_id;
}

function LVStampErrorCallback(data) {
	var merchant_id = $.urlParam('id') || $.urlParam('merchant_id');
	
  var errors = data && (data.errors && data.errors.join(' ') || data.error_message) || !data && $LOCALE.get('lost_connection') || '';
	errors = encodeURIComponent(errors);
	
	document.location.href = $CONFIG.local.loyalty_value_stamp_failure_path + '?merchant_id=' + merchant_id + '&amount=' + $.urlParam('amount')+ '&errors=' + errors;
}

function LVStampShowSuccess(){
  var obj = {};
	obj.id = $.urlParam('merchant_id') || $.urlParam('id');
	obj.amount = $.urlParam('amount');
	obj.notices = $.urlParam('notices');
	
	$.extend(obj, merchantsGetInfo(obj.id));

	var html = templateReplaceVars($('.mainContent').html(), obj);

	$('.mainContent').html(html);
}
function LVStampShowFailure(){
  var obj = {};
	obj.id = $.urlParam('merchant_id') || $.urlParam('id');
	obj.amount = $.urlParam('amount');
	obj.errors = '';
	
	if($.urlParam('errors')){
	  obj.errors = $.urlParam('errors');
	}

	$.extend(obj, merchantsGetInfo(obj.id));

	var html = templateReplaceVars($('.mainContent').html(), obj);

	$('.mainContent').html(html);
}

