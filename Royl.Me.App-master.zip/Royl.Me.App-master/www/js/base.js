function app_init() {
	console.log('app_init'+version);

	onDeviceReadyPushNotification();
	
	//currentPositionTracker();

	$_DEVICE = device;

	dbCheckInstall();
	
	console.log(navigator);

	if (document.location.href.match(/my_profile.html/)) {
		cameraOnDeviceReady();
	}
	
	requestsSendFromQueue();
}

function error_occurred(e, message) {
	console.log(e, message);
	var error_occurred_num = $.urlParam('error_occurred') ? parseInt($.urlParam('error_occurred')) : 0;
	if (error_occurred_num <= 3) {
		alert(message || $CONFIG.error_message);
		document.location.href = $CONFIG.local.root_path + '?error_occurred=' + (error_occurred_num + 1);
	} else {
		alert($CONFIG.second_error_message);
	}
}

$(function(){
	document.addEventListener('deviceready', app_init, false);
  // document.addEventListener('deviceready', function(){	
	// setTimeout(app_init, 1000);	
	// }, false);
});

