function rewardAddCode(key) {
	var code = $('#enterAmount');
	//if (code.val().length < 10) {
  code.val(code.val() + key);
	//}
}

function rewardEmptyCode() {
	var code = $('#enterAmount');

	code.val('');
}

function rewardBackSpace() {
	var code = $('#enterAmount');

	if (code.val().length > 0) {
		code.val(code.val().slice(0, -1));
	}
}

function rewardEnterVisitAmount() {
	if ($('#enterAmount').val().length == 0) {
		return false;
	}

	merchant_id = $.urlParam('merchant_id') || $.urlParam('id');

	document.location.href = $CONFIG.local.enter_amount_stamp_path + '?amount=' + $('#enterAmount').val() + '&merchant_id=' + merchant_id;
}

function rewardEnterRewardAmount() {
	if ($('#enterAmount').val().length == 0) {
		return false;
	}

	merchant_id = $.urlParam('merchant_id') || $.urlParam('id');

	var params = [];
	
  params.push('reward_id=' + $.urlParam('reward_id') );
	params.push('amount=' + $('#enterAmount').val());
	params.push('items=' + $.urlParam('items'));
	params.push('reward_prize=' + $.urlParam('reward_prize'));
	params.push('reward_type=' + $.urlParam('reward_type'));
	params.push('reward_name=' + encodeURIComponent($.urlParam('reward_name')));
	params.push('campaign_id=' + $.urlParam('campaign_id'));
	params.push('merchant_id=' + merchant_id);

	document.location.href = $CONFIG.local.reward_enter_amount_stamp_path + '?'+params.join('&');
	
}

function rewardEnterItems() {
	if ($('#enterAmount').val().length == 0) {
		return false;
	}

	merchant_id = $.urlParam('merchant_id') || $.urlParam('id');
	
	var params = [];
	
  params.push('reward_id=' + $.urlParam('reward_id') );
	params.push('items=' + $('#enterAmount').val());
	params.push('reward_prize=' + $.urlParam('reward_prize'));
	params.push('items_should_be=' + $.urlParam('items_should_be'));	
	params.push('reward_type=' + $.urlParam('reward_type'));
	params.push('reward_name=' + encodeURIComponent($.urlParam('reward_name')));
	params.push('campaign_id=' + $.urlParam('campaign_id'));
	params.push('merchant_id=' + merchant_id);

	document.location.href = $CONFIG.local.reward_enter_amount_path + '?'+params.join('&');
}

function rewardShowVisitStamp(show_menu) {
	var obj = {};
	obj.id = $.urlParam('merchant_id') || $.urlParam('id');
	obj.amount = $.urlParam('amount');
	
	if($.urlParam('errors')){
	  obj.errors = $.urlParam('errors');
	}

	$.extend(obj, merchantsGetInfo(obj.id));

	var html = templateReplaceVars($('.mainContent').html(), obj);

	$('.mainContent').html(html);

	if (show_menu)
		merchantSetMenu(obj, 'enter-amount');

	setBackObserve();

	closePreloader();
}

function rewardShowRewardStamp(show_menu) {
	var obj = {};
	obj.id = $.urlParam('merchant_id') || $.urlParam('id');
	obj.amount = $.urlParam('amount');

	$.extend(obj, merchantsGetInfo(obj.id));

	obj.reward_name = $.urlParam('reward_name');
	obj.reward_id = $.urlParam('reward_id');
	obj.reward_type = $.urlParam('reward_type');
	obj.reward_prize = $.urlParam('reward_prize') && $.urlParam('reward_prize') != 'null' ? $.urlParam('reward_prize') : null;	
	obj.items = $.urlParam('items') && $.urlParam('items') != 'null' ? $.urlParam('items') : null;	
	
	if(obj.reward_prize && obj.items){
		obj.reward_name = obj.items+' '+obj.reward_prize;
	}

	var html = templateReplaceVars($('.mainContent').html(), obj);

	$('.mainContent').html(html);

	if (show_menu)
		merchantSetMenu(obj, 'reward-enter-amount');

	setBackObserve();

	closePreloader();
}

function rewardKeybordInit() {
	$('div[data-value]').bind('click', function() {
		rewardAddCode($(this).data('value'));
	});

	$('#deleteButton').bind('click', function() {
		rewardEmptyCode();
	});
}

function rewardShowVisitEnterAmount() {
	var merchant = new Object();
	merchant.id = $.urlParam('merchant_id') || $.urlParam('id');

	$.extend(merchant, merchantsGetInfo(merchant.id));

	var html = templateReplaceVars($('.mainContent').html(), merchant);
	$('.mainContent').html(html);

	rewardKeybordInit();

	setBackObserve();

	merchantSetMenu(merchant, 'enter-amount');

	closePreloader();
}

function rewardStampCallback(data) {
	var merchant_id = $.urlParam('id') || $.urlParam('merchant_id');
	document.location.href = $CONFIG.local.enter_amount_stamp_success_path + '?amount=' + $.urlParam('amount') + '&merchant_id=' + merchant_id;
}

function rewardStampErrorCallback(data) {
	var merchant_id = $.urlParam('id') || $.urlParam('merchant_id');
	var errors = data && (data.errors && data.errors.join(' ') || data.error_message) || !data && $LOCALE.get('lost_connection') || '';
	errors = encodeURIComponent(errors);
	
	document.location.href = $CONFIG.local.enter_amount_stamp_failure_path + '?merchant_id=' + merchant_id + '&amount=' + $.urlParam('amount')+ '&errors=' + errors;
}

function rewardStampRewardCallback(data) {
	var merchant_id = $.urlParam('id') || $.urlParam('merchant_id');
  var notices =  data.notices && encodeURIComponent(data.notices.join(' ')) || '';
	document.location.href = $CONFIG.local.reward_enter_amount_stamp_success_path + '?amount=' + $.urlParam('amount') + '&notices=' + notices + '&merchant_id=' + merchant_id;
}

function rewardStampRewardErrorCallback(data) {
	var merchant_id = $.urlParam('id') || $.urlParam('merchant_id');

	var errors = data && (data.errors && data.errors.join(' ') || data.error_message) || !data && $LOCALE.get('lost_connection') || '';
	errors = encodeURIComponent(errors);
	
	document.location.href = $CONFIG.local.reward_enter_amount_stamp_failure_path + '?merchant_id=' + merchant_id + '&amount=' + $.urlParam('amount')+ '&errors=' + errors;
}

function rewardShowVisitStampSuccess() {
	rewardShowVisitStamp(true);
}

function rewardShowVisitStampFailure() {
	rewardShowVisitStamp(true);
}

function rewardShowRewardStampSuccess() {
	var obj = {};

	obj.notices = $.urlParam('notices');
	obj.merchant_id = $.urlParam('merchant_id') || $.urlParam('id');

	$.extend(obj, merchantsGetInfo(obj.merchant_id));

	var html = templateReplaceVars($('.mainContent').html(), obj);

	$('.mainContent').html(html);

	merchantSetMenu(obj, 'reward-enter-amount');

	setBackObserve();

	closePreloader();
}

function rewardShowRewardEnterItems(){
	var obj = {};
  obj.merchant_id = $.urlParam('merchant_id') || $.urlParam('id');

	$.extend(obj, merchantsGetInfo(obj.merchant_id));
	
	obj.enter_the_number_of_items_purchased = $LOCALE.get('enter_the_number_of_items_purchased', {title: $.urlParam('reward_prize')});
	var html = templateReplaceVars($('.mainContent').html(), obj);
	$('.mainContent').html(html);
	
	rewardShowRewardEnterAmount();
}

function rewardShowRewardEnterAmount() {
	var obj = {};
	obj.merchant_id = $.urlParam('merchant_id') || $.urlParam('id');

	$.extend(obj, merchantsGetInfo(obj.merchant_id));

	obj.reward_name = $.urlParam('reward_name');
	obj.reward_id = $.urlParam('reward_id');
	obj.reward_type = $.urlParam('reward_type');
	obj.max_redeem = $.urlParam('max_redeem');

	if($.urlParam('items')){
	  obj.reward_apllied = $LOCALE.get('reward_will_be_earned', {items: $.urlParam('items'), items_should_be: $.urlParam('items_should_be')});
	} else {
		obj.reward_apllied = $LOCALE.get('reward_to_be_applied', {title: obj.reward_name});
	}

	var html = templateReplaceVars($('.mainContent').html(), obj);

	$('.mainContent').html(html);

	rewardKeybordInit();

	setBackObserve();

	merchantSetMenu(obj, 'reward-enter-amount');

	closePreloader();
}

function rewardSelectedReward() {
	var merchant_id = $.urlParam('id') || $.urlParam('merchant_id');
	var li_on = $('#position li.on');
	var reward_name = $('.wrap').eq(li_on.index()).find('.reward-title').html();
	
	var merchant = merchantsGetInfo(merchant_id);
	console.log(merchant);
	var url = $CONFIG.local.reward_enter_amount_path;
	
	var params = [];
	
	if(li_on.data('type') == 'punchcard' ){
		url = $CONFIG.local.reward_enter_items_path;
		
		params.push('reward_prize=' + encodeURIComponent(li_on.data('reward-prize')));
		params.push('items_should_be=' + encodeURIComponent(li_on.data('items-should-be')));
	}
	
	if(merchant['merchant_royl_me.qr_code_enabled']){
	  url = $CONFIG.local.scan_code_for_reward_path;
	}
	
	params.push('reward_id=' + li_on.data('id'));
	params.push('reward_type=' + li_on.data('type'));
	params.push('reward_name=' + encodeURIComponent(reward_name));
	params.push('campaign_id=' + li_on.data('campaign'));
	params.push('merchant_id=' + merchant_id);

	document.location.href = url +'?'+params.join('&');
}

function rewardShowRewardsSlider() {
	var merchant_id = $.urlParam('id') || $.urlParam('merchant_id');

	var res = authSignedRequest($CONFIG.moe.show_merchant_url.replace(/_MERCHANT_ID_/, merchant_id), 'GET', {
		with_balance : 'yes',
		with_consumer_data_for_merchant : 'yes',
		with_punchcards : 'yes'
	});

	if (!res || !res.success) {
		document.location.href = $CONFIG.local.my_merchants_path;
		return;
	}

	var obj = res.merchant;

	merchantsSaveInfo(obj);

	var template_slide = $('.wrap.template')[0].outerHTML;
	var template_navig = $('#position li.template')[0].outerHTML;
		
  var loyl_me_rewards = [];
  var moe_coupons  = [];
  var ss_rewards = [];
  var ss_campaigns = [];
  var moe_daily_deal_coupons = [];
  var punchcards = res.punchcards;
  
  if (punchcards && punchcards.length > 0){
  	for (i in punchcards) {
  		var object = {
					title : punchcards[i].title,
					description : $LOCALE.get('items_from', {items: punchcards[i].already_visited, items_should_be: punchcards[i].should_count_visits}),
					reward_id : punchcards[i].id,
					reward_type : 'punchcard',
					reward_prize: punchcards[i].reward_prize,
					campaign_id: punchcards[i].loyalty_campaign_id,
					
					items_should_be: punchcards[i].should_count_visits
				};
				
			  if (punchcards[i].cover_image && punchcards[i].cover_image.cover_image && punchcards[i].cover_image.cover_image.view && punchcards[i].cover_image.cover_image.view.url && punchcards[i].cover_image.cover_image.view.url.length > 0) {
          object.cover = "background-image:url('"+$CONFIG.moe.url + punchcards[i].cover_image.cover_image.view.url+"');";
        }

				$('.wrap:last').after(templateReplaceVars(template_slide, object));
				$('#position li:last').after(templateReplaceVars(template_navig, object));
  	}
  }

	if (res.consumer_balance) {
		moe_coupons = res.consumer_balance.moegenius.coupons;

		if (moe_coupons.length > 0) {
			for (i in moe_coupons) {
				var object = {
					title : moe_coupons[i].discount_name,//+'-'+moe_coupons[i].code,
					description : '',//moe_coupons[i].discount_message,
					reward_id : moe_coupons[i].id,
					expiration_date: moe_coupons[i].expiration_date ? $LOCALE.get('expiration_date', {date: moe_coupons[i].expiration_date}) : '',
					reward_type : 'coupon'
				};

				$('.wrap:last').after(templateReplaceVars(template_slide, object));
				$('#position li:last').after(templateReplaceVars(template_navig, object));
			}
		}

		if (res.consumer_balance.enabled_loyalty == 'loyl_me') {
			loyl_me_rewards = res.consumer_balance.loyl_me.loyalty_campaigns.rewards;

			if (loyl_me_rewards.length > 0) {
				for (var i in loyl_me_rewards) {
					
					var slide = 0;
					var count = loyl_me_rewards[i].earned;
					var title =  loyl_me_rewards[i].title+(count > 1 ? " (x"+count+")" : '');
					// while(slide < count){
						// slide += 1;
						
						var object = {
							title : title,
							description : '',
							reward_id : loyl_me_rewards[i].id,
							reward_type : loyl_me_rewards[i].type,
							campaign_id: loyl_me_rewards[i].loyalty_campaign_id,
							expiration_date: loyl_me_rewards[i].expiration_date ? $LOCALE.get('expiration_date', {date: loyl_me_rewards[i].expiration_date}) : ''
							
						};

            if (loyl_me_rewards[i].cover_image && loyl_me_rewards[i].cover_image.cover_image && loyl_me_rewards[i].cover_image.cover_image.view && loyl_me_rewards[i].cover_image.cover_image.view.url && loyl_me_rewards[i].cover_image.cover_image.view.url.length > 0) {
              object.cover = "background-image:url('"+$CONFIG.moe.url + loyl_me_rewards[i].cover_image.cover_image.view.url+"');";
            }
	
						$('.wrap:last').after(templateReplaceVars(template_slide, object));
						$('#position li:last').after(templateReplaceVars(template_navig, object));
					// }
				}
			}
		}

		moe_daily_deal_coupons = res.consumer_balance.moegenius.daily_deal_coupons;

		if (moe_daily_deal_coupons.length > 0) {
			for (i in moe_daily_deal_coupons) {
				var object = {
					title : $LOCALE.get('livingsocial_deal') + ' ' + moe_daily_deal_coupons[i]["groupon_deal.title"],
					description : $LOCALE.get('voucher_code') + ' ' + moe_daily_deal_coupons[i].code,
					reward_id : moe_daily_deal_coupons[i].id,
					reward_type : 'daily_deal_coupon'
				};

				$('.wrap:last').after(templateReplaceVars(template_slide, object));
				$('#position li:last').after(templateReplaceVars(template_navig, object));
			}
		}

		if (res.consumer_balance.enabled_loyalty == 'SS'){
			ss_campaigns = res.consumer_balance.sticky_street.campaigns;

			if (ss_campaigns && ss_campaigns.length > 0) {
				for (i in ss_campaigns) {
					var ss_campaign = ss_campaigns[i];
					var key, key_item, key_item_id;

					if (ss_campaign.type == 'points') {
						key_item_id = 'id';
						key_title = 'description';
						balance = ss_campaign['balance'];
						needed_to_redeem_key = 'needed_to_redeem';
					} else {//buyx
						key_title = 'name';
						key_item_id = 'item_id';
						needed_to_redeem_key = 'earn_ratio';
					}

					if (ss_campaign['rewards'].length > 0) {

						ss_rewards = ss_rewards.concat(ss_campaign['rewards']);

						for (y in ss_campaign['rewards']) {
							var reward = ss_campaign['rewards'][y];

							if (ss_campaign.type == 'points' || reward.earned > 0) {

								var object = {
									title : reward[key_title],
									description : '',
									reward_id : reward[key_item_id],
									reward_type : ss_campaign.type,
									campaign_id : ss_campaign.id
								};

								$('.wrap:last').after(templateReplaceVars(template_slide, object));
								$('#position li:last').after(templateReplaceVars(template_navig, object));
							}
						}
					}
				}
			}
		}
	}

	if ((!moe_coupons || moe_coupons.length <= 0) && 
	    (!moe_daily_deal_coupons || moe_daily_deal_coupons.length <= 0) && 
	    (!ss_rewards || ss_rewards.length <= 0) && (!loyl_me_rewards || loyl_me_rewards.length <= 0) &&
	    (!punchcards || punchcards.length <= 0)) {
		$('#slider').html( $LOCALE.get('empty_rewards') ).addClass('empty');
		$('#claim-cont').hide();
	}
		
	$('.wrap.template').remove();
	$('#position li.template').remove();

	var html = templateReplaceVars($('.mainContent').html(), obj);

	$('.mainContent').html(html);

	if ($('#position li').length > 0) {
		$('#position li:first').addClass('on');
		setSlider();
	}

	merchantSetMenu(obj, 'reward-enter-amount');

	setBackObserve();

	closePreloader();
}
