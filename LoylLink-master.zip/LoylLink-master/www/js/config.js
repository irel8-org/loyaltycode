//var $ = jQuery.noConflict();
var $CONFIG = new Object;

var $_DEVICE = {};
var $_READY = false;
var $_DB = false;
var $_SCOPE = false;
var $_STATE = false;
var $LOADING = false;

$CONFIG.moe  = new Object;
$CONFIG.local  = new Object;
$CONFIG.db     = new Object;
$CONFIG.locale = new Object;
$CONFIG.push_notifications = new Object;
$CONFIG.debug = false;
$CONFIG.debug = true;
$CONFIG.verify_first_use = false;

$CONFIG.locale.available = ['en', 'es', 'it'];
$CONFIG.locale.base = 'en';
$CONFIG.locale.current = window.localStorage.getItem("user_locale") || 'en';

$CONFIG.snow_shoe = new Object;
$CONFIG.snow_shoe.debug = $CONFIG.debug;

$CONFIG.debug_code = $CONFIG.debug ? '9EWDbwm9o5uNtt10nQ7o53BB2Na1Jh2' : '';
$CONFIG.error_message_should_be_authorized = 'You need to sign in or sign up before continuing.';
$CONFIG.error_message = "Rubbish! We've encountered an issue. We'll direct you back to the main page momentarily.  Our apologies.";
$CONFIG.second_error_message = "Rubbish!  We've encountered a bugger. Tap your home button twice (the round button on your iPhone), select Royl.Me and slide it to the top.  Then come on back.  Our sincere apologies - cheers!";

////////// MOE SETTINGS //////////
$CONFIG.moe.host = 'http://moegenius.com';
//$CONFIG.moe.host = document.location.host == 'royal' ?  'http://loc.my:4500' :  'http://moegenius.com';
//$CONFIG.moe.host = 'http://loc.my:4500';

$CONFIG.moe.reseller_id = '';
$CONFIG.moe.without_reseller_ids = [];
$CONFIG.moe.api_version = 1.1;

$CONFIG.moe.namespace = '/consumer_api';

$CONFIG.moe.routes = {};

$CONFIG.moe.routes['session_create'] = '/sessions';

$CONFIG.moe.routes['facebook_session_create'] = '/sessions/sign_in_via_facebook';

$CONFIG.moe.routes['session_destroy'] = '/sessions/_EMPLOYEE_ID_';

$CONFIG.moe.routes['registration'] = '/registrations';

$CONFIG.moe.routes['reset_password_code'] = '/passwords';

$CONFIG.moe.routes['reset_password_change'] = '/passwords/_EMPLOYEE_ID_';

$CONFIG.moe.routes['geo_notification_request'] = '/notifications/geo_request';

$CONFIG.moe.routes['merchants'] = '/merchants';

$CONFIG.moe.routes['merchants_availalbe_for_employee'] = '/merchants/availalbe_for_employee';

$CONFIG.moe.routes['roles'] = '/merchants/_MERCHANT_ID_/availalbe_roles_for_employee';

$CONFIG.moe.routes['search_merchants'] = '/merchants/search';

$CONFIG.moe.routes['create_merchants'] = '/merchants';

$CONFIG.moe.routes['show_merchant'] = '/merchants/_MERCHANT_ID_';

$CONFIG.moe.routes['update_consumer'] = '/consumers/_CONSUMER_ID_';

$CONFIG.moe.routes['show_consumer'] = '/consumers/_CONSUMER_ID_';

$CONFIG.moe.routes['balances_consumer'] = '/consumers/balances';

$CONFIG.moe.routes['reconfirm_email'] = '/consumers/_CONSUMER_ID_/send_confirmation_instruction';

$CONFIG.moe.routes['link_to_facebook_consumer'] = '/consumers/_CONSUMER_ID_/link_to_facebook';

$CONFIG.moe.routes['snowshoe'] = '/snow_shoe/callback';
$CONFIG.moe.routes['snowshoe_check_stamp'] = '/snow_shoe/check_stamp';
$CONFIG.moe.routes['snowshoe_assign_stamp'] = '/snow_shoe/assign_stamp/_EMPLOYEE_ID_';


$CONFIG.moe.routes['find_merchant_by_stamp'] = '/snow_shoe/merchant_by_stamp';

$CONFIG.moe.routes['customers'] = '/customers';

$CONFIG.moe.routes['customer'] = '/customers/_CUSTOMER_ID_';
$CONFIG.moe.routes['update_customer'] = '/customers/_CUSTOMER_ID_';


$CONFIG.moe.routes['employees'] = '/employees';

$CONFIG.moe.routes['employee'] = '/employees/_EMPLOYEE_ID_';
$CONFIG.moe.routes['employee_archive'] = '/employees/_EMPLOYEE_ID_/archive';
$CONFIG.moe.routes['employee_stamp_remove'] = '/employees/_EMPLOYEE_ID_/merchant_snow_shoe_stamps/_STAMP_ID_';


$CONFIG.moe.routes['purchases'] = '/purchases';


$CONFIG.moe.url = function(key, params){
	var key2 = key.replace(/prepared_/, '');
	var route;
	
  if(!(route = $CONFIG.moe.routes[key2.replace(/_url/,'')])){
	  alert('there are no such route');
	  return;
	}
	  
	var url = $CONFIG.moe.host+$CONFIG.moe.namespace+route;
	
  if(key != key2)
    url = url.replace(/_CONSUMER_ID_/, window.localStorage.getItem("consumer_id"));
 
	if(params){
		for(i in params){
			url = url.replace(i, params[i]);
		}
	}

	return url;
};




//////////////////////////////////

////////// LOCAL SETTINGS //////////
$CONFIG.local.root_path = '#/app/home';

$CONFIG.local.verification_path = $CONFIG.local.root_path;// '#/app/verification';
$CONFIG.local.not_verified_path = $CONFIG.local.root_path;//'#/app/not_verified';

$CONFIG.local.login_path = '#/app/login';
$CONFIG.local.signup_path = '#/app/signup';
$CONFIG.local.forgot_password_path = '#/app/forgotpassword';

$CONFIG.local.add_merchants_path = '#/app/find_merchant_by_stamp';

$CONFIG.local.sidebar_path = '#/app/_sidebar';

$CONFIG.local.welcome_path = '#/app/welcome';
$CONFIG.local.my_merchants_path = '#/app/my_merchants';
$CONFIG.local.search_merchants_path = '#/app/search_merchants';
$CONFIG.local.show_merchant_path = '#/app/show_merchant';
$CONFIG.local.merchant_settings_path = '#/app/merchant_settings';

$CONFIG.local.merchant_menu_path = '#/app/_merchant_menu';
$CONFIG.local.merchant_index_menu_path = '#/app/_merchant_index_menu';

$CONFIG.local.scan_code_path = '#/app/merchant_qr_code';
$CONFIG.local.scan_code_for_reward_path = '#/app/merchant_qr_code_reward';

$CONFIG.local.enter_amount_path = '#/app/enter_amount';
$CONFIG.local.enter_amount_stamp_path = '#/app/enter_amount_visit_total_stamp_screen';
$CONFIG.local.enter_amount_stamp_failure_path = '#/app/enter_amount_visit_total_failure';
$CONFIG.local.enter_amount_stamp_success_path = '#/app/enter_amount_visit_total_success';

$CONFIG.local.reward_slider_path = '#/app/reward_slider';
$CONFIG.local.reward_enter_amount_path = '#/app/reward_enter_amount';
$CONFIG.local.reward_enter_items_path = '#/app/reward_enter_items';

$CONFIG.local.reward_enter_amount_stamp_path = '#/app/reward_visit_total_stamp_screen';
$CONFIG.local.reward_enter_amount_stamp_failure_path = '#/app/reward_visit_total_failure';
$CONFIG.local.reward_enter_amount_stamp_success_path = '#/app/reward_visit_total_success';

$CONFIG.local.loyalty_value_slider_path = '#/app/loyalty_value_slider';
$CONFIG.local.loyalty_value_enter_amount_path = '#/app/loyalty_value_enter_amount';
$CONFIG.local.loyalty_value_stamp_path = '#/app/loyalty_value_stamp_screen';
$CONFIG.local.loyalty_value_stamp_failure_path = '#/app/loyalty_value_stamp_failure';
$CONFIG.local.loyalty_value_stamp_success_path = '#/app/loyalty_value_stamp_success';


$CONFIG.local.my_profile_menu_path = '#/app/_profile_menu';
$CONFIG.local.my_profile_path = '#/app/my_profile';
$CONFIG.local.my_profile_phone_path = '#/app/my_profile_phone';
$CONFIG.local.my_profile_email_path = '#/app/my_profile_email';
$CONFIG.local.my_profile_password_path = '#/app/my_profile_password';
$CONFIG.local.my_profile_birthday_path = '#/app/my_profile_birthday';
$CONFIG.local.my_profile_language_path = '#/app/my_profile_language';
$CONFIG.local.my_facebook_profile_path = '#/app/my_facebook_profile';
$CONFIG.local.find_merchant_by_stamp_path = '#/app/find_merchant_by_stamp';

$CONFIG.local.add_loyalty_card_path = '#/app/merchant_add_loyalty_card';
$CONFIG.local.add_loyalty_card_success_path = '#/app/merchant_add_loyalty_card_success';

// for working with camera
$CONFIG.local.picture_source = null;
$CONFIG.local.destination_type = null;
$CONFIG.local.file_system = null;
//////////////////////////////////

$CONFIG.requests_add_to_queue = false;

$CONFIG.push_notifications.sender_id = '885385952808';
$CONFIG.push_notifications.distination_to_merchant = 0.25;//km
$CONFIG.push_notifications.period_cheking_distance = 40*1000;//40 seconds
$CONFIG.push_notifications.period_sending_pn = 5 * 60 * 60 * 1000;// 5 hours

$CONFIG.db.connect = null;

$CONFIG.db.name = 'DB19.db';
$CONFIG.db.size = 100*1024*1024;
