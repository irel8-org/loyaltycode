function requestsAddToQueue(url, data, type, identificator) {
	dbCheckInstall();

	if (!identificator)
		identificator = (new Date()).getTime() + '' + window.localStorage.getItem("employee_id");

	sql = 'INSERT INTO requests (url, data, type, status, identificator) VALUES (?, ?, ?, ?, ?)';

	$CONFIG.db.connect.transaction(function(tx) {
		tx.executeSql(sql, [url, window.JSON.stringify(data), type, 'new', identificator], function(tx, result) {

		});
	});
}

function requestsSetAsDone(id) {
	$CONFIG.db.connect.transaction(function(tx) {
		tx.executeSql('UPDATE requests SET status = ? WHERE id = ?', ['done', id], function(tx, result) {

		});
	});
}

function requestsCanBeSend() {
	if($CONFIG.debug) return true;
	
	networkState = navigator && navigator.network && navigator.network.connection.type;

	return !((networkState == Connection.NONE) || (networkState == Connection.UNKNOWN));
}

function requestsSendRequest(db_item) {
	console.log(db_item);
	$.ajax({
		'url' : db_item.url,
		'data' : window.JSON.parse(db_item.data),
		'type' : db_item.type,
		timeout : 10 * 1000,
		cache : false,
		'error' : function(data, textStatus, errorThrown) {
			console.log(data);
			if (textStatus === "timeout") {
				//nothing, will try again later
			} else if(data.responseText) {
				obj = JSON.parse(data.responseText);
				
				if(obj.error_code == 'this_request_already_made'){
					requestsSetAsDone(db_item.id);
				}
			}
		},
		'success' : function(data) {
			requestsSetAsDone(db_item.id);
		}
	});
}

function requestsSendFromQueue() {
	if (!requestsCanBeSend())
		return;
		
  dbCheckInstall();

	$CONFIG.db.connect.transaction(function(tx) {
		tx.executeSql('SELECT * FROM requests WHERE status = ?', ['new'], function(tx, result) {
			var len = result.rows.length, i;

			if (len <= 0)
				return;

			for ( i = 0; i < len; i++) {
				requestsSendRequest(result.rows.item(i));
			};

		});
	});
}
