
  function authCleanUserData() {
    console.log('authCleanUserData');
    window.localStorage.removeItem("auth_token");
    window.localStorage.removeItem("employee_id");
    // window.localStorage.removeItem("user_email");
    // window.localStorage.removeItem("user_unconfirmed_email");
    // window.localStorage.removeItem("user_birthday");
    // window.localStorage.removeItem("user_first_name");
    // window.localStorage.removeItem("user_last_name");
    // window.localStorage.removeItem("user_name");
    // window.localStorage.removeItem("user_locale");
    // window.localStorage.removeItem("user_facebook_id");
  };
  
function authSignedParams(params){
    params = params == undefined ? new Object : params;
    
    params.auth_token = window.localStorage.getItem("auth_token");
    params.reseller_id = $CONFIG.moe.reseller_id;
    params.without_reseller_ids = $CONFIG.moe.without_reseller_ids;
    params.api_version = $CONFIG.moe.api_version;
    params.debug_code = $CONFIG.debug_code;
    params.format = 'json';
    params.scope = 'user';
    
    var device_attrs = authDeviceAttributes();
    
    jQuery.extend(params, device_attrs);
    
    return params;
}


function authDeviceAttributes() {
    if (!$_DEVICE)
      return {};

    return {
      device : {
        model : $_DEVICE.model,
        platform : $_DEVICE.platform,
        uuid : $_DEVICE.uuid,
        version : $_DEVICE.version,
        token : window.localStorage.getItem("device_token")
      }
    };
  }