$.urlParam = function(name) {
	//console.log(name, document.location.href);
	var results = new RegExp('[\\?&]' + name + '=([^&#]*)').exec(document.location.href);
	return (results !== null) ? decodeURIComponent(results[1]) : null;
}

function floatToS(val){
	if(val){
		if((val+'').match(/\.\d{3}/)){
			val = val.toFixed(2);
		}
	}
	
	return val;
}
