angular.module('loylMeApp.data.customer', ['loylMeApp.dbConfig']).factory('Customer', function($http, $q, DB) {
  var self = this;

  self.prepare = function(customer) {
    //console.log('prepare', customer);
    if (!customer)
      return;

    if (!customer.starRating)
      customer.starRating = customer['merchant_customer.segment_index'] + 1;

    customer.maxStarRating = 5;

    if (!customer.avg_ticket_size)
      customer.avg_ticket_size = customer['merchant_customer.avg_ticket_size'];

    if (!customer.purchases_amount)
      customer.purchases_amount = customer['merchant_customer.purchases_amount'];

    if (!customer.recency)
      customer.recency = customer['merchant_customer.recency'];

    if (!customer.locale)
      customer.locale = customer['consumer.locale'];

    if (!customer.enabled_loyalty && customer.loyalty_balance)
      customer.enabled_loyalty = customer.loyalty_balance.enabled_loyalty;

    if (customer.photo && customer.photo.photo && customer.photo.photo.view)
      customer.photo_url = customer.photo.photo.view.url;

    if (customer.enabled_loyalty == "loyl_me") {
      if (!customer.loyalty_value && customer.loyalty_balance)
        customer.loyalty_value = customer.loyalty_balance.loyl_me.loyalty_value;

      if (!customer.count_rewards && customer.loyalty_balance)
        customer.count_rewards = customer.loyalty_balance.loyl_me.rewards_count;

      if (!customer.points_balance && customer.loyalty_balance)
        customer.points_balance = customer.loyalty_balance.loyl_me.points_balance;
    } else {// @todo ss

    }

    return customer;

  };

  self.sync = function(params, customer_id, extended) {
    var deferred = $q.defer();

    var customers = [];
    
 //   DB.init();

    url = customer_id !== undefined ? $CONFIG.moe.url('customer', {
      '_CUSTOMER_ID_' : customer_id
    }) : $CONFIG.moe.url('customers', params);

    $http({
      method : 'GET',
      url : url,
      params : authSignedParams(params)
    //  timeout : 5000
    }).success(function(data) {
      
      console.log(url + ': succes: '+data.success);
      
      if(data.success){
        deferred.resolve( extended ? data : (customer_id ? data.customer : data.customers));

        self.sync_customers( customer_id ? data.customer : data.customers);
        
        console.log('synced_customers');
        
      } else {
        deferred.reject(data);
      }    

    }).error(function(data) {
      console.log(url + ': error');

      deferred.reject(data);
    });

    return deferred.promise;
  };

  self.sync_customers = function(customers) {
    console.log('customers:');
    
    if (customers['id'])
      customers = [customers];

    angular.forEach(customers, function(data, key) {

      data = self.prepare(data);
      if (data) {
        customers[key] = data;

        self.find(data.id).then(function(customer) {
          if (customer) {
            DB.update('customers', data.id, data);
          } else {
            DB.insert('customers', data);
          }
        });
      }

    });
  };

  self.all = function(limit, page, query) {

    if (limit) {

      offset = page ? limit * (page - 1) : 0;

      limit = ' LIMIT ' + offset + ', ' + limit;
    }

    if (query && query.length > 0) {
      query = ' WHERE first_name LIKE "%' + query + '%" OR last_name LIKE "%' + query + '%"';
    } else {
      query = '';
    }
    console.log('SELECT * FROM customers ' + query + limit);
    return DB.query('SELECT * FROM customers ' + query + limit).then(function(result) {
      customers = DB.fetchAll(result);

      angular.forEach(customers, function(customer, key) {

        if (customer) {
          customer = self.prepare(customer);
          customers[key] = customer;

        }
      });

      return customers;
    });
  };

  self.find = function(id, update, params, extended) {
    if (update) {
      return self.sync(params, id, extended).then(function(data) {

        $.extend(data, self.prepare(data['customer']));

        return data;

      });
    } else {
      console.log('DB');
      console.log(DB);
      return DB.query('SELECT * FROM customers WHERE id = ? LIMIT 1', [id]).then(function(result) {
        return self.prepare(DB.fetch(result));
      });
    }
  };

  self.find_by_card = function(card_number, update) {
    if (update) {
      return self.sync({card_number: card_number}, 0).then(function(data) {

        $.extend(data, self.prepare(data['customer']));

        return data;

      });
    } else {
      console.log('DB');
      console.log(DB);
      return DB.query('SELECT * FROM customers WHERE card_number = ? LIMIT 1', [card_number]).then(function(result) {
        return self.prepare(DB.fetch(result));
      });
    }
  };
  return self;
});
