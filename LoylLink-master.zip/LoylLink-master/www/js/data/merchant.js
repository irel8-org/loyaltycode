angular.module('loylMeApp.data.merchant', ['loylMeApp.dbConfig'])

.factory('Merchant', function($http, $q, DB) {
  var self = this;
  

  self.availableList = function(params) {
    var deferred = $q.defer();

    var merchants = [];

    url = $CONFIG.moe.url('merchants_availalbe_for_employee', params);

    $http({
      method : 'GET',
      url : url,
      params : authSignedParams(params)
 //     timeout : 5000
    }).success(function(data) {
      console.log(url + ': success');
  
      deferred.resolve(data);

    }).error(function() {
      console.log(url + ': error');
      deferred.reject();
    });

    return deferred.promise;
  };
  
  return self;
});
