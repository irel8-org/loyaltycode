angular.module('loylMeApp.data.db', ['loylMeApp.dbConfig']).factory('DB', function($q, DB_CONFIG, $cordovaSQLite) {
  var self = this;
  self.db = null;
  self.db_type = null;

  self.init = function() {
    if (self.db)
      return;

    self.db = $_DB;

    angular.forEach(DB_CONFIG.tables, function(table, table_name) {
      var columns = [];

      angular.forEach(table.columns, function(column) {
        columns.push(column.name + ' ' + column.type);
      });

      var query = 'CREATE TABLE IF NOT EXISTS ' + table_name + ' (' + columns.join(',') + ')';
      self.query(query);
      console.log('Table ' + table_name + ' initialized');
    });
  };

  self.insert = function(table_name, attributes) {
    console.log(table_name, attributes);
    if (!attributes || attributes.length == 0) {
      console.log('attributes blank');
      return false;
    }

    var table = DB_CONFIG.tables[table_name];

    if (!table) {
      console.log('there are no such table: ' + table_name);
      return false;
    }

    //var ex_columns = [];

    var columns = [];
    var values = [];
    var qvalues = [];

    angular.forEach(table.columns, function(column) {
      //ex_columns.push(column.name);

      // console.log(column, attributes);
      if (attributes[column.name] != undefined) {
        columns.push(column.name);
        values.push(attributes[column.name]);
        qvalues.push('?');
      }
    });

    if (columns.length == 0) {
      console.log('there are no such columns');
      return false;
    }

    return self.query("INSERT INTO " + table_name + "(" + columns.join(', ') + ") VALUES (" + qvalues.join(", ") + ")", values);
  };

  self.update_where = function(table_name, attributes, where) {
    if (!attributes || attributes.length == 0) {
      console.log('attributes blank');
      return false;
    }

    var table = DB_CONFIG.tables[table_name];

    if (!table) {
      console.log('there are no such table: ' + table_name);
      return false;
    }

    var columns = [];
    var values = [];
    var where_columns = [];
    var where_values = [];


    angular.forEach(table.columns, function(column) {
      if (attributes[column.name] != undefined) {
        columns.push(column.name + ' = ?');
        values.push(attributes[column.name]);
      }
      
      if (where && where[column.name] != undefined) {
        where_columns.push(column.name + ' = ?');
        where_values.push(where[column.name]);
      }
    });

    if (columns.length == 0) {
      console.log('there are no such columns');
      return false;
    }


    return self.query("UPDATE " + table_name + " SET " + columns.join(', ') + (where_columns.length > 0 ? 'WHERE '+where_columns.join(', ') : ''), $.merge(values,where_values));
  };
  
  self.where_part = function(table_name, where) {
    var table = DB_CONFIG.tables[table_name];
    
     if (!table) {
      console.log('there are no such table: ' + table_name);
      return false;
    }
    
    var where_columns = [];
    var where_values = [];

    angular.forEach(table.columns, function(column) {
      if (where && where[column.name] != undefined) {
        where_columns.push(column.name + ' = ?');
        where_values.push(where[column.name]);
      }
    });

    return {columns: (where_columns.length > 0 ? 'WHERE '+where_columns.join(', ') : ''), values: where_values}; 
  };

  self.update = function(table_name, id, attributes) {
    return self.update_where(table_name, attributes, {id: id});
  };

  self.query = function(query, bindings) {
    if (!self.db)
      return;

    bindings = typeof bindings !== 'undefined' ? bindings : [];
    var deferred = $q.defer();

    if (self.db_type == 'SQLite') {
      // production version
      // console.log('self.db', self.db);
      $cordovaSQLite.execute(self.db, query, bindings).then(function(result) {
        deferred.resolve(result);
      }, function(error) {
        console.log('Query error:', error);
        deferred.reject(error);
      });
    } else {
      // web testing
      self.db.transaction(function(transaction) {
        transaction.executeSql(query, bindings, function(transaction, result) {
          deferred.resolve(result);
        }, function(transaction, error) {
          console.log(error);
          deferred.reject(error);
        });
      });
    }

    return deferred.promise;
  };

  self.fetchAll = function(result) {
    var output = [];

    for (var i = 0; i < result.rows.length; i++) {
      output.push(result.rows.item(i));
    }

    return output;
  };

  self.fetch = function(result) {
    if (result.rows.length == 0)
      return;
    return result.rows.item(0);
  };

  return self;
});
