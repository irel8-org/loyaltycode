angular.module('loylMeApp.data.role', ['loylMeApp.dbConfig'])

.factory('Role', function($http, $q, DB) {
  var self = this;

  self.availableList = function(params) {
    var deferred = $q.defer();

    var merchants = [];

    url = $CONFIG.moe.url('roles', params);

    $http({
      method : 'GET',
      url : url,
      params : authSignedParams(params)
     // timeout : 5000
    }).success(function(data) {
      console.log(url + ': success');
  
      deferred.resolve(data);

    }).error(function() {
      console.log(url + ': error');
      deferred.reject();
    });

    return deferred.promise;
  };
  
  return self;
});
