angular.module('loylMeApp.data.employee', ['loylMeApp.dbConfig']).factory('Employee', function($http, $q, DB) {
  var self = this;

  self.prepare = function(employee) {
    console.log('prepare', employee);

    if (!employee)
      return;

    employee.name = [];

    if (employee.first_name && employee.first_name.length > 0)
      employee.name.push(employee.first_name);

    if (employee.last_name && employee.last_name.length > 0)
      employee.name.push(employee.last_name);

    if (employee.name.length == 0)
      employee.name.push(employee.email);
      
    employee.name = employee.name.join(' ');

    if (employee.photo && employee.photo.photo && employee.photo.photo.view)
      employee.photo_url = employee.photo.photo.view.url;

    if (employee.merchant_roles && employee.merchant_roles.length > 0) {
      employee.roles = [];

      angular.forEach(employee.merchant_roles, function(data, key) {
        employee.roles.push(data.merchant + ' - ' + data.role);
      });

      employee.roles = employee.roles.join(', ');
    }
    
    return employee;

  };

  self.sync = function(params, employee_id) {
    var deferred = $q.defer();

    var employees = [];

    url = employee_id ? $CONFIG.moe.url('employee', {
      '_EMPLOYEE_ID_' : employee_id
    }) : $CONFIG.moe.url('employees', params);

    $http({
      method : 'GET',
      url : url,
      params : authSignedParams(params)
      //    timeout : 5000
    }).success(function(data) {
      if (data.success) {
        console.log('Employee.sync: ' + url + ': success');
 
        deferred.resolve( employee_id ? data.employee : data.employees);
        
        self.sync_employees( employee_id ? data.employee : data.employees);
      } else {
        console.log('Employee.sync: ' + url + ': error: ', data);
        deferred.reject(data);
      }
    }).error(function() {
      console.log(url + ': error');
      deferred.reject(data);
    });

    return deferred.promise;
  };

  self.sync_employees = function(employees) {

    if (employees['id'])
      employees = [employees];

    angular.forEach(employees, function(data, key) {

      data = self.prepare(data);
      if (data) {
        employees[key] = data;

        self.find(data.id).then(function(employee) {
          if (employee) {
            DB.update('employees', data.id, data);
          } else {
            DB.insert('employees', data);
          }
        });
      }

    });
  };

  self.all = function(limit, page, query) {

    if (limit) {

      offset = page ? limit * (page - 1) : 0;

      limit = ' LIMIT ' + offset + ', ' + limit;
    }

    if (query && query.length > 0) {
      query = ' WHERE first_name LIKE "%' + query + '%" OR last_name LIKE "%' + query + '%"';
    } else {
      query = '';
    }
    console.log('SELECT * FROM employees ' + query + limit);
    return DB.query('SELECT * FROM employees ' + query + limit).then(function(result) {
      employees = DB.fetchAll(result);

      angular.forEach(employees, function(employee, key) {

        if (employee) {
          employee = self.prepare(employee);
          employees[key] = employee;

        }
      });

      return employees;
    });
  };

  self.find = function(id, update) {
    if (update) {
      return self.sync({}, id).then(function(data) {
        return self.prepare(data);

      });
    } else {
      return DB.query('SELECT * FROM employees WHERE id = ?', [id]).then(function(result) {
        return self.prepare(DB.fetch(result));
      });
    }
  };

  self.last = function(where) {
    var where_part = DB.where_part('employees', where);

    return DB.query('SELECT * FROM employees ' + where_part.columns + ' ORDER BY updated_at LIMIT 1', where_part.values).then(function(result) {
      return self.prepare(DB.fetch(result));
    });

  };

  self.update = function(id, data) {
    return DB.update('employees', id, data).then(function(result) {
      return result;
    });
  };

  self.update_all = function(data) {
    return DB.update_where('employees', data).then(function(result) {
      return result;
    });
  };

  return self;
});
