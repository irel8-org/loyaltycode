angular.module('loylMeApp.data.locale', ['loylMeApp.dbConfig']).factory('LocaleData', function($http, $q, LocaleStorage) {
  var data = {};

  var service = {};

  service.async = function() {

    var deferred = $q.defer();

    if ($CONFIG.locale.base) {
      locale = $CONFIG.locale.base;
    } else if ($CONFIG.locale.current && $CONFIG.locale.current != 'null') {
      locale = $CONFIG.locale.current;
    }
    ;

    var json = 'json/locales/' + locale + '.json';

    $http({
      method : 'GET',
      url : json
   //   timeout : 5000
    }).success(function(data) {
      //    console.log('locales success', data);
      LocaleStorage.save(data);
      deferred.resolve();
    }).error(function() {
      console.log('locales error');
      data = LocaleStorage.all();
      deferred.reject();
    });

    return deferred.promise;

  };

  service.getAll = function() {
    return LocaleStorage.all();
  };

  service.getValue = function(hash, keys) {
    var key = keys.shift();

    if (keys.length == 0)
      return hash[key];

    return this.getValue(hash[key], keys);
  };

  service.get = function(key, params) {    
    if (!data || Object.keys(data).length == 0) {
      data = LocaleStorage.all();
    }

    var res = this.getValue(data, key.split('.'));

    if (!res)
      return res;

    if (params) {
      for (i in params) {
        re = new RegExp("%\{" + i + "\}", "g");

        res = res.replace(re, params[i]);

      }
    }

    return res;
  };

  return service;

}); 