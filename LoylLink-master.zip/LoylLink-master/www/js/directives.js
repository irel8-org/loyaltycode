'use strict';

var loyl_link_directives = angular.module('loylMeApp.directives', []);


loyl_link_directives.directive("slider", function () {
	return function (scope, element, attrs) {
	scope.$watch("rewards", function () {
	    console.log("jq plugging the table (it's always empty!)...");
	    setSlider();
	});
};
});

loyl_link_directives.directive('customerMenu', function() {
	return {
		restrict : 'E',
		templateUrl : 'templates/_customer_menu.html',
		scope: {
	      customerHomeClass: '@',
	      customerCheckoutClass: '@',
	      editCustomerClass: '@',
	      customer: '=',
	      locale: '='
	   },
	  link: function(scope) {
	    	scope.redirectTo = function(url){
	    	//alert(scope.customer.id);
	    		redirectTo(url);//.replace('{customer.id}', scope.customer.id));
	    	};

	    	scope.$watch('customer', function(oldVal, newVal) {
	    		console.log(oldVal, newVal);
	    	});

	  }
	 };
});

loyl_link_directives.directive('customerEditMenu', function() {
  return {
    restrict : 'E',
    templateUrl : 'templates/_customer_edit_menu.html',
    scope: {
				backToCustomerClass: '@',
				profileClass: '@',
				paymentClass: '@',
        settingsClass: '@',
        customer: '=',
        locale: '='
     },
    link: function(scope) {
        scope.redirectTo = function(url){
          redirectTo(url);
        };

        scope.$watch('customer', function(oldVal, newVal) {
          console.log(oldVal, newVal);
        });

    }
   };
});

loyl_link_directives.directive('employeesMenu', function() {
  return {
    restrict : 'E',
    templateUrl : 'templates/_employees_menu.html',
    scope: {
        searchClass: '@',
        addEmployeeClass: '@',
        stampCheckClass: '@',
        locale: '='
     },
    link: function(scope) {
        scope.redirectTo = function(url){
          redirectTo(url);
        };

    }
   };
});

loyl_link_directives.directive('employeeMenu', function() {
  return {
    restrict : 'E',
    templateUrl : 'templates/_employee_menu.html',
    scope: {
				employeeHomeClass: '@',
				stampClass: '@',
				editClass: '@',
        locale: '=',
        employee: '='
     },
    link: function(scope) {
        scope.redirectTo = function(url){
          redirectTo(url);
        };

    }
   };
});

loyl_link_directives.directive('employeeForm', function() {
  return {
    restrict : 'E',
    templateUrl : 'templates/_employee_form.html',
    scope: true,
    link: function($scope, elem, attrs) {
        $scope.redirectTo = function(url){
          redirectTo(url);
        };

          elem.ready(function(){
            $scope.formsSetEvents();


          });
    }
   };
});

loyl_link_directives.directive('starRating', function() {
	return {
		restrict : 'E',
		templateUrl : 'templates/_star_rating.html',
		link : function(scope) {
			// scope.click = function(starRating) {
				// scope.starRating = starRating;
				// scope.ratingChanged({
					// newRating : starRating
				// });
			// };
			scope.$watch('rating', function(newVal, oldVal) {

				if (newVal) {
					scope.stars = [];
					var rating = scope.rating;
					for (var i = 0; i < scope.maxRating; i++) {
						scope.stars.push({
							empty : i >= rating,
							index : i + 1
						});
					}

				}
			});
		},
		scope : {
			rating : "=",
			maxRating : "=",
			ratingChanged : "&"
		}
	};
});
