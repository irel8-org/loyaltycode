angular.module('loylMeApp.dbConfig', [])
.constant('DB_CONFIG', {
    tables: {
      customers: {
            columns: [
                {name: 'inner_id', type: 'integer primary key'},
                {name: 'id', type: 'integer'},
                {name: 'first_name', type: 'VARCHAR(255)'},
                {name: 'last_name', type: 'VARCHAR(255)'},
                {name: 'name', type: 'VARCHAR(255)'},
                {name: 'email', type: 'VARCHAR(255)'},
                {name: 'enabled_loyalty', type: 'VARCHAR(255)'},
                {name: 'loyalty_value', type: 'FLOAT'},
                {name: 'starRating', type: 'INTEGER'},
                {name: 'points_balance', type: 'FLOAT'},
                {name: 'count_rewards', type: 'INTEGER'},
                {name: 'avg_ticket_size', type: 'FLOAT'},
                {name: 'purchases_amount', type: 'INTEGER'},
                {name: 'formatted_card_number', type: 'VARCHAR(255)'},
                {name: 'recency', type: 'INTEGER'},
                {name: 'merchant_id', type: 'INTEGER'},
                {name: 'photo_url', type: 'TEXT'},
                {name: 'card_number', type: 'VARCHAR(255)'}
                                
            ]
      },
      employees: {
            columns: [
                {name: 'inner_id', type: 'integer primary key'},
                {name: 'id', type: 'integer'},
                {name: 'first_name', type: 'VARCHAR(255)'},
                {name: 'last_name', type: 'VARCHAR(255)'},
               
                {name: 'email', type: 'VARCHAR(255)'},    
                {name: 'mobile_phone', type: 'VARCHAR(255)'},    
                {name: 'photo_url', type: 'TEXT'},
                {name: 'count_stamps', type: 'INTEGER'},
                {name: 'value_thru_stamps', type: 'FLOAT'},          
                {name: 'locale', type: 'VARCHAR(255)'},
                {name: 'roles', type: 'TEXT'},
                
                {name: 'login', type: 'VARCHAR(255)'},
                {name: 'unconfirmed_email', type: 'VARCHAR(255)'},
                {name: 'updated_at', type: 'DATETIME DEFAULT CURRENT_TIMESTAMP'},
                {name: 'auth_token', type: 'VARCHAR(255)'},
                                
            ]
        }
    }
});



