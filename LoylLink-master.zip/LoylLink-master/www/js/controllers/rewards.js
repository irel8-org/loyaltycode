var cinst = angular.module('loylMeApp.controllers.rewards', []);

cinst.controller('RewardsCtrl', function($scope, $stateParams, Customer, $ionicSlideBoxDelegate) {
  console.log('RewardsCtrl');
  if (!$stateParams.customer_id)
    redirectTo('#/app/customers');

  $scope.authShouldBeAuthorized();

  console.log('rewardPrepareSlider');

  Customer.find($stateParams.customer_id, true, {
    with_balance : 'yes',
    with_user_data_for_merchant : 'yes',
    with_punchcards : 'yes'
  }, true).then(function(customer) {
    $scope.customer = customer;

    if (!$scope.customer || !$scope.customer.success) {
      redirectTo('#/app/customers/' + $stateParams.customer_id);
      return;
    }
    console.log('customer', $scope.customer);
    var loyl_me_rewards = [];
    var moe_coupons = [];
    var ss_rewards = [];
    var ss_campaigns = [];
    var moe_daily_deal_coupons = [];
    var punchcards = $scope.customer.punchcards;

    $scope.rewards = [];

    if (punchcards && punchcards.length > 0) {
      for (i in punchcards) {
        var object = {
          title : punchcards[i].title,
          description : $LOCALE.get('items_from', {
            items : punchcards[i].already_visited,
            items_should_be : punchcards[i].should_count_visits
          }),
          reward_id : punchcards[i].id,
          reward_type : 'punchcard',
          reward_prize : punchcards[i].reward_prize,
          campaign_id : punchcards[i].loyalty_campaign_id,

          items_should_be : punchcards[i].should_count_visits
        };

        $scope.rewards.push(object);
      }
    }

    if ($scope.customer.consumer_balance) {
      moe_coupons = $scope.customer.consumer_balance.moegenius.coupons;

      if (moe_coupons.length > 0) {
        for (i in moe_coupons) {
          var object = {
            title : moe_coupons[i].discount_name, //+'-'+moe_coupons[i].code,
            description : '', //moe_coupons[i].discount_message,
            reward_id : moe_coupons[i].id,
            expiration_date : moe_coupons[i].expiration_date ? $LOCALE.get('expiration_date', {
              date : moe_coupons[i].expiration_date
            }) : '',
            reward_type : 'coupon'
          };

          $scope.rewards.push(object);
        }
      }

      if ($scope.customer.consumer_balance.enabled_loyalty == 'loyl_me') {
        loyl_me_rewards = $scope.customer.consumer_balance.loyl_me.loyalty_campaigns.rewards;

        if (loyl_me_rewards.length > 0) {
          for (var i in loyl_me_rewards) {

            var slide = 0;
            var count = loyl_me_rewards[i].earned;
            var title = loyl_me_rewards[i].title + (count > 1 ? " (x" + count + ")" : '');
            // while(slide < count){
            // slide += 1;

            var object = {
              title : title,
              description : '',
              reward_id : loyl_me_rewards[i].id,
              reward_type : loyl_me_rewards[i].type,
              campaign_id : loyl_me_rewards[i].loyalty_campaign_id,
              expiration_date : loyl_me_rewards[i].expiration_date ? $LOCALE.get('expiration_date', {
                date : loyl_me_rewards[i].expiration_date
              }) : ''

            };

            $scope.rewards.push(object);
            // }
          }
        }
      }

      moe_daily_deal_coupons = $scope.customer.consumer_balance.moegenius.daily_deal_coupons;

      if (moe_daily_deal_coupons.length > 0) {
        for (i in moe_daily_deal_coupons) {
          var object = {
            title : $LOCALE.get('livingsocial_deal') + ' ' + moe_daily_deal_coupons[i]["groupon_deal.title"],
            description : $LOCALE.get('voucher_code') + ' ' + moe_daily_deal_coupons[i].code,
            reward_id : moe_daily_deal_coupons[i].id,
            reward_type : 'daily_deal_coupon'
          };

          $scope.rewards.push(object);
        }
      }

      if ($scope.customer.consumer_balance.enabled_loyalty == 'SS') {
        ss_campaigns = $scope.customer.consumer_balance.sticky_street.campaigns;

        if (ss_campaigns && ss_campaigns.length > 0) {
          for (i in ss_campaigns) {
            var ss_campaign = ss_campaigns[i];
            var key, key_item, key_item_id;

            if (ss_campaign.type == 'points') {
              key_item_id = 'id';
              key_title = 'description';
              balance = ss_campaign['balance'];
              needed_to_redeem_key = 'needed_to_redeem';
            } else {//buyx
              key_title = 'name';
              key_item_id = 'item_id';
              needed_to_redeem_key = 'earn_ratio';
            }

            if (ss_campaign['rewards'].length > 0) {

              ss_rewards = ss_rewards.concat(ss_campaign['rewards']);

              for (y in ss_campaign['rewards']) {
                var reward = ss_campaign['rewards'][y];

                if (ss_campaign.type == 'points' || reward.earned > 0) {

                  var object = {
                    title : reward[key_title],
                    description : '',
                    reward_id : reward[key_item_id],
                    reward_type : ss_campaign.type,
                    campaign_id : ss_campaign.id
                  };

                  $scope.rewards.push(object);
                }
              }
            }
          }
        }
      }
    }
 
    if($scope.rewards.length == 0){
      redirectTo('#/app/enter_amount/'+$scope.customer.id);
    }
  });

  $scope.redeemReward = function() {
    var index = $ionicSlideBoxDelegate.currentIndex();

    var slide = $('.slider ion-slide').eq(index).find('.cont');

    var reward_name = slide.find('.reward-title').html();

    var params = [];

    url = $CONFIG.local.reward_enter_amount_path + '/' + $stateParams.customer_id;

    if (slide.data('type') == 'punchcard') {
      url = $CONFIG.local.reward_enter_items_path + '/' + $stateParams.customer_id;

      params.push('reward_prize=' + encodeURIComponent(slide.data('reward-prize')));
      params.push('items_should_be=' + encodeURIComponent(slide.data('items-should-be')));
    }

    params.push('reward_id=' + slide.data('id'));
    params.push('reward_type=' + slide.data('type'));
    params.push('reward_name=' + encodeURIComponent(reward_name));
    params.push('campaign_id=' + slide.data('campaign'));
    params.push('customer_id=' + $stateParams.customer_id);
    console.log(url, params);
    redirectTo(url + '?' + params.join('&'));

  };
});

cinst.controller('RewardEnterAmountBaseCtrl', function($scope, $stateParams, Customer) {
  if (!$stateParams.customer_id)
    redirectTo('#/app/customers');

  $scope.authShouldBeAuthorized();

  Customer.find($stateParams.customer_id).then(function(customer) {
    $scope.customer = customer;
  });

  $scope.rewardAddCode = function(key) {
    var code = $('#enterAmount');
    //if (code.val().length < 10) {
    code.html(code.html() + key);
    //}
  };

  $scope.rewardEmptyCode = function() {
    var code = $('#enterAmount');

    code.html('');
  };

  $scope.rewardBackSpace = function() {
    var code = $('#enterAmount');

    if (code.html().length > 0) {
      code.html(code.html().slice(0, -1));
    }
  };

  // $scope.rewardEnterRewardAmount = function() {
  // if ($('#enterAmount').html().length == 0) {
  // return false;
  // }
  //
  // merchant_id = $.urlParam('merchant_id') || $.urlParam('id');
  //
  // var params = [];
  //
  // params.push('reward_id=' + $.urlParam('reward_id'));
  // params.push('amount=' + $('#enterAmount').html());
  // params.push('items=' + $.urlParam('items'));
  // params.push('reward_prize=' + $.urlParam('reward_prize'));
  // params.push('reward_type=' + $.urlParam('reward_type'));
  // params.push('reward_name=' + encodeURIComponent($.urlParam('reward_name')));
  // params.push('campaign_id=' + $.urlParam('campaign_id'));
  // params.push('merchant_id=' + merchant_id);
  //
  // redirectTo($CONFIG.local.reward_enter_amount_stamp_path + '?' + params.join('&'));
  //
  // };

  // $scope.rewardEnterItems = function() {
  // if ($('#enterAmount').html().length == 0) {
  // return false;
  // }
  //
  // merchant_id = $.urlParam('merchant_id') || $.urlParam('id');
  //
  // var params = [];
  //
  // params.push('reward_id=' + $.urlParam('reward_id'));
  // params.push('items=' + $('#enterAmount').html());
  // params.push('reward_prize=' + $.urlParam('reward_prize'));
  // params.push('items_should_be=' + $.urlParam('items_should_be'));
  // params.push('reward_type=' + $.urlParam('reward_type'));
  // params.push('reward_name=' + encodeURIComponent($.urlParam('reward_name')));
  // params.push('campaign_id=' + $.urlParam('campaign_id'));
  // params.push('merchant_id=' + merchant_id);
  //
  // redirectTo($CONFIG.local.reward_enter_amount_path + '?' + params.join('&'));
  // };

  $('div[data-value]').bind('click', function() {
    $scope.rewardAddCode($(this).data('value'));
  });

  $('#deleteButton').bind('click', function() {
    $scope.rewardEmptyCode();
  });

});

cinst.controller('RewardEnterItemsCtrl', function($scope, $stateParams, $controller, Customer) {
  $controller('RewardEnterAmountBaseCtrl', {
    $scope : $scope
  });

  $scope.reward_name = $.urlParam('reward_name');

  $scope.rewardEnterVisitAmount = function() {
    if ($('#enterAmount').html().length == 0) {
      return false;
    };

    var params = [];

    params.push('reward_id=' + $.urlParam('reward_id'));
    params.push('amount=' + $('#enterAmount').val());
    params.push('items=' + $.urlParam('items'));
    params.push('reward_prize=' + $.urlParam('reward_prize'));
    params.push('reward_type=' + $.urlParam('reward_type'));
    params.push('reward_name=' + encodeURIComponent($.urlParam('reward_name')));
    params.push('campaign_id=' + $.urlParam('campaign_id'));
    //params.push('merchant_id=' + merchant_id);

    redirectTo("#/app/confirm_transaction/" + $stateParams.customer_id + '/' + $('#enterAmount').html() + '?' + params.join('&'));
  };

});

cinst.controller('RewardEnterAmountCtrl', function($scope, $stateParams, $controller, Customer) {
  $controller('RewardEnterAmountBaseCtrl', {
    $scope : $scope
  });

  $scope.rewardEnterVisitAmount = function() {
    if ($('#enterAmount').html().length == 0) {
      return false;
    };

    redirectTo("#/app/confirm_transaction/" + $stateParams.customer_id + '/' + $('#enterAmount').html());
  };

});
