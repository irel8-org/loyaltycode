angular.module('loylMeApp.controllers.camera', [])

.controller('CameraCtrl', function($scope, $cordovaFileTransfer, $ionicLoading) {

  $scope.cameraRemovePreloader = function() {
    $ionicLoading.hide();
  };

  $scope.cameraShowPreloader = function() {
    $ionicLoading.show({template: 'Loading...'});
  };

  $scope.cameraOnDeviceReady = function(param_name, server_url) {
    console.log('cameraOnDeviceReady');
    console.log(navigator.camera);
    
    $scope.camera_param_name = param_name;
    $scope.camera_server_url = server_url;

    if (!navigator.camera) {
      setTimeout($scope.cameraOnDeviceReady, 1000);
      return;
    };

    $CONFIG.local.picture_source = navigator.camera.PictureSourceType;
    $CONFIG.local.destination_type = navigator.camera.DestinationType;

    if ( typeof (LocalFileSystem) != 'undefined') {
      window.requestFileSystem(LocalFileSystem.PERSISTENT, 1024 * 1024, $scope.cameraGotFileSystem, $scope.cameraFsFail1);
    };

  };

  $scope.cameraCapturePhoto = function() {

    navigator.camera.getPicture($scope.cameraPhotoSave, $scope.cameraOnFail, {
      quality : 50,
      targetWidth : 1000,
      targetHeight : 1000,
      destinationType : $CONFIG.local.destination_type.FILE_URI
    });
  };

  $scope.cameraGotFileSystem = function(fileSystem) {
    $CONFIG.local.file_system = fileSystem;
  };
  ;

  $scope.camerGotFileEntry = function(fileEntry) {
  
    fileEntry.copyTo($CONFIG.local.file_system.root, null, $scope.cameraCopiedFile, $scope.cameraFsFail2);

    $scope.cameraUploadPhotoToServer(fileEntry.toURL());
  };

  $scope.cameraPhotoSave = function(imageURI) {
   
    $scope.cameraShowPreloader();

    var rLocalFileSystemURL;

    //(image is currently stored in dir off of persistent file system but that may change)
    if (window.resolveLocalFileSystemURL == undefined) {
      rLocalFileSystemURL = window.resolveLocalFileSystemURI;
    } else {
      rLocalFileSystemURL = window.resolveLocalFileSystemURL;
    };

    rLocalFileSystemURL(imageURI, $scope.camerGotFileEntry, $scope.cameraFsFail3);

    // upload to server

  };

  $scope.cameraCopiedFile = function(fileEntry) {
    $('#avatar').attr('src', fileEntry.toURL() + "?v=" + (new Date()).getTime());
  };

  $scope.cameraFsFail1 = function(error) {
    console.log("cameraFsFail1");
    $scope.cameraFsFail(error);
  };
  $scope.cameraFsFail2 = function(error) {
    console.log("cameraFsFail2");
    $scope.cameraFsFail(error);
  };
  $scope.cameraFsFail3 = function(error) {
    console.log("cameraFsFail3");
    $scope.cameraFsFail(error);
  };

  // file system fail
  $scope.cameraFsFail = function(error) {
    console.log("failed with error code: " + error.code);
    console.log(error);
  };

  // Called if something bad happens.
  //
  $scope.cameraOnFail = function(message) {
    console.log('Failed because: ' + message);
  };

$scope.cameraUploadPhotoToServer = function(imageURI) {

    console.log('cameraUploadPhotoToServer');

    var options = {};

    options.fileKey = $scope.camera_param_name;

    options.fileName = imageURI.substr(imageURI.lastIndexOf('/') + 1);

    options.mimeType = "image/jpeg";

    options.params = $scope.authSignedParams({});

    $cordovaFileTransfer.upload($scope.camera_server_url, imageURI, options)
      .then($scope.cameraPhotoUploaded, $scope.cameraPhotoNotUploaded, function (progress) {
        // constant progress updates
      });
  };
  
  $scope.cameraPhotoUploaded = function(r) {
    //console.log('cameraPhotoUploaded');
 
    $scope.cameraRemovePreloader();
  };

  $scope.cameraPhotoNotUploaded = function(error) {
    console.log('cameraPhotoNotUploaded');

    $scope.cameraRemovePreloader();
  };

});

