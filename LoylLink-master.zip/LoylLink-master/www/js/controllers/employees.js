var capp = angular.module('loylMeApp.controllers.employees', []);

capp.controller('ManageEmployeesCtrl', function($scope, Employee) {

});

capp.controller('EmployeesCtrl', function($scope, $ionicPlatform, Employee, DB) {
  $scope.authShouldBeAuthorized();

  $scope.employees = [];
  $scope.count_on_page = 20;
  $scope.current_page = 1;
  $scope.current_query = '';
  $scope.more_data_exist = true;

  $scope.loadMoreEmployees = function(employees) {
    if (employees.length > 0) {
      angular.forEach(employees, function(employee, key) {
        $scope.employees.push(employee);
      });

      $scope.$broadcast('scroll.infiniteScrollComplete');
      $scope.current_page += 1;
    }

    $scope.more_data_exist = employees.length >= $scope.count_on_page;
  };

  $scope.loadMore = function(query, clean) {
    $ionicPlatform.ready(function() {
      DB.init();

      if (!query)
        query = $('#search-query').val();

      // if user type new query - cleaning a list of employees
      if ($scope.current_query != query || clean) {
        $scope.employees = [];
        $scope.more_data_exist = true;
        $scope.current_page = 1;
        $scope.current_query = query;
      }

      console.log('loadMore', $scope.current_page, $scope.count_on_page);

      Employee.sync({
        count : $scope.count_on_page,
        page : $scope.current_page,
        query : query
      }).then(function(employees) {
        console.log('then');
        $scope.loadMoreEmployees(employees);

      }, function(data) {
        console.log('Employee.all');
        Employee.all($scope.count_on_page, $scope.current_page, query).then(function(employees) {
          $scope.loadMoreEmployees(employees);
        });
        $scope.lostConnection();
        $scope.loadMoreEnabled = false;
      });
    });
  };

  $scope.$on('$stateChangeSuccess', function() {
    $scope.loadMore();
  });
});

capp.controller('EmployeeFormCtrl', function($scope, Merchant, Role) {
  $scope.authShouldBeAuthorized();

  $scope.merchants = [];
  $scope.employee = {};
  $scope.exist_merchants_available_for_user = [{user_merchant_id: 0}];
  $scope.selected_merchant = {};
  $scope.selected_role = {};

  Merchant.availableList().then(function(merchants) {
    if (merchants.length == 0) {
      alert($LOCALE.get('new_employee.no_merchants'));
      redirectTo('#/app/employees');
    }
    $scope.merchants = merchants;
    $scope.selected_merchant[0] = $scope.merchants[0];
    //for editing set current merchant, but there can be more than one..
    if ($scope.merchants.length > 1) {
      $('.merchant-selector').show();
    }
    if ($scope.selected_merchant[0])
      $scope.setRoles(0, false, false, $scope.selected_merchant[0].id);
  });

  $scope.roles = [];

  $scope.setRoles = function(muid, role_id, role_name, merchant_id) {
    if(!merchant_id) merchant_id = $scope.selected_merchant[muid].id;
    console.log(merchant_id);
    Role.availableList({
      "_MERCHANT_ID_" : merchant_id
    }).then(function(roles) {
      $scope.roles = roles;
      $scope.selected_role[0] = $scope.roles[0];
      //for editing set current role, but there can be more than one..
      if ($scope.roles.length > 1) {
        $('.role-selector').show();
      } else {
        $('.role-selector').hide();
      }
    });
  };

  $scope.employee = {
    send_invite_for_app : true
  };

});

capp.controller('AddEmployeeCtrl', function($scope, $controller, $sce, Merchant, Role) {
  $controller('EmployeeFormCtrl', {
    $scope : $scope
  });

  $scope.form_callback = 'employeeCreated';
  $scope.form_error_callback = 'employeeNotCreated';

  $scope.form_action = function() {
    return $sce.trustAsResourceUrl($CONFIG.moe.url('employees'));
  };

  $scope.$on('employeeCreated', function(e, result) {
    var button = $('#employeeSubmitButton');

    if (!result.errors || result.errors.length <= 0) {
      alert($LOCALE.get('new_employee.added'));
      redirectTo('#/app/employees');
    } else {
      if (button.siblings('.base-error-message').length == 0) {
        button.before('<span class="base-error-message"></span>');
      }

      button.siblings('.base-error-message').html(result.errors).show();
    }
  });

  $scope.$on('employeeNotCreated', function(e, result) {
    alert('employeeNotCreated');
  });
});

capp.controller('StampCheckCtrl', function($scope, Employee) {
  $scope.authShouldBeAuthorized();

  var stampScreenInitData = {
    "postUrl" : $CONFIG.moe.url('snowshoe_check_stamp'),
    "stampScreenElmId" : "stamp-screen",
    "progressBarOn" : true,
    "additionalParams" : $scope.authSignedParams({}),
    "messages" : {
      "insufficientPoints" : "<h3>" + $LOCALE.get('stamp_check.not_found') + "</h3>"
    },
    "postViaAjax" : true,
    "success" : function(response) {
      if (response.status == 400) {
        alert($LOCALE.get('stamp_check.not_found'));
      } else if (response.merchant_snow_shoe_stamp) {
        redirectTo('#/app/employees/' + response.merchant_snow_shoe_stamp.user_id + '/stamp/' + response.merchant_snow_shoe_stamp.id);
      } else {
        redirectTo('#/app/unassigned_stamp');
      }
      console.log(response);
      console.log("Success!", response);
    },
    "error" : function(response) {
      // handle failure
      console.log("error stamp");
      alert($LOCALE.get('stamp_check.not_found'));
    }
  };

  $.snowshoe.stampScreen.init(stampScreenInitData, $.snowshoe.client);

});

capp.controller('EmployeeCtrl', function($scope, $stateParams, Employee) {
  if (!$stateParams.id)
    redirectTo('#/app/employees');

  $scope.authShouldBeAuthorized();

  Employee.find($stateParams.id, true).then(function(employee) {

    $scope.employee = employee;

  }, function() {
    redirectTo('#/app/employees');
  });
});

capp.controller('EmployeeRemoveStampCtrl', function($scope, $stateParams, $http, Employee) {
  if (!$stateParams.id)
    redirectTo('#/app/employees', {}, 'Wrong Employee ID');

  if (!$stateParams.stamp_id)
    redirectTo('#/app/employees/' + $stateParams.id, {}, 'Wrong Stamp ID');

  $scope.authShouldBeAuthorized();

  Employee.find($stateParams.id, true).then(function(employee) {

    $scope.employee = employee;

    angular.forEach(employee.merchant_snow_shoe_stamps, function(stamp, key) {
      if (stamp.id == $stateParams.stamp_id)
        $scope.stamp = stamp;
    });

    if (!$scope.stamp)
      redirectTo('#/app/employees/' + $stateParams.id, {}, 'Wrong Stamp');

    $scope.title = $LOCALE.get('employee_stamp_remove.title', {
      name : $scope.employee.name
    });

    $scope.description = $LOCALE.get('employee_stamp_remove.description', {
      name : $scope.employee.name,
      serial : $scope.stamp && $scope.stamp.serial
    });

  }, function() {
    redirectTo('#/app/employees');
  });

  $scope.removeStamp = function(stamp_id) {
    console.log(stamp_id);

    $http({
      method : 'POST',
      url : $CONFIG.moe.url('employee_stamp_remove', {
        '_EMPLOYEE_ID_' : $stateParams.id,
        '_STAMP_ID_' : stamp_id
      }),
      params : $scope.authSignedParams({})
      //timeout : 5000
    }).success(function(data) {
      if (data.success) {
        console.log('Employee.removeStamp: success');
        redirectTo('#/app/employees/' + $stateParams.id);
      } else {
        console.log('Employee.removeStamp: error: ', data);
        alert(data);

      }
    }).error(function() {

    });

  };
});

capp.controller('EmployeeAssignStampCtrl', function($scope, $stateParams, $http, Employee) {
  if (!$stateParams.id)
    redirectTo('#/app/employees', {}, 'Wrong Employee ID');

  $scope.authShouldBeAuthorized();

  Employee.find($stateParams.id, true).then(function(employee) {

    $scope.employee = employee;
    $scope.tap = $LOCALE.get('employee_stamp_assign.tap', {
      name : employee.name
    });

  }, function() {
    redirectTo('#/app/employees');
  });

  var stampScreenInitData = {
    "postUrl" : $CONFIG.moe.url('snowshoe_assign_stamp', {
      _EMPLOYEE_ID_ : $stateParams.id
    }),
    "stampScreenElmId" : "stamp-screen",
    "progressBarOn" : true,
    "additionalParams" : $scope.authSignedParams({}),
    "messages" : {
      "insufficientPoints" : "<h3>" + $LOCALE.get('stamp_check.try_again') + "</h3>"
    },
    "postViaAjax" : true,
    "success" : function(response) {
      if (response.status == 400) {
        alert($LOCALE.get('stamp_check.not_found'));
      } else if (response.success) {
        redirectTo('#/app/employees/' + $stateParams.id + '/stamp/assigned');
      } else {
        employee_id = response.employee ? response.employee.id : 0;
        redirectTo('#/app/employees/' + $stateParams.id + '/stamp/unassigned/' + employee_id);
      }
      console.log(response);
      console.log("Success!", response);
    },
    "error" : function(response) {
      // handle failure
      console.log("error stamp");
      alert($LOCALE.get('stamp_check.not_found'));
    }
  };

  $.snowshoe.stampScreen.init(stampScreenInitData, $.snowshoe.client);

});

capp.controller('EmployeeArchiveCtrl', function($scope, $stateParams, $http, Employee) {
  if (!$stateParams.id)
    redirectTo('#/app/employees');

  $scope.authShouldBeAuthorized();

  Employee.find($stateParams.id, true).then(function(employee) {

    $scope.employee = employee;

    $scope.title = $LOCALE.get('employee_archive.title', {
      name : $scope.employee.name
    });

    $scope.description = $LOCALE.get('employee_archive.description', {
      name : $scope.employee.name
    });

  }, function() {
    redirectTo('#/app/employees');
  });

  $scope.archive = function() {
    if (!window.confirm($LOCALE.get('employee_archive.are_you_sure'))) {
      return;
    }
    $http({
      method : 'POST',
      url : $CONFIG.moe.url('employee_archive', {
        '_EMPLOYEE_ID_' : $stateParams.id
      }),
      params : $scope.authSignedParams({})
      //    timeout : 5000
    }).success(function(data) {
      if (data.success) {
        console.log('Employee.archive: success');
        redirectTo('#/app/employees');
      } else {
        console.log('Employee.archive: error: ', data);
        alert(data);

      }
    }).error(function() {

    });

  };

});

capp.controller('EmployeeEditCtrl', function($scope, $controller, $sce, $stateParams, $filter, Employee, Merchant, Role) {
  // $controller('EmployeeFormCtrl', {
  // $scope : $scope
  // });

  if (!$stateParams.id)
    redirectTo('#/app/employees');

  $scope.form_callback = 'employeeUpdated';
  $scope.form_error_callback = 'employeeNotUpdated';
  $scope.form_action = function() {
    return $sce.trustAsResourceUrl($CONFIG.moe.url('employee', {
      '_EMPLOYEE_ID_' : $stateParams.id
    }));
  };

  $scope.authShouldBeAuthorized();

  Employee.find($stateParams.id, true).then(function(employee) {

    $scope.employee = employee;
    
    $scope.exist_merchants_available_for_user = $scope.employee.exist_merchants_available_for_user;
    
    $scope.old_merchant_ids = [];
    
    for(i in $scope.employee.exist_merchants_available_for_user){
      $scope.old_merchant_ids.push($scope.employee.exist_merchants_available_for_user[i].id);
    }

    Merchant.availableList().then(function(merchants) {
      if (merchants.length == 0) {
        alert($LOCALE.get('new_employee.no_merchants'));
        redirectTo('#/app/employees');
      } else {

        $scope.merchants = merchants;
        $scope.selected_merchant = {};
        $scope.selected_role = {};
        
        for(i in $scope.employee.exist_merchants_available_for_user){
          var m = $scope.employee.exist_merchants_available_for_user[i];
          
          $scope.selected_merchant[m.user_merchant_id] = m;
          $scope.setRoles(m.user_merchant_id, m.role_id, m.role, m.id);
        } 
      
       //for editing set current merchant, but there can be more than one..
        // if ($scope.merchants.length > 1) {
           $('.merchant-selector').show();
        // }
 
      }

    });
    
  });

  $scope.roles = [];

  $scope.setRoles = function(muid, role_id, role_title, merchant_id) {
   if(!merchant_id) merchant_id = $scope.selected_merchant[muid].id;
  //  console.log(muid, role_id, role_title, merchant_id, $scope.selected_merchant[muid]);
    
    Role.availableList({
      "_MERCHANT_ID_" : merchant_id
    }).then(function(roles) {
      $scope.roles = roles;
      $scope.selected_role[muid] = $filter('getById')($scope.roles, role_id);
      if(!$scope.selected_role[muid] && role_title){
        $scope.selected_role[muid] = {id: role_id, title: role_title};
        $scope.roles.push( $scope.selected_role[muid] );
      }
      
      //for editing set current role, but there can be more than one..
      if ($scope.merchants.length > 1) {
        $('.role-selector').show();
      } else {
        $('.role-selector').hide();
      }
    });
  };

  $scope.employee = {
    send_invite_for_app : true
  };

  $scope.$on('employeeUpdated', function(e, result) {
    var button = $('#employeeSubmitButton');

    if (result.errors.length <= 0) {
      alert($LOCALE.get('edit_employee.updated'));
      redirectTo('#/app/employees/' + $scope.employee.id);
    } else {
      if (button.siblings('.base-error-message').length == 0) {
        button.before('<span class="base-error-message"></span>');
      }

      button.siblings('.base-error-message').html(result.errors).show();
    }
  });

  $scope.$on('employeeNotUpdated', function(e, result) {
    alert('employeeNotCreated');
  });

});

capp.controller('EmployeeNotAssignedStampCtrl', function($scope, $stateParams) {

});

capp.controller('EmployeeStampCtrl', function($scope, $stateParams, Employee) {
  if (!$stateParams.id)
    redirectTo('#/app/employees');

  $scope.authShouldBeAuthorized();

  Employee.find($stateParams.id, true).then(function(employee) {

    $scope.employee = employee;

    $scope.its_employees = $LOCALE.get('employee_stamp.its_employees', {
      name : $scope.employee.first_name
    });

    $scope.get_this_stamp = $LOCALE.get('employee_stamp.get_this_stamp', {
      name : $scope.employee.first_name
    });

  }, function() {
    redirectTo('#/app/employees');
  });
});

capp.controller('EmployeeStampAssignedCtrl', function($scope, $stateParams, Employee) {
  if (!$stateParams.id)
    redirectTo('#/app/employees');

  $scope.authShouldBeAuthorized();

  Employee.find($stateParams.id, true).then(function(employee) {

    $scope.employee = employee;

    $scope.its_employees = $LOCALE.get('employee_stamp_assigned.its_employees', {
      name : $scope.employee.first_name
    });

    $scope.get_this_stamp = $LOCALE.get('employee_stamp_assigned.get_this_stamp', {
      name : $scope.employee.first_name
    });

    $scope.back_to_user = $LOCALE.get('employee_stamp_assigned.back_to_user', {
      name : $scope.employee.first_name
    });

  }, function() {
    redirectTo('#/app/employees');
  });
});

capp.controller('EmployeeStampUnassignedCtrl', function($scope, $stateParams, Employee) {
  if (!$stateParams.id)
    redirectTo('#/app/employees');

  $scope.authShouldBeAuthorized();

  Employee.find($stateParams.id).then(function(employee) {

    $scope.employee = employee;

    $scope.back_to_user = $LOCALE.get('employee_stamp_assigned.back_to_user', {
      name : $scope.employee.first_name
    });

  }, function() {
    redirectTo('#/app/employees');
  });

  console.log($stateParams.owner_id);
  if ($stateParams.owner_id && $stateParams.owner_id != 0) {
    console.log('1');
    Employee.find($stateParams.owner_id, true).then(function(employee) {

      $scope.owner = employee;

      $scope.its_employees = $LOCALE.get('employee_stamp_unassigned.its_employees', {
        name : $scope.owner.first_name
      });

      $scope.give_this_stamp = $LOCALE.get('employee_stamp_unassigned.give_this_stamp', {
        name : $scope.owner.first_name
      });

    }, function() {
      redirectTo('#/app/employees');
    });
  } else {
    $scope.its_employees = $LOCALE.get('employee_stamp_unassigned.not_exist');
    $scope.give_this_stamp = $LOCALE.get('employee_stamp_unassigned.wrong_stamp');
    console.log('2', $scope.its_employees, $scope.give_this_stamp);
  }
});
