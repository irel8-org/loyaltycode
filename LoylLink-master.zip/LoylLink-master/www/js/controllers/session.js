angular.module('loylMeApp.controllers.session', []).controller('LoginCtrl', function($scope, $location) {
  $scope.formsSetEvents();
  $scope.authAlreadyLogged();

  var set_default_data = false;

  if ($.urlParam('email') && $.urlParam('email') != 'null') {
    $('input[name=email]').val($.urlParam('email'));
    $scope.addErrorToField($('input[name=email]'), 'wrong credentials');
  } else if (!set_default_data && window.localStorage.getItem("user_email") && window.localStorage.getItem("user_email").length > 0) {
    set_default_data = true;
    $('input[name=email]').val(window.localStorage.getItem("user_email"));
  }

  $scope.$on('authUser', function(e, data) {
    console.log('do authUser');

    if (!data) {
      $scope.error_occurred();
      return;
    }
console.log(data);
    if (data.success == true) {

      $scope.authSetUserData(data);
    } else {
      $scope.authCleanUserData();
      if (data.error_code == 'wrong_credentials') {
        $('.form-item input').each(function() {
          if ($(this).val().length > 0) {
            $scope.addErrorToField($(this), $LOCALE.get('wrong_credentials'));
          }
        });
      } else if (data.error_code == 'missing_attributes') {
        $scope.addErrorToField($('.form-item input'), data.error_message);
      } else {
        $scope.error_occurred();
      }
    }
  });

  $scope.authForgotLinkClick = function() {

    if ($("#checkbox-1").prop('checked')) {

      $('#login-form #form-field-password').val('Password');
      if (!$scope.validForm($('#login-form.smart-form'))) {

        for (i in formErrors) {

          if (i != 'form-field-password')
            $scope.addErrorToField($('#' + i), formErrors[i].join(' and '));
        }

        return false;
      };
    
      redirectTo($CONFIG.local.forgot_password_path, {
        email : $('input[name=email]').val()
      });
   
    } else {
      redirectTo();
    };
    return false;
  };

}).controller('SignUpCtrl', function($scope) {

  $scope.formsSetEvents();

  $scope.authAlreadyLogged();

  $scope.$on('authSingUpUser', function(e, data) {
    if (data.success == true) {
      //$scope.authSetUserData(data);
      alert($LOCALE.get('signup.saved'));
      redirectTo('#/app/login');
    } else {
      $scope.authCleanUserData();

      if (data.error_code == 'wrong_data') {
        for (var i in data.error_message) {
          if (data.error_message.hasOwnProperty(i)) {
            $scope.addErrorToField($('.form-item input[name="user[' + i + ']"]'), data.error_message[i].join(' and '));
          }
        }
      } else {
        $scope.addErrorToField($('.form-item input'), data.error_message);
      }
    }
  });

  $('#regForm').keypress(function(e) {
    if (e.keyCode == 13) {
      $('#submitButton').click();
      return false;
    }
  });

}).controller('LoginForgotPasswordCtrl', function($scope, $http, $location) {
  $scope.formsSetEvents();
  
  $scope.authAlreadyLogged();

  $scope.email = $location.search().email;

  $scope.authSendResetPasswordCode = function(button) {
    $scope.authCleanUserData();

    $("#resend-result").html('').attr('class', '');
    var last_sent = $(button).attr('last-sent');

    var ts = new Date().getTime();

    if (last_sent && (ts - last_sent) / 1000 < 60) {
      $("#resend-result").html($LOCALE.get('you_can_request_a_reset_code_once')).addClass('error');
      return;
    }

    $(button).attr('last-sent', new Date().getTime());
    $(button).val($(button).attr('data-wait'));

    $http({
      method : 'POST',
      url : $CONFIG.moe.url('reset_password_code'),
      params : {
        email : $LOCATION.search().email,
        scope: 'user'
      }
  //    timeout : 5000
    }).success(function(data) {
      window.localStorage.setItem("employee_id", data.employee_id);

      $("#resend-result").html('code successfully resent').show();
      $(button).val($(button).attr('data-value'));
      
    }).error(function(e) {
     
      if (e.status == 400 || e.status == 0) {
        redirectTo('/#app/login', {
          login : $.urlParam('login'),
          mobile_number : $.urlParam('mobile_number'),
          email : $.urlParam('email')
        });
      }
    });

  };
  
  $scope.authSendResetPasswordCode();

}).controller('WelcomeCtrl', function($scope, $ionicPlatform) {
  $scope.authShouldBeAuthorized();

  $scope.user_name = window.localStorage.getItem('user_name');

});
