var capp = angular.module('loylMeApp.controllers.customers', []);

capp.controller('CustomersCtrl', function($scope, $ionicPlatform, Customer, DB) {

  $scope.customers = [];
  $scope.count_on_page = 20;
  $scope.current_page = 1;
  $scope.current_query = '';
  $scope.more_data_exist = true;

  $scope.loadMoreCustomers = function(customers) {
    angular.forEach(customers, function(customer, key) {
      console.log('push customer ' + customer.id);
      $scope.customers.push(customer);
    });

    $scope.more_data_exist = customers.length >= $scope.count_on_page;
    $scope.$broadcast('scroll.infiniteScrollComplete');
    $scope.current_page += 1;
  };

  $scope.loadMore = function(query, clean) {
    $ionicPlatform.ready(function() {
      DB.init();
      if ($scope.loadMoreEnabled) {
        console.log('Sorry, loadMoreEnabled, next time maybe..');
        return;
      }

      $scope.loadMoreEnabled = true;

      if (!query)
        query = $('#search-query').val();

      // if user type new query - cleaning a list of customers
      if ($scope.current_query != query || clean) {
        $scope.customers = [];
        $scope.more_data_exist = true;
        $scope.current_page = 1;
        $scope.current_query = query;
      }

      console.log('loadMore', $scope.current_page, $scope.count_on_page);

      Customer.sync({
        count : $scope.count_on_page,
        page : $scope.current_page,
        query : query
      }).then(function(customers) {
        console.log('after customers synced ');
        $scope.loadMoreCustomers(customers);

        $scope.loadMoreEnabled = false;

      }, function(response) {
        console.log('Customer.all');
       Customer.all($scope.count_on_page, $scope.current_page, query).then(function(customers) {
          $scope.loadMoreCustomers(customers);
        });

        $scope.lostConnection();
        $scope.loadMoreEnabled = false;
      });
    });
  };

  $scope.$on('$stateChangeSuccess', function() {
    $scope.loadMore();
  });

});

capp.controller('CustomerCtrl', function($scope, $stateParams, $ionicPlatform, Customer) {

  if (!$stateParams.id)
    redirectTo('#/app/customers');

  $scope.authShouldBeAuthorized();

  Customer.find($stateParams.id, true).then(function(customer) {

    $scope.customer = customer;
    console.log('$scope.customer:', $scope.customer);

    if (customer && customer.enabled_loyalty == "loyl_me") {
      $scope.loyalty_value = [];

      if (customer.points_balance > 0)
        $scope.loyalty_value.push($LOCALE.get('points', {
          count : customer.points_balance
        }));

      if (customer.loyalty_value > 0)
        $scope.loyalty_value.push($LOCALE.get('loyalty_value_2', {
          count : customer.loyalty_value
        }));

      $scope.loyalty_value = $scope.loyalty_value.join(', ');

    } else {// ss

    }
  }, function(res) {

 //   redirectTo('#/app/customers', {}, $LOCALE.get('lost_connection'));
  });

});

capp.controller('AddCustomerCtrl', function($scope, $cordovaDatePicker) {
  $scope.authShouldBeAuthorized();
  $scope.formsSetEvents();
  $scope.test = 1;

  $scope.customer = {
    send_invite_to_rm : true,
    send_email : true,
    send_sms : false
  };

  $scope.$on('customerCreated', function(e, result) {
    var button = $('#customerSubmitButton');

    if (result.success) {
      alert($LOCALE.get('customer_added'));
      redirectTo('#/app/customers');
    } else {
      if (button.siblings('.base-error-message').length == 0) {
        button.before('<span class="base-error-message"></span>');
      }
      
      button.siblings('.base-error-message').html(result.errors).show();
    }
  });

  $scope.customerNotCreated = function(data) {
    alert('customerNotCreated');
  };

  var options = {
    date : new Date(),
    mode : 'date', // or 'time'
    minDate : new Date(new Date().setYear(new Date().getFullYear() - 100)),
    allowOldDates : true,
    allowFutureDates : false,
    doneButtonLabel : 'DONE',
    doneButtonColor : '#F2F3F4',
    cancelButtonLabel : 'CANCEL',
    cancelButtonColor : '#000000'
  };

  document.addEventListener("deviceready", function() {

  }, false);

});

capp.controller('CustomerEditCtrl', function($scope, $stateParams, Customer, $ionicPlatform) {
  if (!$stateParams.id)
    redirectTo('#/app/customers');

  if (!$scope.authShouldBeAuthorized())
    return;

  document.addEventListener("deviceready", function() {
    $scope.cameraOnDeviceReady("customer[photo]", $CONFIG.moe.url('update_customer', {
      '_CUSTOMER_ID_' : $stateParams.id
    }));
  });

  Customer.find($stateParams.id, true).then(function(customer) {

    $scope.customer = customer;

  });

  $scope.$on('customerUpdated', function(e, data) {
    Customer.sync_customers([data]);

    $field = $('input[type="submit"]');

    if ($('form .success-message').length == 0) {
      $field.before('<span class="success-message"></span>');
    }

    $field.siblings('.success-message').html($LOCALE.get('successfully_updated'));
  });

  $scope.$on('customerNotUpdated', function(e, data) {
    console.log('profileNotUpdated');
    var $field = $('form input[type=submit]:last');
    $field.siblings('.success-message').remove();

    if ($field.siblings('.error-message').length == 0) {
      $field.before('<span class="error-message"></span>');
    }

    $field.siblings('.error-message').html(data.error_message.join(' ' + $LOCALE.get('and') + ' ')).show();
  });

  $scope.formsSetEvents();

});

capp.controller('CustomerEditPaymentCtrl', function($scope, $controller) {
  $controller('CustomerEditCtrl', {
    $scope : $scope
  });
});
capp.controller('CustomerEditSettingsCtrl', function($scope, $controller) {
  $controller('CustomerEditCtrl', {
    $scope : $scope
  });

  $scope.$watch('customer', function(customer, oldVal) {

    if ( typeof (customer) != 'undefined' && (customer.birthday && ( birthday = customer.birthday.match(/(\d{4})-(\d{2})-(\d{2})/) ) && birthday.length == 4)) {

      $('[name="day"]').val(birthday[3]);
      $('[name="month"]').val(birthday[2]);
      $('[name="year"]').val(birthday[1]);
    }
  }, true);

  $scope.$on('customerBeforeUpdated', function(e) {
    $('[name="customer[birthday]"]').val($('[name="year"]').val() + '-' + $('[name="month"]').val() + '-' + $('[name="day"]').val());
  });
  
  $scope.$watch('customer', function(customer, oldVal) {
    if (customer && customer.locale) {
      $('[name*="locale"]').val(customer.locale);
    }
  }, true);

});
// capp.controller('CustomerEditLanguageCtrl', function($scope, $controller) {
  // $controller('CustomerEditCtrl', {
    // $scope : $scope
  // });
// 
  // $scope.$watch('customer', function(customer, oldVal) {
    // if (customer && customer.locale) {
      // $('[name*="locale"]').val(customer.locale);
    // }
  // }, true);
// 
// });

capp.controller("CustomerCardScannerCtrl", function($scope, $cordovaBarcodeScanner, Customer) {
  console.log('CustomerCardScannerCtrl');

  document.addEventListener("deviceready", function() {

    console.log('$cordovaBarcodeScanner');
    console.log($cordovaBarcodeScanner);

    $cordovaBarcodeScanner.scan().then(function(barcodeData) {
      console.log('barcodeData');
      console.log(barcodeData);

      if (barcodeData.cancelled != 1) {
        Customer.find_by_card(barcodeData.text, true).then(function(customer) {
          redirectTo('#/app/customers/' + customer.id);
        }, function() {
          alert($LOCALE.get('customer_scan_code.there_are_no_such_customer'));
          console.log('there_are_no_such_customer');
          document.location.reload();
        });
      } else{
        redirectTo('#/app/customers/');
      }

    }, function(error) {
      alert($LOCALE.get('customer_scan_code.there_are_no_such_customer'));
      redirectTo('#/app/customers/');
    });

  }, false);

});
