angular.module('loylMeApp.controllers.auth', []).controller('AuthCtrl', function($scope, $ionicSideMenuDelegate, Employee) {
  $scope.authIsLogged = function() {
    return !!window.localStorage.getItem("auth_token");
  };

  $scope.authCleanUserData = function() {
    authCleanUserData();
  };

  $scope.authDeviceAttributes = function() {
    return authDeviceAttributes();
  };

  $scope.checkAuthResponse = function(response) {
    if (response && response.status == 401) {
      console.log('status is ', response.status, 'cleaning and redirecting to main page');
      $scope.authCleanUserData();
      $scope.authRedirectNotAuthorized();
      return true;
    }
  };

  $scope.authCleanUserDataAndRedirect = function(not_redirect, additional_params) {
    var employee_id = window.localStorage.getItem("employee_id");

    $scope.authCleanUserData();

    var url = $CONFIG.local.root_path;
    if (additional_params && additional_params.match(/\?/))
      url = url + additional_params;

    if (employee_id) {
      Employee.update_all({
        auth_token : ''
      }).then(function() {
        if (not_redirect === true) {//something
        } else {
          redirectTo(url);
        }
      });

    } else {
      if (not_redirect === true) {//something
      } else {
        redirectTo(url);
      }
    }
  };

  $scope.authSetUserLocalData = function(data) {
    window.localStorage.setItem("auth_token", data.auth_token);
    window.localStorage.setItem("employee_id", data.employee.id);
    // window.localStorage.setItem("user_email", data.employee.email || '');
    // window.localStorage.setItem("user_unconfirmed_email", data.employee.unconfirmed_email || '');
    // window.localStorage.setItem("user_first_name", data.employee.first_name || '');
    // window.localStorage.setItem("user_last_name", data.employee.last_name || '');
    // window.localStorage.setItem("user_name", data.employee.name || '');
    // window.localStorage.setItem("user_locale", data.employee.locale || '');
    // window.localStorage.setItem("user_facebook_id", data.employee.facebook_id || '');
    //
    // if (data.employee.birthday && data.employee.birthday.match(/\d{4}-\d{2}-\d{2}/)) {
    // window.localStorage.setItem("user_birthday", data.employee.birthday);
    // }
    //
    // $scope.authSetUserAvatar(data);
  };

  $scope.authSetUserData = function(data, update_db, not_redirect) {
    if (update_db == undefined)
      update_db = true;
      
    if(!data.employee) data.employee = data.user;

    if (update_db && data && data.employee) {
      var sql, args;
console.log('authSetUserData=>authSetUserLocalData');
      $scope.authSetUserLocalData(data);

      if (data.employee.id) {
        console.log('authSetUserData=>Employee.sync');
        Employee.sync({}, data.employee.id).then(function(employee_or_employees) {
          if (!not_redirect)
            $scope.authAlreadyLogged();
        });
        
      } else {
        $scope.authAlreadyLogged();
      }
    };

    // $scope.authSetUserAvatar = function(data) {
    // if (data && data.employee.photo_exist && data.employee.photo && data.employee.photo.photo && data.employee.photo.photo.view && data.employee.photo.photo.view.url) {
    // window.localStorage.setItem("user_avatar", data.employee.photo.photo.view.url);
    // } else {
    // window.localStorage.removeItem("user_avatar");
    // }
  };

  $scope.authUpdateUserDataSuccess = function(url, type, params, result) {
    result.user = result;
    result.auth_token = window.localStorage.getItem("auth_token");
    $scope.authSetUserData(result, true, true);
  };

  $scope.authUpdateUserData = function() {
    $scope.authSignedRequest($CONFIG.moe.url('prepared_show_user'), 'GET', {}, false, '$scope.authUpdateUserDataSuccess');
  };

  $scope.authPasswordChange = function(data) {
    if (data.success == true) {
      $scope.authSetUserData(data);
    } else {
      if (data.error_code == 'invalid_sms_code') {
        $scope.addErrorToField($('.form-item input[name=code]'), data.error_message);
      } else if (data.error_code = 'invalid_user_params') {
        $scope.addErrorToField($('.form-item input[name=password]'), data.error_message);
      }
    }
  };

  $scope.authSetUserDataFromDb = function(successCallback) {
    if (!window.localStorage.getItem("auth_token")) {
      var data = null;

      employee_id = window.localStorage.getItem("employee_id");

      Employee.find(employee_id).then(function(employee) {
        data = {};

        data.employee = employee;

        $scope.authSetUserData(data, false);

        if (successCallback)
          eval(successCallback + '(data)');
      });

    }
  };

  $scope.authAlreadyLogged = function(check_for_verification) {
    check_for_verification = check_for_verification && !$.urlParam('not_check_for_verification');

    if ($scope.authIsLogged()) {
      redirectTo($CONFIG.local.welcome_path);
    } else if (check_for_verification && $CONFIG.verify_first_use) {

      Employee.all().then(function(employees) {
        if (!employees || employees.length == 0) {
          redirectTo($CONFIG.local.verification_path);
        }
      });

    }
  };

  $scope.authRedirectNotAuthorized = function() {
    //document.location.href = $CONFIG.local.root_path;

    $scope.error_occurred(null, $CONFIG.error_message_should_be_authorized);
  };

  $scope.authShouldBeAuthorized = function() {
    if (!$scope.authIsLogged()) {
      $scope.authRedirectNotAuthorized();
      return false;
    }

    return true;
  };

  $scope.authSignOutLocal = function() {
    $scope.authCleanUserDataAndRedirect();
  };

  $scope.authSignOut = function() {
    $scope.authSignedRequest($CONFIG.moe.url('session_destroy').replace(/_employee_id_/, window.localStorage.getItem("employee_id")), 'POST', {}, false, '$scope.authSignOutLocal', '$scope.authCleanUserDataAndRedirect');
    $ionicSideMenuDelegate.toggleRight(false);
  };

  $scope.authSignedParams = function(params) {
    return authSignedParams(params);
  };

  // sending request to MOE server with auth token
  $scope.authSignedRequest = function(url, type, params, async, callback, errorCallback) {
    if (async == undefined)
      async = false;

    params = $scope.authSignedParams(params);

    $scope.authShouldBeAuthorized();

    type = type == undefined ? 'GET' : type;
    var result;

    $.ajax({
      type : type,
      url : url,
      data : params,
      async : async,
      success : function(data) {
        result = data;
        if (result.status == 401) {
          alert($LOCALE.get('your_session_is_expired_pls_authorize_again'));
          $scope.authCleanUserDataAndRedirect();
        } else if (callback) {
          eval(callback + '(url, type, params, result)');
        }
      },
      error : function(xhr, status, error) {
        if (status == "timeout" || error.name == 'TimeoutError') {
          $scope.lostConnection();
        } else if (errorCallback) {
          result = eval(errorCallback + '(url, type, params, error)');
        } else {
          //authCleanUserDataAndRedirect(true);
          $scope.lostConnection(true);
          //error_occurred(error);
        }
      }
    });
    //var t;
    //return t;//todo remove
    return result;
  };

});
