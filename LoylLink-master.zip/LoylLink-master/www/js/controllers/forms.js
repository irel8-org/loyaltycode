
angular.module('loylMeApp.controllers.forms', [])

.controller('FormsCtrl', function($scope) {

  // FORM FUNCTIONS
  $scope.formErrors = {};

  $scope.error_occurred_for_form = function(form) {
    var cont = $(form).find('.form-submit-error');

    if (cont.length > 0) {
      cont.html($LOCALE.get('form_not_submited')).show();
    } else {
      $(form).append('<div class="form-submit-error">' + $LOCALE.get('form_not_submited') + '</div>');
    }
  };

  $scope.addErrorToField = function(field, message) {
    $(field).focus();

    $(field).parent().addClass('error');

    if ($(field).siblings('.error-message').length == 0) {
      $(field).after('<span class="error-message"></span>');
    }

    $(field).siblings('.error-message').html(message).show();
  };

  $scope.isFieldBlank = function(field) {
    var str = typeof (field) == 'string' ? field : $(field).val();
    return !!str.match(/^\s*$/);
  };

  $scope.formsAddError = function(field, message) {
    field = $(field).attr('id');
    if (formErrors[field] == undefined) {
      formErrors[field] = [];
    }

    if (formErrors[field].indexOf(message) == -1)
      formErrors[field].push(message);
  };

  $scope.formsErrorExist = function() {
    return Object.keys(formErrors).length > 0;
  };

  $scope.validForm = function(form) {
    form = $(form);

    form.find('.error').removeClass('error');
    form.find('.success-message').remove();
    form.find('.base-error-message').remove();
    form.find('.form-submit-error').remove();
    
    form.find('.error-message').remove();

    formErrors = [];

    form.find('.requiredFieldForChoice').each(function(i) {
      vals = [];
      $('[data-choice=' + $(this).data('choice') + ']').each(function() {
        vals.push($(this).val());
      });
      if ($scope.isFieldBlank(vals.join(''))) {
        $scope.formsAddError(this, 'cannot be blank');
      }
    });

    form.find('.requiredField').each(function(i) {
      if ($scope.isFieldBlank(this)) {
        $scope.formsAddError(this, $LOCALE.get('cannot_be_blank'));

      } else if ($(this).hasClass('requiredEmailField')) {
        var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;

        if (!emailReg.test($(this).val())) {
          $scope.formsAddError(this, $LOCALE.get('should_be_valid_email'));
        }
      }
    });

    form.find('.customValidation').each(function(i) {
      $this = $(this);
      if ($this.data('type')) {
        if ($this.data('type') == 'integer' && !$this.val().match(/^\d+$/)) {
          $scope.formsAddError(this, $LOCALE.get('should_be_numericality'));
        } else if ($this.data('type') == 'string') {
          // todo
        }
      }

      if ($this.data('size-max') && $this.val().length > parseInt($this.data('size-max'))) {
        $scope.formsAddError(this, $LOCALE.get('should_have_length_less_or_equal') + ' ' + $this.data('size-max'));
      }

      if ($this.data('size-min') && $this.val().length < parseInt($this.data('size-min'))) {
        $scope.formsAddError(this, $LOCALE.get('should_have_length_more_or_equal') + ' ' + $this.data('size-min'));
      }

      if ($this.data('size-equal') && $this.val().length != parseInt($this.data('size-equal'))) {
        $scope.formsAddError(this, $LOCALE.get('should_have_length_equal') + ' ' + $this.data('size-equal'));
      }
    });

    form.find('.ShouldBeConfirmedField').each(function(i) {
      $this = $(this);
      $this_conf = $('#' + $this.attr('id') + '-confirmation');

      if ($this.val() != $this_conf.val()) {
        $scope.formsAddError($this_conf, $LOCALE.get('invalid_confirmation'));
      }
    });

    return !$scope.formsErrorExist();
  };

  $scope.ReqieredNotSet = function(field) {
    addErrorToField(field, $LOCALE.get('cannot_be_blank'));

    return false;
  };

  $scope.formsSetEvents = function(klass) {
    if (!klass)
      klass = 'smart-form';
    console.log('formsSetEvents', klass, $('form.'+klass));

    $('form.' + klass).bind('submit', function() {

      if ($scope.validForm(this)) {
        $scope.submitData(this);
      } else {
        for (i in formErrors) {
          $scope.addErrorToField($('#' + i), formErrors[i].join(' ' + $LOCALE.get('and') + ' '));
        }
      }

      //headerControll();

      return false;
    });
  };

  $scope.submitData = function(form) {
    $(form).find('[type="submit"]').attr('disabled', true);

    if ($(form).data('before-callback')) {
      $scope.$broadcast( $(form).data('before-callback'));
      //eval($(form).data('before-call') + '()');
    }

    var formVals = $(form).serialize();

    var device_attrs = $scope.authDeviceAttributes();

    formVals = formVals + '&' + decodeURIComponent($.param(device_attrs));

    formVals = formVals + '&' + decodeURIComponent($.param({
      api_version : $CONFIG.moe.api_version,
      without_reseller_ids : $CONFIG.moe.without_reseller_ids,
      reseller_id : $CONFIG.moe.reseller_id
    }));

    if ($(form).data('config-param')) {
      var source = $(form).data('config-source') || 'local';
      if (source == 'moe') {
        url = $CONFIG[source].url($(form).data('config-param'));
      } else {
        url = $CONFIG[source][$(form).data('config-param')];
      }
    } else {
      url = $(form).attr('action');
    }

    url = url.replace(/_EMPLOYEE_ID_/, window.localStorage.getItem("employee_id"));
    
    var customer_id = $(form).find('[name*="customer_id"]').length > 0 ?$(form).find('[name*="customer_id"]').val() : 0;
 
    url = url.replace(/_CUSTOMER_ID_/, customer_id);

    if ($(form).data('should-be-signed')) {
      url += '?auth_token=' + window.localStorage.getItem("auth_token");
    }

    $.post(url, formVals, function(data) {
      console.log('data.status', data.status);
      if (data.status == 401) {
        alert($LOCALE.get('your_session_is_expired_pls_authorize_again'));
        $scope.authCleanUserDataAndRedirect();
      } else if ($(form).data('callback')) {
        console.log('callback:', $(form).data('callback'));
        $scope.$broadcast( $(form).data('callback'), data);      
      }

      $(form).find('[type="submit"]').attr('disabled', false);
    }, 'json').fail(function(data) {
      if ($(form).data('error-callback')) {
        console.log('error-callback:', $(form).data('error-callback'));
        try {
          $scope.$broadcast( $(form).data('error-callback'), JSON.parse(data.responseText));        
        } catch(e) {
          console.log(form);
          $scope.error_occurred_for_form(form);
        }
      } else {
        console.log(form);
        $scope.error_occurred_for_form(form);
      }

      $(form).find('[type="submit"]').attr('disabled', false);
    });
  };

  /// END FORM FUNCTIONS

});