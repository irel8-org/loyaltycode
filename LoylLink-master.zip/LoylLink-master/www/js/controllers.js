var $LOCATION, $LOCALE, $SCOPE;

angular.module('loylMeApp.controllers', []).controller('AppCtrl', function($scope, $controller, LocaleData, MenuData, $location, $ionicLoading) {
  console.log('AuthCtrl loading');
  $controller('AuthCtrl', {
    $scope : $scope
  });
  console.log('FormsCtrl loading');
  $controller('FormsCtrl', {
    $scope : $scope
  });
  console.log('CameraCtrl loading');
  $controller('CameraCtrl', {
    $scope : $scope
  });
  $_SCOPE = $scope;

  // $ionicLoading.show({
  // template : 'Loading...'
  // });

  //   $ionicLoading.hide();

  $scope.error_occurred = function(e, message) {
    console.log(e, message);

    var error_occurred_num = $LOCATION.search().error_occurred ? parseInt($LOCATION.search().error_occurred) : 0;

    var redirect = true;

    if (error_occurred_num <= 3) {
      alert(message || $CONFIG.error_message);
      $scope.redirectTo($CONFIG.local.root_path, {
        error_occurred : (error_occurred_num + 1)
      });
      return false;
    } else {
      alert($CONFIG.second_error_message);
      redirect = false;
    }

    $scope.authCleanUserDataAndRedirect(!redirect, '?error_occurred=' + (error_occurred_num + 1));
  };

  $scope.menu_items = MenuData.items;

  $scope.moe_host = $CONFIG.moe.host;

  $LOCATION = $location;
  $LOCALE = LocaleData;

  LocaleData.async().then(function() {
    $scope.locale = LocaleData.getAll();
    $LOCALE = LocaleData;
  });

  $scope.redirectTo = function(url, params) {
    redirectTo(url, params);
  };

  $scope.lostConnection = function(error_on_server) {
    var cont = $('.lost-connection');

    if (cont.length > 0) {
      cont.html($LOCALE.get('lost_connection')).show();
    } else {
      $('ion-content').prepend('<div class="lost-connection"><div>' + $LOCALE.get('lost_connection') + '<button class="btn btn-large background-color-1 background-color-hover-1" onclick="document.location.reload()">Check Again</button></div></div>');
    };
  };

  $scope.toggleChange = function(slider, cont) {
    console.log(slider[cont], cont);
    var container = $('[ng-model="' + cont + '"]');

    container.find('input[type=hidden]').val(slider[cont] ? 1 : 0);
    container.find('.sub').hide();
    container.find('.sub.' + (slider[cont] ? 'on' : 'off')).show().removeClass('hidden');
  };

  $scope.signOut = function() {
    $scope.authSignOut();
    return true;
  };

})
// Home Controller
.controller('HomeCtrl', function($scope, $ionicPlatform, DB) {
 document.addEventListener("deviceready", function() {
     DB.init();
    if (!$LOCATION.search().error_occurred) {
      $scope.authSetUserDataFromDb();

      $scope.authAlreadyLogged(true);
    }

    //localeStandartControll();
  });
}).controller('EnterAmountCtrl', function($scope, $stateParams, $controller) {
  $controller('RewardEnterAmountBaseCtrl', {
    $scope : $scope
  });

  $scope.rewardEnterVisitAmount = function() {
    if ($('#enterAmount').html().length == 0) {
      return false;
    };

    redirectTo("#/app/confirm_transaction/" + $stateParams.customer_id + '/' + $('#enterAmount').html());
  };

}).controller('ConfirmTransactionCtrl', function($scope, $stateParams, Customer) {
  $scope.authShouldBeAuthorized();

  Customer.find($stateParams.customer_id).then(function(customer) {
    $scope.customer = customer;
  });

  $scope.amount = $stateParams.amount;
  $scope.amount_in_words = $LOCALE.get('confirm_transaction.amount', {
    amount : $stateParams.amount
  });

  $scope.reward_name = $.urlParam('reward_name');

  $scope.confirmTransaction = function() {
    res = $scope.authSignedRequest($CONFIG.moe.url('purchases'), 'POST', {
      amount : $stateParams.amount,
      customer_id : $stateParams.customer_id,
      reward_id : $.urlParam('reward_id'),
      amount : $.urlParam('amount'),
      items : $.urlParam('items'),
      reward_prize : $.urlParam('reward_prize'),
      reward_type : $.urlParam('reward_type'),
      reward_name : $.urlParam('reward_name'),
      campaign_id : $.urlParam('campaign_id')
    });

    console.log('confirmTransaction:', res);

    if (res.saved) {
      redirectTo("#/app/transaction_completed/" + $stateParams.customer_id);
    } else {
      alert(res.errors);
    }
  };
}).controller('TransactionCompletedCtrl', function($scope, $stateParams, Customer) {
  if (!$stateParams.customer_id)
    redirectTo('#/app/customers');

  $scope.authShouldBeAuthorized();

  Customer.find($stateParams.customer_id, true).then(function(customer) {
    if (customer) {
      $scope.customer = customer;

      $scope.new_loyalty_value = $LOCALE.get('transaction_completed.new_loyalty_value', {
        first_name : customer.first_name,
        loyalty_value : customer.loyalty_value || 0
      });
    }
  });

}); 