window.debug = true;
$_V=3;

function track(){
  
}

  // catch exceptions out of angular
  window.onerror = function(message, url, line, col, error) {
    var stopPropagation = debug ? false : true;
    var data = {
      type : 'javascript',
      url : window.location.hash,
      localtime : Date.now()
    };
    if (message) {
      data.message = message;
    }
    if (url) {
      data.fileName = url;
    }
    if (line) {
      data.lineNumber = line;
    }
    if (col) {
      data.columnNumber = col;
    }
    if (error) {
      if (error.name) {
        data.name = error.name;
      }
      if (error.stack) {
        data.stack = error.stack;
      }
    }

    if (debug) {
      console.log('exception', data);
      window.alert('Error: ' + data.message);
    } else {
      track('exception', data);
    }
    return stopPropagation;
  };

function redirectTo(url, params, message) {
  console.log('current_path', document.location.href);
  var q, sign;

  if (message)
    alert(message);

  if (!params)
    params = {};

  if (!url)
    url = $CONFIG.local.root_path;

  if (url.match(/\?/)) {
    postfix = '&';
  } else {
    postfix = '?';
  }

  url = url.replace(/\/$/, '');

  postfix = postfix + $.param(params);

  console.log('redirectTo:', url + postfix);
  document.location.href = url + postfix;

  if ($LOADING)
    $LOADING.hide();
}

function initializeDB(DB, $cordovaSQLite) {
  console.log('initializeDB...');
 
  db_type = window.cordova && $cordovaSQLite ? 'SQLite' : 'web';

  console.log(db_type);

  if (db_type == 'SQLite') {
    $_DB = window.sqlitePlugin.openDatabase({
      name : $CONFIG.db.name
    }, function(db) {
      db.transaction(function(tx) {
        console.log('Open database SUCCESS: ');
        console.log(tx);
      }, function(err) {
        console.log('Open database ERROR: ' + JSON.stringify(err));
      });
    });
    //, 1 );
  } else {
    // Ionic serve syntax
    $_DB = window.openDatabase($CONFIG.db.name, '1.0', $CONFIG.db.name, $CONFIG.db.size);
  }

  DB.init();
}

var loyl_link_app = angular.module('loylMeApp', ['ionic', 'loylMeApp.controllers.auth', 'loylMeApp.controllers.forms', 'loylMeApp.controllers.camera', 'loylMeApp.controllers', 'loylMeApp.controllers.session', 'loylMeApp.controllers.customers', 'loylMeApp.controllers.rewards', 'loylMeApp.controllers.employees', 'loylMeApp.data', 'loylMeApp.data.db', 'loylMeApp.data.customer', 'loylMeApp.data.locale', 'loylMeApp.data.employee', 'loylMeApp.data.merchant', 'loylMeApp.data.role', 'loylMeApp.directives', 'loylMeApp.filters', 'loylMeApp.storage', 'ngSanitize', //'uiGmapgoogle-maps',
'angularLoad', 'ngCordova']);

loyl_link_app.run(function($rootScope, $ionicLoading, $ionicPlatform, DB, $cordovaSQLite, $timeout, $state) {
 //$('body').prepend('<br/>VERSION:'+$_V);
  $_STATE = $state;

  $LOADING = $ionicLoading;

  $rootScope.$on('loading:show', function() {
    console.log('loading:show');
    $ionicLoading.show({
      template : "<ion-spinner class='spinner-stable'></ion-spinner>",
      noBackdrop : false
    });
  });

  $rootScope.$on('loading:hide', function() {
    console.log('loading:hide');
    $ionicLoading.hide();
  });

  if (window.cordova) {
    console.log('window.cordova - deviceready');
    document.addEventListener("deviceready", function() {
      initializeDB(DB, $cordovaSQLite);
    });
  } else {
    console.log('!window.cordova - $ionicPlatform.ready');
    $ionicPlatform.ready(function() {
      initializeDB(DB, $cordovaSQLite);
    });
  }

  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // // for form inputs)
    // if (window.cordova && window.cordova.plugins.Keyboard) {
    // cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
    // }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }

    // Open any external link with InAppBrowser Plugin
    $(document).on('click', 'a[href^=http], a[href^=https]', function(e) {

      e.preventDefault();
      var $this = $(this);
      var target = $this.data('inAppBrowser') || '_blank';

      window.open($this.attr('href'), target);

    });

  });
  
  function stateInit(i){   
    if(!i) i = 1;
    
  //  $('body').prepend('stateInit:'+i+'<br/>');
     
    if($state)
      window.localStorage.getItem("auth_token") ? $state.go('app.welcome') : $state.go('app.home');
    
    if(!$state || !$state.current || !$state.current.name || $state.current.name.length == 0){
      $timeout(function() {
        stateInit(i+1);
      }, 1000);
    }     
  }

   stateInit();
  
});

loyl_link_app.config(function($stateProvider, $provide, $urlRouterProvider, $ionicConfigProvider, $httpProvider) {

  $provide.decorator('$exceptionHandler', ['$delegate',
  function($delegate) {
    return function(exception, cause) {
      $delegate(exception, cause);

      var data = {
        type : 'angular',
        url : window.location.hash,
        localtime : Date.now()
      };
      if (cause) {
        data.cause = cause;
      }
      if (exception) {
        if (exception.message) {
          data.message = exception.message;
        }
        if (exception.name) {
          data.name = exception.name;
        }
        if (exception.stack) {
          data.stack = exception.stack;
        }
      }

      if (debug) {
        console.log('exception', data);
        window.alert('Error: ' + data.message);
      } else {
        track('exception', data);
      }
    };
  }]);


  $httpProvider.interceptors.push(function($rootScope) {
    return {
      request : function(config) {
        console.log(config);
        if (config.url.match(/http/))
          $rootScope.$broadcast('loading:show');
        return config;
      },
      response : function(response) {
        console.log('response:', response);

        if (response && response.data) {

          if (response.data.status == 403) {

            console.log('Sorry, you have not permissions for this action');

            alert('Sorry, you have not permissions for this action');

            window.history.back();
          } else if (response.data.status == 401) {
            authCleanUserData();
            redirectTo('#app/login', {}, $CONFIG.error_message_should_be_authorized);
          }
        }

        if (response.config.url.match(/http/))
          $rootScope.$broadcast('loading:hide');

        return response;
      },
      responseError : function(response) {
        console.log('$httpProvider error', response);

        if (response.data == null)
          response.data = {};

        if (response.config && response.config.url.match(/http/))
          $rootScope.$broadcast('loading:hide');

        return response;
      }
    };
  });

  $httpProvider.defaults.timeout = 10000;

  // $ionicConfigProvider
  // http://ionicframework.com/docs/api/provider/%24ionicConfigProvider/
  $ionicConfigProvider.tabs.position('bottom');
  $ionicConfigProvider.navBar.alignTitle('center');

  $ionicConfigProvider.views.maxCache(0);
  $ionicConfigProvider.templates.maxPrefetch(0);

  $stateProvider.state('app', {
    url : "/app",
    abstract : true,
    templateUrl : "templates/app.html",
    controller : 'AppCtrl'

  }).state('app.home', {
    url : "/home",
    views : {
      'appContent' : {
        templateUrl : "templates/home.html",
        controller : 'HomeCtrl'
      }
    }
  }).state('app.welcome', {
    url : "/welcome",
    views : {
      'appContent' : {
        templateUrl : "templates/welcome.html",
        controller : 'WelcomeCtrl'
      }
    }
  }).state('app.login', {
    url : "/login",
    views : {
      'appContent' : {
        templateUrl : "templates/login.html",
        controller : 'LoginCtrl'
      }
    }
  }).state('app.forgotpassword', {
    url : "/forgotpassword",
    views : {
      'appContent' : {
        templateUrl : "templates/login_forgot_password.html",
        controller : 'LoginForgotPasswordCtrl'
      }
    }
  }).state('app.signup', {
    url : "/signup",
    views : {
      'appContent' : {
        templateUrl : "templates/signup.html",
        controller : 'SignUpCtrl'
      }
    }
  }).state('app.customers', {
    url : "/customers",
    views : {
      'appContent' : {
        templateUrl : "templates/customers.html",
        controller : 'CustomersCtrl'
      }
    }
  }).state('app.customer', {
    url : "/customers/:id",
    views : {
      'appContent' : {
        templateUrl : "templates/customer.html",
        controller : 'CustomerCtrl'
      }
    }
  }).state('app.customer_edit', {
    url : "/customers/:id/edit",
    views : {
      'appContent' : {
        templateUrl : "templates/customer_edit.html",
        controller : 'CustomerEditCtrl'
      }
    }
  }).state('app.customer_edit_payment', {
    url : "/customers/:id/edit/payment",
    views : {
      'appContent' : {
        templateUrl : "templates/customer_edit_payment.html",
        controller : 'CustomerEditPaymentCtrl'
      }
    }
  }).state('app.customer_edit_settings', {
    url : "/customers/:id/edit/settings",
    views : {
      'appContent' : {
        templateUrl : "templates/customer_edit_settings.html",
        controller : 'CustomerEditSettingsCtrl'
      }
    }
  }).state('app.add_customer', {
    url : "/add_customer",
    views : {
      'appContent' : {
        templateUrl : "templates/add_customer.html",
        controller : 'AddCustomerCtrl'
      }
    }
  }).state('app.enter_amount', {
    url : "/enter_amount/:customer_id",
    views : {
      'appContent' : {
        templateUrl : "templates/enter_amount.html",
        controller : 'EnterAmountCtrl'
      }
    }
  }).state('app.confirm_transaction', {
    url : "/confirm_transaction/:customer_id/:amount",
    views : {
      'appContent' : {
        templateUrl : "templates/confirm_transaction.html",
        controller : 'ConfirmTransactionCtrl'
      }
    }
  }).state('app.transaction_completed', {
    url : "/transaction_completed/:customer_id",
    views : {
      'appContent' : {
        templateUrl : "templates/transaction_completed.html",
        controller : 'TransactionCompletedCtrl'
      }
    }
  }).state('app.rewards', {
    url : "/rewards/:customer_id",
    views : {
      'appContent' : {
        templateUrl : "templates/rewards.html",
        controller : 'RewardsCtrl'
      }
    }
  }).state('app.reward_enter_amount', {
    url : "/reward_enter_amount/:customer_id",
    views : {
      'appContent' : {
        templateUrl : "templates/reward_enter_amount.html",
        controller : 'RewardEnterAmountCtrl'
      }
    }
  }).state('app.reward_enter_items', {
    url : "/reward_enter_items/:customer_id",
    views : {
      'appContent' : {
        templateUrl : "templates/reward_enter_items.html",
        controller : 'RewardEnterItemsCtrl'
      }
    }
  }).state('app.manage_employees', {
    url : "/employees/manage",
    views : {
      'appContent' : {
        templateUrl : "templates/manage_employees.html",
        controller : 'ManageEmployeesCtrl'
      }
    }
  }).state('app.employees', {
    url : "/employees",
    views : {
      'appContent' : {
        templateUrl : "templates/employees.html",
        controller : 'EmployeesCtrl'
      }
    }
  }).state('app.add_employee', {
    url : "/employees/new",
    views : {
      'appContent' : {
        templateUrl : "templates/add_employee.html",
        controller : 'AddEmployeeCtrl'
      }
    }
  }).state('app.stamp_check', {
    url : "/employees/stamp_check",
    views : {
      'appContent' : {
        templateUrl : "templates/stamp_check.html",
        controller : 'StampCheckCtrl'
      }
    }
  }).state('app.employee', {
    url : "/employees/:id",
    views : {
      'appContent' : {
        templateUrl : "templates/employee.html",
        controller : 'EmployeeCtrl'
      }
    }
  }).state('app.employee_archive', {
    url : "/employees/:id/archive",
    views : {
      'appContent' : {
        templateUrl : "templates/employee_archive.html",
        controller : 'EmployeeArchiveCtrl'
      }
    }
  }).state('app.employee_edit', {
    url : "/employees/:id/edit",
    views : {
      'appContent' : {
        templateUrl : "templates/employee_edit.html",
        controller : 'EmployeeEditCtrl'
      }
    }
  }).state('app.employee_stamp_remove', {
    url : "/employees/:id/stamps/:stamp_id/remove",
    views : {
      'appContent' : {
        templateUrl : "templates/employee_stamp_remove.html",
        controller : 'EmployeeRemoveStampCtrl'
      }
    }
  }).state('app.employee_assing_stamp', {
    url : "/employees/:id/stamps/new",
    views : {
      'appContent' : {
        templateUrl : "templates/employee_stamp_assign.html",
        controller : 'EmployeeAssignStampCtrl'
      }
    }
  }).state('app.employee_stamp_assinged', {
    url : "/employees/:id/stamps/assigned",
    views : {
      'appContent' : {
        templateUrl : "templates/employee_stamp_assigned.html",
        controller : 'EmployeeStampAssignedCtrl'
      }
    }
  }).state('app.employee_stamp_unassinged', {
    url : "/employees/:id/stamps/unassigned/:owner_id",
    views : {
      'appContent' : {
        templateUrl : "templates/employee_stamp_unassigned.html",
        controller : 'EmployeeStampUnassignedCtrl'
      }
    }
  }).state('app.unassigned_stamp', {
    url : "/unassigned_stamp",
    views : {
      'appContent' : {
        templateUrl : "templates/unassigned_stamp.html",
        controller : 'EmployeeNotAssignedStampCtrl'
      }
    }
  }).state('app.employee_stamp', {
    url : "/employees/:id/stamps/:stamp_id",
    views : {
      'appContent' : {
        templateUrl : "templates/employee_stamp.html",
        controller : 'EmployeeStampCtrl'
      }
    }
  }).state('app.card_scanner', {
    url : "/card_scanner",
    views : {
      'appContent' : {
        templateUrl : "templates/card_scanner.html",
        controller : 'CustomerCardScannerCtrl'
      }
    }
  }),

  // if none of the above states are matched, use this as the fallback
  (window.localStorage.getItem("auth_token") ? $urlRouterProvider.otherwise('/app/welcome') : $urlRouterProvider.otherwise('/app/home'));
});
