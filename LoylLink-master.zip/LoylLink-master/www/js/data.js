angular.module('loylMeApp.data', ['loylMeApp.dbConfig'])

// Menu Data: Menu configuration
.factory('MenuData', function() {
  var data = {};

  data.items = [{
    title : 'Home',
    icon : 'ion-ios-home',
    url : '#/app'
  },
  {
    title : 'Customers',
    icon : 'ion-person-stalker',
    url : '#/app/customers'
  }, {
    title : 'Add Customer',
    icon : 'ion-person-add',
    url : '#/app/add_customer'
  }, {
    title : 'Manage Employees',
    icon : 'ion-ios-people',
    url : '#/app/employees/manage'
  }];

  return data;
});
