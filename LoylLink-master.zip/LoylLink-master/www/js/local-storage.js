angular.module('loylMeApp.storage', []).factory('LocaleStorage', function() {
  return {
    all: function() {
      var locales = window.localStorage['locales'];
      if(locales) {
        return angular.fromJson(locales);
      }
      return {};
    },
    save: function(locales) {
      window.localStorage['locales'] = angular.toJson(locales);
    },
    clear: function() {
      window.localStorage.removeItem('locales');
    }
  };
});

